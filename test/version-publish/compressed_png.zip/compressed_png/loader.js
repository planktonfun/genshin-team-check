
		// Replace 'your_zip_file_url' with the actual URL of the zip file
		const zipFileUrl = './compressed_png.zip';

		var extractedProgress = {total:0,progress:0};
		var extractedFiles = {};
		var extractedAudioFiles = {};
		var extractedJSFiles = {};

		function getExtractedFile(filename) {
			if(!extractedFiles[filename.toLowerCase()]) return filename;

			if(filename.indexOf(".mp3") == filename.length - 4) {
    			if(!extractedAudioFiles[filename.toLowerCase()]) return filename;
    			return extractedAudioFiles[filename.toLowerCase()];
			}

			return extractedFiles[filename.toLowerCase()];
		}

		function startDownload() {
	        loadTheZipFromUrl(zipFileUrl);
	    }

		function loadTheZipFromUrl(zipFileUrl) {
			const xhr = new XMLHttpRequest();

			xhr.onprogress = function (event) {
	            if (event.lengthComputable) {
	                const percentComplete = (event.loaded / event.total) * 100;
	                document.getElementById('progress-bar').style.width = percentComplete + '%';
	            }
	        };

			// Set up event listeners
			xhr.addEventListener('load', function () {
			  if (xhr.status === 200) {
			    // The request was successful
			    const blob = xhr.response;
			    loadTheZipBlob(blob)

			  } else {
			    // Handle errors here, e.g., show an error message
			    console.error('Failed to download the zip file');
			  }
			});

			xhr.addEventListener('error', function () {
			  // Handle network errors here
			  console.error('Network error occurred');
			});

			xhr.open('GET', zipFileUrl);
			xhr.responseType = 'blob'; // Set the response type to Blob
			xhr.send();
		}

		async function convertJSBlobURLToDataUrl(blobURL, name) {
		  try {
		    // Fetch the Blob data
		    const response = await fetch(blobURL);
		    if (!response.ok) {
		      throw new Error('Failed to fetch Blob data');
		    }

		    // Read the Blob data as ArrayBuffer
		    const blobData = await response.blob();

		    // Convert the Blob data to a Data URL with 'audio/mpeg' MIME type
		    const dataURL = `data:text/javascript;base64,${await blobToBase64(blobData)}`;
		    return dataURL;
		  } catch (error) {
		    console.error('Error converting Blob URL to Data URL:', error);
		    throw error;
		  }
		}

		async function convertAudioBlobURLToDataUrl(blobURL, name) {
		  try {
		    // Fetch the Blob data
		    const response = await fetch(blobURL);
		    if (!response.ok) {
		      throw new Error('Failed to fetch Blob data');
		    }

		    // Read the Blob data as ArrayBuffer
		    const blobData = await response.blob();

		    // Convert the Blob data to a Data URL with 'audio/mpeg' MIME type
		    const dataURL = `data:audio/mpeg;base64,${await blobToBase64(blobData)}`;

		    return dataURL;
		  } catch (error) {
		    console.error('Error converting Blob URL to Data URL:', error);
		    throw error;
		  }
		}

		function checkComplete() {

			const percentComplete = (extractedProgress.progress / extractedProgress.total) * 100;
            document.getElementById('progress-bar2').style.width = percentComplete + '%';

			if(extractedProgress.progress != extractedProgress.total) return;

			loadJSFiles();
		}

		async function blobToBase64(blob) {
		  return new Promise((resolve, reject) => {
		    const reader = new FileReader();
		    reader.onload = () => {
		      resolve(reader.result.split(',')[1]);
		    };
		    reader.onerror = (error) => {
		      reject(error);
		    };
		    reader.readAsDataURL(blob);
		  });
		}


		function loadTheZipBlob(zipBlob) {
			// Create a new JSZip instance
			const zip = new JSZip();

			// Use FileReader to read the Blob as an array buffer
			const reader = new FileReader();

			reader.onload = function () {
			  const arrayBuffer = reader.result;

			  // Load the zip file into JSZip
			  zip.loadAsync(arrayBuffer)
			    .then(function (zipContents) {
			      extractedProgress.total = Object.keys(zipContents.files).length;
			      // Loop through each file in the zip
			      zipContents.forEach(function (relativePath, file) {
			        // Extract the file
			        file.async('blob').then(async function (content) {
			          var filename = relativePath.replace('compressed_png/', '').toLowerCase();

			          if(filename.indexOf(".js") == filename.length - 3) {
			          	extractedJSFiles[filename] = URL.createObjectURL(content); //await convertJSBlobURLToDataUrl(URL.createObjectURL(content));
					  } else {
			          	extractedAudioFiles[filename] = await convertAudioBlobURLToDataUrl(URL.createObjectURL(content));
			          	extractedFiles[filename] = URL.createObjectURL(content);
			          }

			          extractedProgress.progress++;
		    		  checkComplete();
			        });
			      });

			    })
			    .catch(function (error) {
			      console.error(error);
			    });
			};

			// Read the Blob as an array buffer
			reader.readAsArrayBuffer(zipBlob);
		}

		function hideProgressBar() {
		  var x = document.getElementById("progress-container");
		  if (x.style.display === "none") {
		    x.style.display = "block";
		  } else {
		    x.style.display = "none";
		  }
		  var x = document.getElementById("progress-container2");
		  if (x.style.display === "none") {
		    x.style.display = "block";
		  } else {
		    x.style.display = "none";
		  }

		}

	    var loadJSOrder = [
	    	"jshashtable.js",
			"logger.js",
			"gd.js",
			"rbush.js",
			"AsyncTasksManager.js",
			"inputmanager.js",
			"jsonmanager.js",
			"Model3DManager.js",
			"timemanager.js",
			"polygon.js",
			"runtimeobject.js",
			"profiler.js",
			"RuntimeInstanceContainer.js",
			"runtimescene.js",
			"scenestack.js",
			"force.js",
			"RuntimeLayer.js",
			"layer.js",
			"RuntimeCustomObjectLayer.js",
			"timer.js",
			"runtimewatermark.js",
			"runtimegame.js",
			"variable.js",
			"variablescontainer.js",
			"oncetriggers.js",
			"runtimebehavior.js",
			"spriteruntimeobject.js",
			"affinetransformation.js",
			"CustomRuntimeObjectInstanceContainer.js",
			"CustomRuntimeObject.js",
			"commontools.js",
			"variabletools.js",
			"runtimescenetools.js",
			"inputtools.js",
			"objecttools.js",
			"cameratools.js",
			"soundtools.js",
			"storagetools.js",
			"stringtools.js",
			"windowtools.js",
			"networktools.js",
			"gd-logo-light.js",
			"pixi.js",
			"pixi-filters-tools.js",
			"runtimegame-pixi-renderer.js",
			"runtimescene-pixi-renderer.js",
			"layer-pixi-renderer.js",
			"pixi-image-manager.js",
			"pixi-bitmapfont-manager.js",
			"spriteruntimeobject-pixi-renderer.js",
			"CustomObjectPixiRenderer.js",
			"DebuggerPixiRenderer.js",
			"loadingscreen-pixi-renderer.js",
			"pixi-effects-manager.js",
			"howler.min.js",
			"howler-sound-manager.js",
			"fontfaceobserver.js",
			"fontfaceobserver-font-manager.js",
			"gdjs-evtsext__basegamefunctions__displaydamage-func.js",
			"gdjs-evtsext__draggablephysics__draggablephysics.js",
			"gdjs-evtsext__flashtransitionpainter__flashtransitionpainter.js",
			"gdjs-evtsext__health__health.js",
			"gdjs-evtsext__interfacefunctions__appendchatmessage-func.js",
			"gdjs-evtsext__interfacefunctions__calculatedistributionpoints-func.js",
			"gdjs-evtsext__interfacefunctions__cleartransparenttextmessage-func.js",
			"gdjs-evtsext__interfacefunctions__converttocurrencyformat-func.js",
			"gdjs-evtsext__interfacefunctions__isobjectinsidecamearaview-func.js",
			"gdjs-evtsext__interfacefunctions__parsedialogdescriptions-func.js",
			"gdjs-evtsext__interfacefunctions__settransparenttextmessage-func.js",
			"gdjs-evtsext__interfacefunctions__settransparenttextmessagewithtimeout-func.js",
			"gdjs-evtsext__interfacefunctions__totitlecase-func.js",
			"gdjs-evtsext__jsonloader__isjsfileloaded-func.js",
			"gdjs-evtsext__jsonloader__loadjsfile-func.js",
			"gdjs-evtsext__jsonloader__loadjsonfilefromurl-func.js",
			"gdjs-evtsext__jsonloader__loadjsonfromtextobject-func.js",
			"gdjs-evtsext__jsonloader__loadjsontoobject-func.js",
			"gdjs-evtsext__jsonloader__loadjsontoscene-func.js",
			"gdjs-evtsext__jsonloader__onsceneloaded-func.js",
			"gdjs-evtsext__mousehelper__cursor.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__broadcastasaserver-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__broadcastonce-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__broadcastonceoneway-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__getactingserver-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__getpredetermineddamage-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__getrandominrangefromseed-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__initializeconnection-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__istimesynchronized-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__loadglobalfunction-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__loadstatemanager-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__onfirstsceneloaded-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__onsceneloaded-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__onscenepostevents-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__onscenepreevents-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__onsceneunloading-func.js",
			"gdjs-evtsext__onlinemultiplayerfirebase__seedrandominrange-func.js",
			"gdjs-evtsext__panelspritecontinuousbar__panelspritecontinuousbar.js",
			"gdjs-evtsext__panelspritecontinuousbar__resourcebar.js",
			"gdjs-evtsext__spritemasking__mask-func.js",
			"gdjs-evtsext__spritemasking__maskwithshapepainter-func.js",
			"gdjs-evtsext__spritemasking__unmask-func.js",
			"gdjs-evtsext__sticker__isstuck-func.js",
			"gdjs-evtsext__sticker__sticker.js",
			"bbtextruntimeobject-pixi-renderer.js",
			"bbtextruntimeobject.js",
			"pixi-multistyle-text.umd.js",
			"bitmaptextruntimeobject-pixi-renderer.js",
			"bitmaptextruntimeobject.js",
			"debuggertools.js",
			"bondage.min.js",
			"dialoguetools.js",
			"draggableruntimebehavior.js",
			"A_firebase-base.js",
			"B_firebase-auth.js",
			"B_firebase-database.js",
			"C_firebasetools.js",
			"D_authtools.js",
			"D_databasetools.js",
			"linkedobjects.js",
			"A_peer.js",
			"B_p2ptools.js",
			"panelspriteruntimeobject-pixi-renderer.js",
			"panelspriteruntimeobject.js",
			"Extensions/Physics2Behavior/Box2D_v2.3.1_min.wasm.js",
			"Extensions/Physics2Behavior/physics2runtimebehavior.js",
			"graphics-extras.min.js",
			"shapepainterruntimeobject-pixi-renderer.js",
			"shapepainterruntimeobject.js",
			"systeminfotools.js",
			"textinputruntimeobject-pixi-renderer.js",
			"textinputruntimeobject.js",
			"textruntimeobject-pixi-renderer.js",
			"textruntimeobject.js",
			"tiledspriteruntimeobject-pixi-renderer.js",
			"tiledspriteruntimeobject.js",
			"shifty.js",
			"shifty_setup.js",
			"tweenruntimebehavior.js",
			"advanced-bloom-pixi-filter.js",
			"drop-shadow-pixi-filter.js",
			"outline-pixi-filter.js",
			"filter-advanced-bloom.js",
			"filter-drop-shadow.js",
			"filter-kawase-blur.js",
			"filter-outline.js",
			"code0.js",
			"code1.js",
			"code2.js",
			"code3.js",
			"data.js",
		];

		function loadJSFileFromBlob(blobUrl) {
			return new Promise((resolve, reject) => {
				// Create a script element
				const scriptElement = document.createElement('script');
				scriptElement.src = blobUrl;
				scriptElement.setAttribute('crossorigin', 'anonymous');

				// Append the script element to the HTML document
				document.head.appendChild(scriptElement);

				// Wait for the script to load and execute
			    scriptElement.onload = () => {
			      resolve(); // Resolve the promise when the script is loaded and executed
			    };

			    // Handle any script loading errors
			    scriptElement.onerror = (error) => {
			      reject(error); // Reject the promise if there's an error
			    };
			});
		}

		function loadExceptionFiles(scriptUrl) {
			return new Promise((resolve, reject) => {
				// Create a script element
				const scriptElement = document.createElement('script');
				scriptElement.src = scriptUrl;
				scriptElement.setAttribute('crossorigin', 'anonymous');

				// Append the script element to the HTML document
				document.head.appendChild(scriptElement);

				// Wait for the script to load and execute
			    scriptElement.onload = () => {
			      resolve(); // Resolve the promise when the script is loaded and executed
			    };

			    // Handle any script loading errors
			    scriptElement.onerror = (error) => {
			      reject(error); // Reject the promise if there's an error
			    };
			});
		}

		async function loadJSFiles() {

			for (const item of loadJSOrder) {
				var filename = item.toLowerCase();

		    	try {
					if(/\//.test(filename)) {
						await loadExceptionFiles(item);
					} else {
						await loadJSFileFromBlob(extractedJSFiles[filename]);
					}
					console.log(filename + ' Script loading and execution completed.');
					// You can now perform further actions after the script has loaded.
				} catch (error) {
					console.error('Script loading failed:', error);
				}
		  	}

			console.log('finish')
			hideProgressBar();
			loadTheGame();
		}
