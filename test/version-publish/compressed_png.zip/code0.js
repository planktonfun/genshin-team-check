gdjs.LoginCode = {};
gdjs.LoginCode.GDCursorsObjects1= [];
gdjs.LoginCode.GDCursorsObjects2= [];
gdjs.LoginCode.GDCursorsObjects3= [];
gdjs.LoginCode.GDCursorsObjects4= [];
gdjs.LoginCode.GDWarpzoneObjects1= [];
gdjs.LoginCode.GDWarpzoneObjects2= [];
gdjs.LoginCode.GDWarpzoneObjects3= [];
gdjs.LoginCode.GDWarpzoneObjects4= [];
gdjs.LoginCode.GDSpawningPointObjects1= [];
gdjs.LoginCode.GDSpawningPointObjects2= [];
gdjs.LoginCode.GDSpawningPointObjects3= [];
gdjs.LoginCode.GDSpawningPointObjects4= [];
gdjs.LoginCode.GDTransitionObjects1= [];
gdjs.LoginCode.GDTransitionObjects2= [];
gdjs.LoginCode.GDTransitionObjects3= [];
gdjs.LoginCode.GDTransitionObjects4= [];
gdjs.LoginCode.GDTransparentBackgroundObjects1= [];
gdjs.LoginCode.GDTransparentBackgroundObjects2= [];
gdjs.LoginCode.GDTransparentBackgroundObjects3= [];
gdjs.LoginCode.GDTransparentBackgroundObjects4= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects1= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects2= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects3= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects4= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects1= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects2= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects3= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects4= [];
gdjs.LoginCode.GDAnnouncementMaskObjects1= [];
gdjs.LoginCode.GDAnnouncementMaskObjects2= [];
gdjs.LoginCode.GDAnnouncementMaskObjects3= [];
gdjs.LoginCode.GDAnnouncementMaskObjects4= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects1= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects2= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects3= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects4= [];
gdjs.LoginCode.GDAnnouncementIconObjects1= [];
gdjs.LoginCode.GDAnnouncementIconObjects2= [];
gdjs.LoginCode.GDAnnouncementIconObjects3= [];
gdjs.LoginCode.GDAnnouncementIconObjects4= [];
gdjs.LoginCode.GDLoadingScreenObjects1= [];
gdjs.LoginCode.GDLoadingScreenObjects2= [];
gdjs.LoginCode.GDLoadingScreenObjects3= [];
gdjs.LoginCode.GDLoadingScreenObjects4= [];
gdjs.LoginCode.GDStartButtonObjects1= [];
gdjs.LoginCode.GDStartButtonObjects2= [];
gdjs.LoginCode.GDStartButtonObjects3= [];
gdjs.LoginCode.GDStartButtonObjects4= [];
gdjs.LoginCode.GDNicknameObjects1= [];
gdjs.LoginCode.GDNicknameObjects2= [];
gdjs.LoginCode.GDNicknameObjects3= [];
gdjs.LoginCode.GDNicknameObjects4= [];
gdjs.LoginCode.GDLoginButtonObjects1= [];
gdjs.LoginCode.GDLoginButtonObjects2= [];
gdjs.LoginCode.GDLoginButtonObjects3= [];
gdjs.LoginCode.GDLoginButtonObjects4= [];
gdjs.LoginCode.GDExitButtonObjects1= [];
gdjs.LoginCode.GDExitButtonObjects2= [];
gdjs.LoginCode.GDExitButtonObjects3= [];
gdjs.LoginCode.GDExitButtonObjects4= [];
gdjs.LoginCode.GDLoginTextObjects1= [];
gdjs.LoginCode.GDLoginTextObjects2= [];
gdjs.LoginCode.GDLoginTextObjects3= [];
gdjs.LoginCode.GDLoginTextObjects4= [];
gdjs.LoginCode.GDExitTextObjects1= [];
gdjs.LoginCode.GDExitTextObjects2= [];
gdjs.LoginCode.GDExitTextObjects3= [];
gdjs.LoginCode.GDExitTextObjects4= [];
gdjs.LoginCode.GDloadingImgObjects1= [];
gdjs.LoginCode.GDloadingImgObjects2= [];
gdjs.LoginCode.GDloadingImgObjects3= [];
gdjs.LoginCode.GDloadingImgObjects4= [];


gdjs.LoginCode.asyncCallback25825780 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);

gdjs.copyArray(runtimeScene.getObjects("loadingImg"), gdjs.LoginCode.GDloadingImgObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDloadingImgObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDloadingImgObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide(false);
}
}}
gdjs.LoginCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LoginCode.GDStartButtonObjects1) asyncObjectsList.addObject("StartButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.LoginCode.asyncCallback25825780(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LoadingScreen"), gdjs.LoginCode.GDLoadingScreenObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDLoadingScreenObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoadingScreenObjects2[i].setAnimation(gdjs.randomInRange(0, 1));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].hide();
}
}
{ //Subevents
gdjs.LoginCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Trickster Online - Trickster Online.mp3", 1, true, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
gdjs.copyArray(gdjs.LoginCode.GDStartButtonObjects1, gdjs.LoginCode.GDStartButtonObjects2);

{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].setString("");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("SavedData").getChild("AlreadyHasLogin"), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects1[i].hide(false);
}
}}

}


};gdjs.LoginCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.LoginCode.GDExitButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButtonObjects1Objects = Hashtable.newFrom({"LoginButton": gdjs.LoginCode.GDLoginButtonObjects1});
gdjs.LoginCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("SavedData").getChild("CharacterCreated"), false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "CharacterCreation", false);
}}

}


};gdjs.LoginCode.asyncCallback25835292 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.LoginCode.asyncCallback25835292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessage.func(runtimeScene, "Logging in...", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDNicknameObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDNicknameObjects1[i].getString() != "" ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDNicknameObjects1[k] = gdjs.LoginCode.GDNicknameObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDNicknameObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfEmptyGDCursorsObjects = Hashtable.newFrom({"Cursors": []});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCursorsObjects1Objects = Hashtable.newFrom({"Cursors": gdjs.LoginCode.GDCursorsObjects1});
gdjs.LoginCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LoginCode.mapOfEmptyGDCursorsObjects) == 0;
if (isConditionTrue_0) {
gdjs.LoginCode.GDCursorsObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCursorsObjects1Objects, 0, 0, "Interface");
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoadingScreenObjects1ObjectsGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"LoadingScreen": gdjs.LoginCode.GDLoadingScreenObjects1, "StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.LoginCode.GDCursorsObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCursorsObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCursorsObjects1[i].isCurrentAnimationName("Hand") ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCursorsObjects1[k] = gdjs.LoginCode.GDCursorsObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDCursorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCursorsObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Click");
}
}}

}


};gdjs.LoginCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDLoginButtonObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects2, "LoginButton": gdjs.LoginCode.GDLoginButtonObjects2});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects2Objects = Hashtable.newFrom({"ExitButton": gdjs.LoginCode.GDExitButtonObjects2});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects2[k] = gdjs.LoginCode.GDStartButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects2[k] = gdjs.LoginCode.GDLoginButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDLoginButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDLoginButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDStartButtonObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDStartButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDLoginButtonObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects2[k] = gdjs.LoginCode.GDStartButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects2[k] = gdjs.LoginCode.GDLoginButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_click.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_create_btnselect.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects2[k] = gdjs.LoginCode.GDExitButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDExitButtonObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDExitButtonObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects2[k] = gdjs.LoginCode.GDExitButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_close.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_open.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_spinbtn.mp3", false, 100, 1);
}}

}


};gdjs.LoginCode.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText"), gdjs.LoginCode.GDTransparentBackgroundTextObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setCenterPositionInScene((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getCenterXInScene()),(( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setWidth((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getWidth()) + 40);
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setHeight((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getHeight()) + 40);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) != "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText"), gdjs.LoginCode.GDTransparentBackgroundTextObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setY(142);
}
}}

}


};gdjs.LoginCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects2);
{/* Mismatched object type - skipped. */}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects2[i].setOpacity(62.5);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TransparentMessageTimer") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TransparentTextMessageSeconds"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(27040180);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects1[k] = gdjs.LoginCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].setAnimation(1);
}
}
{ //Subevents
gdjs.LoginCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects1[k] = gdjs.LoginCode.GDExitButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDExitButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].hide(false);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects1[k] = gdjs.LoginCode.GDLoginButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Attack");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("isOnNpcObject"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("chat");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Blocked");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoadingScreen"), gdjs.LoginCode.GDLoadingScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoadingScreenObjects1ObjectsGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoadingScreenObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoadingScreenObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoadingScreenObjects1[k] = gdjs.LoginCode.GDLoadingScreenObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoadingScreenObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects1[k] = gdjs.LoginCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDStartButtonObjects1.length === 0 ) ? (( gdjs.LoginCode.GDLoadingScreenObjects1.length === 0 ) ? "" :gdjs.LoginCode.GDLoadingScreenObjects1[0].getLayer()) :gdjs.LoginCode.GDStartButtonObjects1[0].getLayer()));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Arrow");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Warp");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("pick");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UsingSkill"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("skill");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Hand");
}
}
{ //Subevents
gdjs.LoginCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(26803732);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList13(runtimeScene);} //End of subevents
}

}


};

gdjs.LoginCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoginCode.GDCursorsObjects1.length = 0;
gdjs.LoginCode.GDCursorsObjects2.length = 0;
gdjs.LoginCode.GDCursorsObjects3.length = 0;
gdjs.LoginCode.GDCursorsObjects4.length = 0;
gdjs.LoginCode.GDWarpzoneObjects1.length = 0;
gdjs.LoginCode.GDWarpzoneObjects2.length = 0;
gdjs.LoginCode.GDWarpzoneObjects3.length = 0;
gdjs.LoginCode.GDWarpzoneObjects4.length = 0;
gdjs.LoginCode.GDSpawningPointObjects1.length = 0;
gdjs.LoginCode.GDSpawningPointObjects2.length = 0;
gdjs.LoginCode.GDSpawningPointObjects3.length = 0;
gdjs.LoginCode.GDSpawningPointObjects4.length = 0;
gdjs.LoginCode.GDTransitionObjects1.length = 0;
gdjs.LoginCode.GDTransitionObjects2.length = 0;
gdjs.LoginCode.GDTransitionObjects3.length = 0;
gdjs.LoginCode.GDTransitionObjects4.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects1.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects2.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects3.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects4.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects1.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects4.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects1.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects2.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects3.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects4.length = 0;
gdjs.LoginCode.GDStartButtonObjects1.length = 0;
gdjs.LoginCode.GDStartButtonObjects2.length = 0;
gdjs.LoginCode.GDStartButtonObjects3.length = 0;
gdjs.LoginCode.GDStartButtonObjects4.length = 0;
gdjs.LoginCode.GDNicknameObjects1.length = 0;
gdjs.LoginCode.GDNicknameObjects2.length = 0;
gdjs.LoginCode.GDNicknameObjects3.length = 0;
gdjs.LoginCode.GDNicknameObjects4.length = 0;
gdjs.LoginCode.GDLoginButtonObjects1.length = 0;
gdjs.LoginCode.GDLoginButtonObjects2.length = 0;
gdjs.LoginCode.GDLoginButtonObjects3.length = 0;
gdjs.LoginCode.GDLoginButtonObjects4.length = 0;
gdjs.LoginCode.GDExitButtonObjects1.length = 0;
gdjs.LoginCode.GDExitButtonObjects2.length = 0;
gdjs.LoginCode.GDExitButtonObjects3.length = 0;
gdjs.LoginCode.GDExitButtonObjects4.length = 0;
gdjs.LoginCode.GDLoginTextObjects1.length = 0;
gdjs.LoginCode.GDLoginTextObjects2.length = 0;
gdjs.LoginCode.GDLoginTextObjects3.length = 0;
gdjs.LoginCode.GDLoginTextObjects4.length = 0;
gdjs.LoginCode.GDExitTextObjects1.length = 0;
gdjs.LoginCode.GDExitTextObjects2.length = 0;
gdjs.LoginCode.GDExitTextObjects3.length = 0;
gdjs.LoginCode.GDExitTextObjects4.length = 0;
gdjs.LoginCode.GDloadingImgObjects1.length = 0;
gdjs.LoginCode.GDloadingImgObjects2.length = 0;
gdjs.LoginCode.GDloadingImgObjects3.length = 0;
gdjs.LoginCode.GDloadingImgObjects4.length = 0;

gdjs.LoginCode.eventsList14(runtimeScene);

return;

}

gdjs['LoginCode'] = gdjs.LoginCode;
