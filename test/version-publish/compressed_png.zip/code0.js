gdjs.LoginCode = {};
gdjs.LoginCode.GDOkayButtonObjects2_1final = [];

gdjs.LoginCode.GDLoadingScreenObjects1= [];
gdjs.LoginCode.GDLoadingScreenObjects2= [];
gdjs.LoginCode.GDLoadingScreenObjects3= [];
gdjs.LoginCode.GDLoadingScreenObjects4= [];
gdjs.LoginCode.GDLoadingScreenObjects5= [];
gdjs.LoginCode.GDPlayerNameTextObjects1= [];
gdjs.LoginCode.GDPlayerNameTextObjects2= [];
gdjs.LoginCode.GDPlayerNameTextObjects3= [];
gdjs.LoginCode.GDPlayerNameTextObjects4= [];
gdjs.LoginCode.GDPlayerNameTextObjects5= [];
gdjs.LoginCode.GDAvatarsObjects1= [];
gdjs.LoginCode.GDAvatarsObjects2= [];
gdjs.LoginCode.GDAvatarsObjects3= [];
gdjs.LoginCode.GDAvatarsObjects4= [];
gdjs.LoginCode.GDAvatarsObjects5= [];
gdjs.LoginCode.GDPlayerJobTextObjects1= [];
gdjs.LoginCode.GDPlayerJobTextObjects2= [];
gdjs.LoginCode.GDPlayerJobTextObjects3= [];
gdjs.LoginCode.GDPlayerJobTextObjects4= [];
gdjs.LoginCode.GDPlayerJobTextObjects5= [];
gdjs.LoginCode.GDPlayerTypeTextObjects1= [];
gdjs.LoginCode.GDPlayerTypeTextObjects2= [];
gdjs.LoginCode.GDPlayerTypeTextObjects3= [];
gdjs.LoginCode.GDPlayerTypeTextObjects4= [];
gdjs.LoginCode.GDPlayerTypeTextObjects5= [];
gdjs.LoginCode.GDPlayerLevelTextObjects1= [];
gdjs.LoginCode.GDPlayerLevelTextObjects2= [];
gdjs.LoginCode.GDPlayerLevelTextObjects3= [];
gdjs.LoginCode.GDPlayerLevelTextObjects4= [];
gdjs.LoginCode.GDPlayerLevelTextObjects5= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects1= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects2= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects3= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects4= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects5= [];
gdjs.LoginCode.GDStartButtonObjects1= [];
gdjs.LoginCode.GDStartButtonObjects2= [];
gdjs.LoginCode.GDStartButtonObjects3= [];
gdjs.LoginCode.GDStartButtonObjects4= [];
gdjs.LoginCode.GDStartButtonObjects5= [];
gdjs.LoginCode.GDNicknameObjects1= [];
gdjs.LoginCode.GDNicknameObjects2= [];
gdjs.LoginCode.GDNicknameObjects3= [];
gdjs.LoginCode.GDNicknameObjects4= [];
gdjs.LoginCode.GDNicknameObjects5= [];
gdjs.LoginCode.GDLoginButtonObjects1= [];
gdjs.LoginCode.GDLoginButtonObjects2= [];
gdjs.LoginCode.GDLoginButtonObjects3= [];
gdjs.LoginCode.GDLoginButtonObjects4= [];
gdjs.LoginCode.GDLoginButtonObjects5= [];
gdjs.LoginCode.GDExitButtonObjects1= [];
gdjs.LoginCode.GDExitButtonObjects2= [];
gdjs.LoginCode.GDExitButtonObjects3= [];
gdjs.LoginCode.GDExitButtonObjects4= [];
gdjs.LoginCode.GDExitButtonObjects5= [];
gdjs.LoginCode.GDLoginTextObjects1= [];
gdjs.LoginCode.GDLoginTextObjects2= [];
gdjs.LoginCode.GDLoginTextObjects3= [];
gdjs.LoginCode.GDLoginTextObjects4= [];
gdjs.LoginCode.GDLoginTextObjects5= [];
gdjs.LoginCode.GDExitTextObjects1= [];
gdjs.LoginCode.GDExitTextObjects2= [];
gdjs.LoginCode.GDExitTextObjects3= [];
gdjs.LoginCode.GDExitTextObjects4= [];
gdjs.LoginCode.GDExitTextObjects5= [];
gdjs.LoginCode.GDloadingImgObjects1= [];
gdjs.LoginCode.GDloadingImgObjects2= [];
gdjs.LoginCode.GDloadingImgObjects3= [];
gdjs.LoginCode.GDloadingImgObjects4= [];
gdjs.LoginCode.GDloadingImgObjects5= [];
gdjs.LoginCode.GDNewTiledSpriteObjects1= [];
gdjs.LoginCode.GDNewTiledSpriteObjects2= [];
gdjs.LoginCode.GDNewTiledSpriteObjects3= [];
gdjs.LoginCode.GDNewTiledSpriteObjects4= [];
gdjs.LoginCode.GDNewTiledSpriteObjects5= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects1= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects2= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects3= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects4= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects5= [];
gdjs.LoginCode.GDSelectedObjects1= [];
gdjs.LoginCode.GDSelectedObjects2= [];
gdjs.LoginCode.GDSelectedObjects3= [];
gdjs.LoginCode.GDSelectedObjects4= [];
gdjs.LoginCode.GDSelectedObjects5= [];
gdjs.LoginCode.GDCardsBackgroundObjects1= [];
gdjs.LoginCode.GDCardsBackgroundObjects2= [];
gdjs.LoginCode.GDCardsBackgroundObjects3= [];
gdjs.LoginCode.GDCardsBackgroundObjects4= [];
gdjs.LoginCode.GDCardsBackgroundObjects5= [];
gdjs.LoginCode.GDcreateCharacterObjects1= [];
gdjs.LoginCode.GDcreateCharacterObjects2= [];
gdjs.LoginCode.GDcreateCharacterObjects3= [];
gdjs.LoginCode.GDcreateCharacterObjects4= [];
gdjs.LoginCode.GDcreateCharacterObjects5= [];
gdjs.LoginCode.GDdeleteButtonObjects1= [];
gdjs.LoginCode.GDdeleteButtonObjects2= [];
gdjs.LoginCode.GDdeleteButtonObjects3= [];
gdjs.LoginCode.GDdeleteButtonObjects4= [];
gdjs.LoginCode.GDdeleteButtonObjects5= [];
gdjs.LoginCode.GDOkayButtonObjects1= [];
gdjs.LoginCode.GDOkayButtonObjects2= [];
gdjs.LoginCode.GDOkayButtonObjects3= [];
gdjs.LoginCode.GDOkayButtonObjects4= [];
gdjs.LoginCode.GDOkayButtonObjects5= [];
gdjs.LoginCode.GDBackButtonObjects1= [];
gdjs.LoginCode.GDBackButtonObjects2= [];
gdjs.LoginCode.GDBackButtonObjects3= [];
gdjs.LoginCode.GDBackButtonObjects4= [];
gdjs.LoginCode.GDBackButtonObjects5= [];
gdjs.LoginCode.GDCursorsObjects1= [];
gdjs.LoginCode.GDCursorsObjects2= [];
gdjs.LoginCode.GDCursorsObjects3= [];
gdjs.LoginCode.GDCursorsObjects4= [];
gdjs.LoginCode.GDCursorsObjects5= [];
gdjs.LoginCode.GDWarpzoneObjects1= [];
gdjs.LoginCode.GDWarpzoneObjects2= [];
gdjs.LoginCode.GDWarpzoneObjects3= [];
gdjs.LoginCode.GDWarpzoneObjects4= [];
gdjs.LoginCode.GDWarpzoneObjects5= [];
gdjs.LoginCode.GDSpawningPointObjects1= [];
gdjs.LoginCode.GDSpawningPointObjects2= [];
gdjs.LoginCode.GDSpawningPointObjects3= [];
gdjs.LoginCode.GDSpawningPointObjects4= [];
gdjs.LoginCode.GDSpawningPointObjects5= [];
gdjs.LoginCode.GDTransitionObjects1= [];
gdjs.LoginCode.GDTransitionObjects2= [];
gdjs.LoginCode.GDTransitionObjects3= [];
gdjs.LoginCode.GDTransitionObjects4= [];
gdjs.LoginCode.GDTransitionObjects5= [];
gdjs.LoginCode.GDTransparentBackgroundObjects1= [];
gdjs.LoginCode.GDTransparentBackgroundObjects2= [];
gdjs.LoginCode.GDTransparentBackgroundObjects3= [];
gdjs.LoginCode.GDTransparentBackgroundObjects4= [];
gdjs.LoginCode.GDTransparentBackgroundObjects5= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects1= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects2= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects3= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects4= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects5= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects1= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects2= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects3= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects4= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects5= [];
gdjs.LoginCode.GDAnnouncementMaskObjects1= [];
gdjs.LoginCode.GDAnnouncementMaskObjects2= [];
gdjs.LoginCode.GDAnnouncementMaskObjects3= [];
gdjs.LoginCode.GDAnnouncementMaskObjects4= [];
gdjs.LoginCode.GDAnnouncementMaskObjects5= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects1= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects2= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects3= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects4= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects5= [];
gdjs.LoginCode.GDAnnouncementIconObjects1= [];
gdjs.LoginCode.GDAnnouncementIconObjects2= [];
gdjs.LoginCode.GDAnnouncementIconObjects3= [];
gdjs.LoginCode.GDAnnouncementIconObjects4= [];
gdjs.LoginCode.GDAnnouncementIconObjects5= [];


gdjs.LoginCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.LoginCode.GDStartButtonObjects2, gdjs.LoginCode.GDStartButtonObjects3);

gdjs.copyArray(runtimeScene.getObjects("loadingImg"), gdjs.LoginCode.GDloadingImgObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDloadingImgObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDloadingImgObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects3[i].hide(false);
}
}}

}


};gdjs.LoginCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects3);

gdjs.copyArray(runtimeScene.getObjects("loadingImg"), gdjs.LoginCode.GDloadingImgObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDloadingImgObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDloadingImgObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects3[i].hide(false);
}
}}

}


};gdjs.LoginCode.asyncCallback39112228 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LoginCode.GDStartButtonObjects2) asyncObjectsList.addObject("StartButton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.LoginCode.asyncCallback39112228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.userFunc0x16020f0 = function(runtimeScene) {
"use strict";
var a = {
        "GlobalVariables": {
            "Raw": {
                "Exp": 0,
                "TmExp": 0
            },
            "Equipment": {

            },
            "Indicators": {
                "Bonus": {
                    "Exp": 0,
                    "TmExp": 0
                },
                "Exp": 0,
                "Galders": 0,
                "Hp": 420,
                "Lv": 1,
                "Mana": 50,
                "MaxHp": 480,
                "MaxMana": 170,
                "MessageCount": 0,
                "SkillPoints": 0,
                "TmExp": 0,
                "TmLv": 0,
                "Weight": 18
            },
            "DistributedLevels": {
                "charm": 2,
                "magic": 4,
                "power": 1,
                "sense": 3
            },
            "SelectedCharacter": "Dragon",
            "QuestId": "quest1",
            "QuestsDone": {},
            "LearnedSkills": [],
            "ItemObtained": [],
            "ChatMessages": [],
            "AnnouncementMessages": [],
            "NPCStates": {
                "SwampMapLayout": {},
                "TutorialMapLayout": {
                    "dorothy": "Dorothy-0",
                    "gm_eni": "GM_Eni-0",
                    "item_girl": "idle",
                    "magician_sephira": "idle",
                    "pia": "idle",
                    "rosemary": "idle"
                }
            },
            "ShortcutSlots": {
                "F1":{"item":0,"skill":0,"qty":0},
                "F2":{"item":0,"skill":0,"qty":0},
                "F3":{"item":0,"skill":0,"qty":0},
                "F4":{"item":0,"skill":0,"qty":0},
                "F5":{"item":0,"skill":0,"qty":0},
                "F6":{"item":0,"skill":0,"qty":0},
                "F7":{"item":0,"skill":0,"qty":0},
                "F8":{"item":0,"skill":0,"qty":0}
            },
            "SaveData": {
                "CurrentMap": 0,
                "ItemIcons": "0",
                "SkillIcons": "0"
            },
            "BossKills": {},
            "AppliedPoints": {
                "used": 0,
                "basePoints": {}
            },
            "SpawningPointId": "Initial",
            "Type": "magic"
        }
    };

const GlobalVariables = a.GlobalVariables;
for(var i in GlobalVariables) {
    var data = GlobalVariables[i];
    runtimeScene.getGame().getVariables().get(i).fromJSObject(data);
}

if(window.equipmentManager) {
    equipmentManager.reset();
}

// fix chat bug
window.lad = false;
window.retrieveFirstTime = false;

};
gdjs.LoginCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LoadingScreen"), gdjs.LoginCode.GDLoadingScreenObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDLoadingScreenObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoadingScreenObjects2[i].setAnimation(gdjs.randomInRange(0, 1));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide();
}
}
{ //Subevents
gdjs.LoginCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.readStringFromJSONFile("localSession", "guestLogin", runtimeScene, runtimeScene.getScene().getVariables().get("UserName"));
}{runtimeScene.getGame().getVariables().getFromIndex(20).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserName")));
}}

}


{



}


{


gdjs.LoginCode.userFunc0x16020f0(runtimeScene);

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LoginCode.GDNicknameObjects2 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), false);
}{runtimeScene.getGame().getVariables().getFromIndex(20).setString((( gdjs.LoginCode.GDNicknameObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDNicknameObjects2[0].getString()));
}{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrieveUserCards.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(20)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Logging in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


};gdjs.LoginCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Trickster Online - Trickster Online.mp3", 1, true, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
gdjs.copyArray(gdjs.LoginCode.GDStartButtonObjects1, gdjs.LoginCode.GDStartButtonObjects2);

{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].setString("");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(20)) != "0";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(20)));
}
}
{ //Subevents
gdjs.LoginCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("SavedData").getChild("AlreadyHasLogin"), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects1[i].hide(false);
}
}}

}


};gdjs.LoginCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.LoginCode.GDExitButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButtonObjects1Objects = Hashtable.newFrom({"LoginButton": gdjs.LoginCode.GDLoginButtonObjects1});
gdjs.LoginCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.LoginCode.GDNicknameObjects1, gdjs.LoginCode.GDNicknameObjects2);

{gdjs.evtTools.storage.writeStringInJSONFile("localSession", "guestLogin", (( gdjs.LoginCode.GDNicknameObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDNicknameObjects2[0].getString()));
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LoginCode.GDNicknameObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(20).setString((( gdjs.LoginCode.GDNicknameObjects1.length === 0 ) ? "" :gdjs.LoginCode.GDNicknameObjects1[0].getString()));
}{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrieveUserCards.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(20)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Logging in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


};gdjs.LoginCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDNicknameObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDNicknameObjects1[i].getString() != "" ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDNicknameObjects1[k] = gdjs.LoginCode.GDNicknameObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDNicknameObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDAvatarsObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDAvatarsObjects4[i].getVariableNumber(gdjs.LoginCode.GDAvatarsObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDAvatarsObjects4[k] = gdjs.LoginCode.GDAvatarsObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDAvatarsObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDAvatarsObjects4 */
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

{for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects4[i].getBehavior("Animation").setAnimationName(gdjs.evtTools.string.toLowerCase(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("avatar"))));
}
}{for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects4[i].setCenterXInScene((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("avatar")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerNameTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerNameTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerNameTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerNameTextObjects4[k] = gdjs.LoginCode.GDPlayerNameTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerNameTextObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDPlayerNameTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects4[i].setBBText(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("name")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerJobTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerJobTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerJobTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerJobTextObjects4[k] = gdjs.LoginCode.GDPlayerJobTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerJobTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerJobTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects4[i].setBBText(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("job")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerJobTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerTypeTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerTypeTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerTypeTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerTypeTextObjects4[k] = gdjs.LoginCode.GDPlayerTypeTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerTypeTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerTypeTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects4[i].setBBText(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("type")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerTypeTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerLevelTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerLevelTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerLevelTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerLevelTextObjects4[k] = gdjs.LoginCode.GDPlayerLevelTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerLevelTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerLevelTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects4[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("level")));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerLevelTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerGaldersTextObjects3[k] = gdjs.LoginCode.GDPlayerGaldersTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerGaldersTextObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerGaldersTextObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].setBBText("[color=#b36a4c]");
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].setBBText(gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getBBText() + (gdjs.evtsExt__InterfaceFunctions__ConvertToCurrencyFormat.func(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("cardDetails").getChild("galders")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].setBBText(gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getBBText() + ("[/color] G"));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects3[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getWidth()));
}
}}

}


};gdjs.LoginCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerNameTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerNameTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerNameTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerNameTextObjects3[k] = gdjs.LoginCode.GDPlayerNameTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerNameTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerJobTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerJobTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerJobTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerJobTextObjects3[k] = gdjs.LoginCode.GDPlayerJobTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerJobTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerTypeTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerTypeTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerTypeTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerTypeTextObjects3[k] = gdjs.LoginCode.GDPlayerTypeTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerTypeTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerLevelTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerLevelTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerLevelTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerLevelTextObjects3[k] = gdjs.LoginCode.GDPlayerLevelTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerLevelTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerGaldersTextObjects3[k] = gdjs.LoginCode.GDPlayerGaldersTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerGaldersTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDAvatarsObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDAvatarsObjects3[i].getVariableNumber(gdjs.LoginCode.GDAvatarsObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDAvatarsObjects3[k] = gdjs.LoginCode.GDAvatarsObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDAvatarsObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDAvatarsObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerGaldersTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerJobTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerLevelTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerNameTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerTypeTextObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCardsBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCardsBackgroundObjects3[i].getVariableNumber(gdjs.LoginCode.GDCardsBackgroundObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCardsBackgroundObjects3[k] = gdjs.LoginCode.GDCardsBackgroundObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDCardsBackgroundObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDCardsBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDCardsBackgroundObjects3[i].getBehavior("Animation").setAnimationName(gdjs.evtTools.string.toLowerCase(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("type"))));
}
}
{ //Subevents
gdjs.LoginCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList12 = function(runtimeScene) {

{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().get("index");
const valueIteratorReference2 = runtimeScene.getScene().getVariables().get("cardDetails");
const iterableReference2 = runtimeScene.getScene().getVariables().get("UserCards");
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().get("index").add(1);
}
{ //Subevents: 
gdjs.LoginCode.eventsList11(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.LoginCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].getVariableNumber(gdjs.LoginCode.GDSelectedObjects2[i].getVariables().get("id")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDSelectedObjects2 */
{for(var i = 0, len = gdjs.LoginCode.GDSelectedObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDSelectedObjects2[i].getBehavior("Animation").setAnimationName("highlight");
}
}{runtimeScene.getScene().getVariables().get("SelectedCardIndex").setNumber(1);
}{runtimeScene.getScene().getVariables().get("SelectedPlayerName").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("name")));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setString(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("job")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects2);
gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDCardsBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDCardsBackgroundObjects2[i].getBehavior("Animation").setAnimationName("empty");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("UserCards")) > 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), true);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), false);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Character Selection");
}
{ //Subevents
gdjs.LoginCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2Objects = Hashtable.newFrom({"createCharacter": gdjs.LoginCode.GDcreateCharacterObjects2});
gdjs.LoginCode.asyncCallback39073644 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "CharacterCreation", false);
}}
gdjs.LoginCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.LoginCode.asyncCallback39073644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("UserRetrievedCount")) == 3);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "No more slots left!", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("UserRetrievedCount")) < 3);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Character creation...", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2Objects = Hashtable.newFrom({"deleteButton": gdjs.LoginCode.GDdeleteButtonObjects2});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCardsBackgroundObjects2Objects = Hashtable.newFrom({"CardsBackground": gdjs.LoginCode.GDCardsBackgroundObjects2});
gdjs.LoginCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDSelectedObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDSelectedObjects3[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].getVariableNumber(gdjs.LoginCode.GDSelectedObjects2[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDCardsBackgroundObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDCardsBackgroundObjects2[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects2 */
/* Reuse gdjs.LoginCode.GDSelectedObjects2 */
{for(var i = 0, len = gdjs.LoginCode.GDSelectedObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDSelectedObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}{runtimeScene.getScene().getVariables().get("SelectedCardIndex").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDCardsBackgroundObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDCardsBackgroundObjects2[0].getVariables()).get("id"))));
}{runtimeScene.getScene().getVariables().get("SelectedPlayerName").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("name")));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setString(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("job")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDOkayButtonObjects3Objects = Hashtable.newFrom({"OkayButton": gdjs.LoginCode.GDOkayButtonObjects3});
gdjs.LoginCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("UserCards")) <= 0;
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Create a character first!", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")) == "0");
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Select a character first!", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("UserCards")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")) != "0");
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrievePlayerStatsFromServer.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Entering World", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDBackButtonObjects2Objects = Hashtable.newFrom({"BackButton": gdjs.LoginCode.GDBackButtonObjects2});
gdjs.LoginCode.asyncCallback39138812 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.LoginCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.LoginCode.asyncCallback39138812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(21), false);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Under construction", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCardsBackgroundObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.LoginCode.GDOkayButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LoginCode.GDOkayButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("OkayButton"), gdjs.LoginCode.GDOkayButtonObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDOkayButtonObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LoginCode.GDOkayButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LoginCode.GDOkayButtonObjects2_1final.indexOf(gdjs.LoginCode.GDOkayButtonObjects3[j]) === -1 )
            gdjs.LoginCode.GDOkayButtonObjects2_1final.push(gdjs.LoginCode.GDOkayButtonObjects3[j]);
    }
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(21), true);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getOnceTriggers().triggerOnce(39102132);
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.LoginCode.GDOkayButtonObjects2_1final, gdjs.LoginCode.GDOkayButtonObjects2);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackButton"), gdjs.LoginCode.GDBackButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDBackButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Login", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("PlayerRetrieved"), true);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("PlayerRetrieved"), false);
}
{ //Subevents
gdjs.LoginCode.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1Objects = Hashtable.newFrom({"createCharacter": gdjs.LoginCode.GDcreateCharacterObjects1, "deleteButton": gdjs.LoginCode.GDdeleteButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1Objects = Hashtable.newFrom({"createCharacter": gdjs.LoginCode.GDcreateCharacterObjects1, "deleteButton": gdjs.LoginCode.GDdeleteButtonObjects1});
gdjs.LoginCode.mapOfEmptyGDCursorsObjects = Hashtable.newFrom({"Cursors": []});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCursorsObjects1Objects = Hashtable.newFrom({"Cursors": gdjs.LoginCode.GDCursorsObjects1});
gdjs.LoginCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LoginCode.mapOfEmptyGDCursorsObjects) == 0;
if (isConditionTrue_0) {
gdjs.LoginCode.GDCursorsObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCursorsObjects1Objects, 0, 0, "Interface");
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoadingScreenObjects1ObjectsGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"LoadingScreen": gdjs.LoginCode.GDLoadingScreenObjects1, "StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.eventsList24 = function(runtimeScene) {

{

/* Reuse gdjs.LoginCode.GDCursorsObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCursorsObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCursorsObjects1[i].isCurrentAnimationName("Hand") ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCursorsObjects1[k] = gdjs.LoginCode.GDCursorsObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDCursorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCursorsObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Click");
}
}}

}


};gdjs.LoginCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDLoginButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2ObjectsGDgdjs_9546LoginCode_9546GDOkayButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDBackButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDSelectedObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects2, "LoginButton": gdjs.LoginCode.GDLoginButtonObjects2, "deleteButton": gdjs.LoginCode.GDdeleteButtonObjects2, "createCharacter": gdjs.LoginCode.GDcreateCharacterObjects2, "OkayButton": gdjs.LoginCode.GDOkayButtonObjects2, "BackButton": gdjs.LoginCode.GDBackButtonObjects2, "Selected": gdjs.LoginCode.GDSelectedObjects2});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects2Objects = Hashtable.newFrom({"ExitButton": gdjs.LoginCode.GDExitButtonObjects2});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BackButton"), gdjs.LoginCode.GDBackButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("OkayButton"), gdjs.LoginCode.GDOkayButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects2[k] = gdjs.LoginCode.GDStartButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects2[k] = gdjs.LoginCode.GDLoginButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects2[k] = gdjs.LoginCode.GDdeleteButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects2[k] = gdjs.LoginCode.GDcreateCharacterObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDOkayButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDOkayButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDOkayButtonObjects2[k] = gdjs.LoginCode.GDOkayButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDOkayButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDBackButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDBackButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDBackButtonObjects2[k] = gdjs.LoginCode.GDBackButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDBackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDLoginButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2ObjectsGDgdjs_9546LoginCode_9546GDOkayButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDBackButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDSelectedObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDSelectedObjects2.length === 0 ) ? (( gdjs.LoginCode.GDBackButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDOkayButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDcreateCharacterObjects2.length === 0 ) ? (( gdjs.LoginCode.GDdeleteButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDLoginButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDStartButtonObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDStartButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDLoginButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDdeleteButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDcreateCharacterObjects2[0].getLayer()) :gdjs.LoginCode.GDOkayButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDBackButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDSelectedObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects2[k] = gdjs.LoginCode.GDStartButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects2[k] = gdjs.LoginCode.GDLoginButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects2[k] = gdjs.LoginCode.GDdeleteButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects2[k] = gdjs.LoginCode.GDcreateCharacterObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDOkayButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDOkayButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDOkayButtonObjects2[k] = gdjs.LoginCode.GDOkayButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDOkayButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDBackButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDBackButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDBackButtonObjects2[k] = gdjs.LoginCode.GDBackButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDBackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_click.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_create_btnselect.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects2[k] = gdjs.LoginCode.GDExitButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDExitButtonObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDExitButtonObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects2[k] = gdjs.LoginCode.GDExitButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_close.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_open.mp3", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_spinbtn.mp3", false, 100, 1);
}}

}


};gdjs.LoginCode.eventsList27 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText"), gdjs.LoginCode.GDTransparentBackgroundTextObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setCenterPositionInScene((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getCenterXInScene()),(( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setWidth((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getWidth()) + 40);
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setHeight((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getHeight()) + 40);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) != "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText"), gdjs.LoginCode.GDTransparentBackgroundTextObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setY(142);
}
}}

}


};gdjs.LoginCode.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects2);
{/* Mismatched object type - skipped. */}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects2[i].setOpacity(62.5);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList27(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TransparentMessageTimer") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TransparentTextMessageSeconds"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(40939564);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects1[k] = gdjs.LoginCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].setAnimation(1);
}
}
{ //Subevents
gdjs.LoginCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects1[k] = gdjs.LoginCode.GDExitButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDExitButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].hide(false);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects1[k] = gdjs.LoginCode.GDLoginButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Character Selection");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects1[k] = gdjs.LoginCode.GDcreateCharacterObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects1[k] = gdjs.LoginCode.GDdeleteButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDcreateCharacterObjects1 */
/* Reuse gdjs.LoginCode.GDdeleteButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDcreateCharacterObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDcreateCharacterObjects1[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.LoginCode.GDdeleteButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDdeleteButtonObjects1[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects1[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects1[k] = gdjs.LoginCode.GDcreateCharacterObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects1[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects1[k] = gdjs.LoginCode.GDdeleteButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDcreateCharacterObjects1 */
/* Reuse gdjs.LoginCode.GDdeleteButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDcreateCharacterObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDcreateCharacterObjects1[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.LoginCode.GDdeleteButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDdeleteButtonObjects1[i].setAnimationFrame(1);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Attack");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("isOnNpcObject"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("chat");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Blocked");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoadingScreen"), gdjs.LoginCode.GDLoadingScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoadingScreenObjects1ObjectsGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoadingScreenObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoadingScreenObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoadingScreenObjects1[k] = gdjs.LoginCode.GDLoadingScreenObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoadingScreenObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects1[k] = gdjs.LoginCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDStartButtonObjects1.length === 0 ) ? (( gdjs.LoginCode.GDLoadingScreenObjects1.length === 0 ) ? "" :gdjs.LoginCode.GDLoadingScreenObjects1[0].getLayer()) :gdjs.LoginCode.GDStartButtonObjects1[0].getLayer()));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Arrow");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Warp");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("pick");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UsingSkill"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("skill");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Hand");
}
}
{ //Subevents
gdjs.LoginCode.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(40592460);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList26(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList28(runtimeScene);} //End of subevents
}

}


};

gdjs.LoginCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoginCode.GDLoadingScreenObjects1.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects2.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects3.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects4.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects5.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects5.length = 0;
gdjs.LoginCode.GDAvatarsObjects1.length = 0;
gdjs.LoginCode.GDAvatarsObjects2.length = 0;
gdjs.LoginCode.GDAvatarsObjects3.length = 0;
gdjs.LoginCode.GDAvatarsObjects4.length = 0;
gdjs.LoginCode.GDAvatarsObjects5.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects5.length = 0;
gdjs.LoginCode.GDStartButtonObjects1.length = 0;
gdjs.LoginCode.GDStartButtonObjects2.length = 0;
gdjs.LoginCode.GDStartButtonObjects3.length = 0;
gdjs.LoginCode.GDStartButtonObjects4.length = 0;
gdjs.LoginCode.GDStartButtonObjects5.length = 0;
gdjs.LoginCode.GDNicknameObjects1.length = 0;
gdjs.LoginCode.GDNicknameObjects2.length = 0;
gdjs.LoginCode.GDNicknameObjects3.length = 0;
gdjs.LoginCode.GDNicknameObjects4.length = 0;
gdjs.LoginCode.GDNicknameObjects5.length = 0;
gdjs.LoginCode.GDLoginButtonObjects1.length = 0;
gdjs.LoginCode.GDLoginButtonObjects2.length = 0;
gdjs.LoginCode.GDLoginButtonObjects3.length = 0;
gdjs.LoginCode.GDLoginButtonObjects4.length = 0;
gdjs.LoginCode.GDLoginButtonObjects5.length = 0;
gdjs.LoginCode.GDExitButtonObjects1.length = 0;
gdjs.LoginCode.GDExitButtonObjects2.length = 0;
gdjs.LoginCode.GDExitButtonObjects3.length = 0;
gdjs.LoginCode.GDExitButtonObjects4.length = 0;
gdjs.LoginCode.GDExitButtonObjects5.length = 0;
gdjs.LoginCode.GDLoginTextObjects1.length = 0;
gdjs.LoginCode.GDLoginTextObjects2.length = 0;
gdjs.LoginCode.GDLoginTextObjects3.length = 0;
gdjs.LoginCode.GDLoginTextObjects4.length = 0;
gdjs.LoginCode.GDLoginTextObjects5.length = 0;
gdjs.LoginCode.GDExitTextObjects1.length = 0;
gdjs.LoginCode.GDExitTextObjects2.length = 0;
gdjs.LoginCode.GDExitTextObjects3.length = 0;
gdjs.LoginCode.GDExitTextObjects4.length = 0;
gdjs.LoginCode.GDExitTextObjects5.length = 0;
gdjs.LoginCode.GDloadingImgObjects1.length = 0;
gdjs.LoginCode.GDloadingImgObjects2.length = 0;
gdjs.LoginCode.GDloadingImgObjects3.length = 0;
gdjs.LoginCode.GDloadingImgObjects4.length = 0;
gdjs.LoginCode.GDloadingImgObjects5.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects5.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects1.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects2.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects3.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects4.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects5.length = 0;
gdjs.LoginCode.GDSelectedObjects1.length = 0;
gdjs.LoginCode.GDSelectedObjects2.length = 0;
gdjs.LoginCode.GDSelectedObjects3.length = 0;
gdjs.LoginCode.GDSelectedObjects4.length = 0;
gdjs.LoginCode.GDSelectedObjects5.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects1.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects2.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects3.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects4.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects5.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects1.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects2.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects3.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects4.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects5.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects1.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects2.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects3.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects4.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects5.length = 0;
gdjs.LoginCode.GDOkayButtonObjects1.length = 0;
gdjs.LoginCode.GDOkayButtonObjects2.length = 0;
gdjs.LoginCode.GDOkayButtonObjects3.length = 0;
gdjs.LoginCode.GDOkayButtonObjects4.length = 0;
gdjs.LoginCode.GDOkayButtonObjects5.length = 0;
gdjs.LoginCode.GDBackButtonObjects1.length = 0;
gdjs.LoginCode.GDBackButtonObjects2.length = 0;
gdjs.LoginCode.GDBackButtonObjects3.length = 0;
gdjs.LoginCode.GDBackButtonObjects4.length = 0;
gdjs.LoginCode.GDBackButtonObjects5.length = 0;
gdjs.LoginCode.GDCursorsObjects1.length = 0;
gdjs.LoginCode.GDCursorsObjects2.length = 0;
gdjs.LoginCode.GDCursorsObjects3.length = 0;
gdjs.LoginCode.GDCursorsObjects4.length = 0;
gdjs.LoginCode.GDCursorsObjects5.length = 0;
gdjs.LoginCode.GDWarpzoneObjects1.length = 0;
gdjs.LoginCode.GDWarpzoneObjects2.length = 0;
gdjs.LoginCode.GDWarpzoneObjects3.length = 0;
gdjs.LoginCode.GDWarpzoneObjects4.length = 0;
gdjs.LoginCode.GDWarpzoneObjects5.length = 0;
gdjs.LoginCode.GDSpawningPointObjects1.length = 0;
gdjs.LoginCode.GDSpawningPointObjects2.length = 0;
gdjs.LoginCode.GDSpawningPointObjects3.length = 0;
gdjs.LoginCode.GDSpawningPointObjects4.length = 0;
gdjs.LoginCode.GDSpawningPointObjects5.length = 0;
gdjs.LoginCode.GDTransitionObjects1.length = 0;
gdjs.LoginCode.GDTransitionObjects2.length = 0;
gdjs.LoginCode.GDTransitionObjects3.length = 0;
gdjs.LoginCode.GDTransitionObjects4.length = 0;
gdjs.LoginCode.GDTransitionObjects5.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects1.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects2.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects3.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects4.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects5.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects1.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects4.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects5.length = 0;

gdjs.LoginCode.eventsList29(runtimeScene);

return;

}

gdjs['LoginCode'] = gdjs.LoginCode;
