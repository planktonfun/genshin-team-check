        const browserDB         = new BrowserDatabase("gameCacheDB", "games");
        const cacheKey          = 'trickster-online';
        const useDownloadCache  = false; // only for testing 
        const folderPath        = 'test/version-diff/latest/'; // Replace with your specific folder path

        async function startUpdate () {
            const repoOwner         = 'planktonfun'; // Replace with the repo owner's username
            const repoName          = 'genshin-team-check'; // Replace with the repository name
            const branchName        = 'main'; // Replace with the repository name
            const token             = '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'; // Replace with your personal access token
            const versionURL        = 'https://raw.githubusercontent.com/planktonfun/genshin-team-check/main/test/version-diff/versions.json';
            const zipFileURL        = 'https://raw.githubusercontent.com/planktonfun/genshin-team-check/main/test/version-diff/latest.zip';
            // const zipFileURL        = './compressed_png.zip'; // only for testing 

            await browserDB.openConnection();

            function bytesToMB(bytes) {
                return (bytes / (1024 * 1024)).toFixed(2);
            }

            async function loadCurrent() {
                var b = await browserDB.getDataById(cacheKey);
                var a = (!b) ? {files:[]} : b.data;

                return a;
            }

            async function updateCurrent(version, fileNames) {
                current = {version, files: fileNames};

                await browserDB.setDataById(cacheKey, current);
            }

            function displayOutput(output) {
                document.getElementById('progress-size').innerText = output;
            }


            let currentCommit = ""; //document.getElementById('currentCommit').value.trim(); // Replace with the head commit SHA
            let targetCommit  = ""; //document.getElementById('targetCommit').value.trim(); // Replace with the head commit SHA

            console.time('Loading Current');
            let current = await loadCurrent();
            // displayOutput(current.files.length);
            console.timeEnd('Loading Current');

            const fetchFromGit = async (url) => {
                const response = await fetch(url, {
                    headers: {
                        'Authorization': `token ${token}`,
                        'Accept': 'application/vnd.github.v3+json'
                    }
                });
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            };

            async function loadTheZipBlob(zipBlob) {
                return new Promise((resolve, reject) =>{
                    // Create a new JSZip instance
                    const zip = new JSZip();

                    // Use FileReader to read the Blob as an array buffer
                    const reader = new FileReader();

                    reader.onload = function () {
                      const arrayBuffer = reader.result;

                      // Load the zip file into JSZip
                      zip.loadAsync(arrayBuffer)
                        .then(function (zipContents) {

                          // Loop through each file in the zip
                          resolve(zipContents);
                        })
                        .catch(function (error) {
                          console.error(error);
                        });
                    };

                    // Read the Blob as an array buffer
                    reader.readAsArrayBuffer(zipBlob);
                })
            }

            async function loadTheZipFromUrl(zipFileUrl, isCache=false) {

                const cache = await caches.open(cacheKey);

                async function retrieveCache() {
                    try {
                        const cachedResponse = await cache.match(zipFileUrl);

                        if (useDownloadCache && cachedResponse) {
                            document.getElementById('progress-bar').style.width = '100%';
                            document.getElementById('progress-size').innerText = `Checking version...`;
                            return await cachedResponse.blob();
                        }

                        return false;

                    } catch (error) {
                        console.error(error);
                        return false;
                    }
                }

                async function finish(blob) {
                    const list = [];
                    const files = await loadTheZipBlob(blob)

                    files.forEach((path, data)=>list.push([folderPath + path.replace("latest/", ""), data]))

                    return list;
                }

                const cacheBlob = await retrieveCache();

                if(cacheBlob) {
                    return await finish(cacheBlob);
                } else if(!cacheBlob)
                    return new Promise((resolve, reject) =>{

                        const xhr = new XMLHttpRequest();

                        xhr.onprogress = function (event) {
                            // if (event.lengthComputable) {
                            //     const percentComplete = (event.loaded / event.total) * 100;
                            //     console.log(percentComplete.toFixed(2) + '%')
                            // }

                            if (event.lengthComputable) {
                                const percentComplete = (event.loaded / event.total) * 100;
                                document.getElementById('progress-bar').style.width = percentComplete + '%';
                                document.getElementById('progress-size').innerText = `Updating version... ${bytesToMB(event.loaded)} MB / ${bytesToMB(event.total)} MB`;
                            }
                        };

                        // Set up event listeners
                        xhr.addEventListener('load', async function () {
                          if (xhr.status === 200) {
                            // The request was successful
                            const blob = xhr.response;

                            // save into cache
                            if(useDownloadCache) await cache.put(zipFileUrl, new Response(blob));

                            resolve(await finish(blob));

                          } else {
                            // Handle errors here, e.g., show an error message
                            console.error('Failed to download the zip file');
                          }
                        });

                        xhr.addEventListener('error', function () {
                          // Handle network errors here
                          console.error('Network error occurred');
                        });

                        xhr.open('GET', zipFileUrl);
                        xhr.responseType = 'blob'; // Set the response type to Blob
                        xhr.send();
                    });
            }

            function getVersion(url) {
                return new Promise((resolve, reject)=>{
                    fetchCache(url)
                      .then((response) => {
                        if (!response.ok) {
                          reject(`HTTP error! Status: ${response.status}`);
                        }

                        resolve(response.text());
                      })
                });
            }

            // Step 1: Convert Data URL to Blob
            function dataUrlToBlobUrl(dataUrl) {
                const byteString = atob(dataUrl.split(',')[1]); // Decode base64
                const mimeString = dataUrl.split(',')[0].split(':')[1].split(';')[0]; // Extract MIME type

                // Create an ArrayBuffer and fill it with the byte data
                const arrayBuffer = new ArrayBuffer(byteString.length);
                const uintArray = new Uint8Array(arrayBuffer);

                for (let i = 0; i < byteString.length; i++) {
                    uintArray[i] = byteString.charCodeAt(i);
                }

                // Return the Blob
                const fileBlob = new Blob([arrayBuffer], { type: mimeString });

                return URL.createObjectURL(fileBlob);
            }


            // Convert Blob to Base64 using async/await
            async function blobToBase64(blob) {
              const reader = new FileReader();
              return new Promise((resolve, reject) => {
                reader.onloadend = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(blob);
              });
            }

            // Example: Create a Blob and store it in localStorage with MIME type
            async function storeBlob(blob) {
              const base64Data = blob; //await blobToBase64(blob);  // Wait for Blob to be converted to Base64
              const mimeType = blob.type;  // Get the MIME type
              const blobData = { base64Data, mimeType }; //JSON.stringify({ base64Data, mimeType });  // Store Base64 and MIME type as JSON string
              return blobData;
            }

            async function updateCurrentVersion(updated, persist = false, persistTotalSize=0) {

                let currentTemp = (persist) ? current : JSON.parse(JSON.stringify(current))

                // Create a map of the updated files by filename
                const updatedMap = new Map(updated.files.map(file => [file.filename, file]));
                let totalSize = 0;
                let toOverwrite = [];
                let persistSize = 0;

                // Update current files and remove those not in updated
                currentTemp.files = currentTemp.files.filter(file => {
                  if (updatedMap.has(file.filename)) {
                    const updatedFile = updatedMap.get(file.filename);

                    if (file.sha !== updatedFile.sha) {
                      // Update the current file with properties from updated, but keep the filename
                      file.raw_url = updatedFile.raw_url; // Add new property
                      file.sha = updatedFile.sha; // Update sha
                      file.size = updatedFile.size; // Update size

                      toOverwrite.push(file.filename);

                      totalSize += file.size;
                    }
                    return true; // Keep the file
                  }
                  if(persist) console.log('remove file: ', file.filename);
                  return false; // Remove the file
                });


                currentTemp.files = await Promise.all(
                    currentTemp.files.map(async (file)=>{

                        if(persist && toOverwrite.includes(file.filename)) {
                            console.log('overwrite file: ', file.filename);
                            const fileBlob = await getFileAsBlobCache(file.raw_url);
                            file.b64 = await storeBlob(fileBlob);

                            persistSize+=file.size;
                            document.getElementById('progress-bar').style.width = (persistSize/persistTotalSize*100).toFixed(2) + '%';
                            document.getElementById('progress-size').innerText = `File updates... ${bytesToMB(persistSize)} MB / ${bytesToMB(persistTotalSize)} MB`;
                        }

                        delete file.raw_url;

                        return file;
                    })
                );

                // Add new files from updated that are not in current
                await Promise.all(updated.files.map(async (updatedFile) => {
                    if (!currentTemp.files.some(file => file.filename === updatedFile.filename)) {
                        totalSize += updatedFile.size;

                        if (persist) {
                            console.log('add file: ', updatedFile.filename);
                            const fileBlob = await getFileAsBlobCache(updatedFile.raw_url);

                            currentTemp.files.push({
                                filename: updatedFile.filename,
                                sha: updatedFile.sha,
                                b64: await storeBlob(fileBlob),
                                size: updatedFile.size
                            });

                            persistSize+=updatedFile.size;
                            document.getElementById('progress-bar').style.width = (persistSize/persistTotalSize*100).toFixed(2) + '%';
                            document.getElementById('progress-size').innerText = `File updates... ${bytesToMB(persistSize)} MB / ${bytesToMB(persistTotalSize)} MB`;
                        } else {
                            currentTemp.files.push({
                                filename: updatedFile.filename,
                                sha: updatedFile.sha,
                                size: updatedFile.size
                            });
                        }
                    }
                }));

                // Update the version
                currentTemp.version = updated.version;

                if(persist) {
                    await updateCurrent(currentTemp.version, currentTemp.files)
                }

                return totalSize;
            }

            async function cachedProcess(zipFileUrl, versionUrl) {

                try {

                    console.time('DownloadZip')
                    const version = JSON.parse(await getVersion(versionUrl)) || {};
                    const list    = await loadTheZipFromUrl(zipFileUrl);
                    console.timeEnd('DownloadZip')

                    const eventTotal = list.length;
                    let eventLoaded = 0;

                    console.time('loadZipFiles')
                    const fileNames = await Promise.all(
                        list.map(async (file) => {

                            const fileBlob = await file[1].async('blob');

                            const response = {
                                filename: file[0],
                                sha: await generateGitHubSHA1(fileBlob),
                                size: fileBlob.size,
                                // obj: `<img src=${URL.createObjectURL(fileBlob)} width=50 height=50 />`,
                                b64: await storeBlob(fileBlob),
                            };

                            eventLoaded++;
                            const percentComplete = ((eventLoaded / eventTotal) * 100).toFixed(2);
                            // console.log(percentComplete + '%')

                            document.getElementById('progress-bar').style.width = percentComplete + '%';
                            document.getElementById('progress-size').innerText = `Integrity check... ${eventLoaded} / ${eventTotal}`;
                            return response;
                        })
                    );
                    console.timeEnd('loadZipFiles')
                    console.log({fileNames})
                    await updateCurrent(version.zipSHA, fileNames);

                    // displayOutput(JSON.stringify(current, null, 2));
                    // displayOutput(current.files.length);

                } catch(err) {
                    console.log(err);
                }
            }

            // get latest data
            async function fetchZip( ) {
                await cachedProcess(zipFileURL, versionURL);
            }

            async function fetchUpdate( ) {

                document.getElementById('progress-bar').style.width = '100%';
                document.getElementById('progress-size').innerText = `Checking version...`;

                // fresh copy get initial download
                if(current.files.length == 0) {
                    await fetchZip();
                }

                // document.getElementById('currentCommit').value = current.version;
                // document.getElementById('targetCommit').value  = 'HEAD';
                currentCommit = current.version;
                targetCommit  = 'HEAD';

                await fetchLatest();

                console.log('update done');
            }

            async function fetchGitCache(url) {
                try {
                    const cache = await caches.open(cacheKey);
                    const cachedResponse = await cache.match(url);

                    if (!useDownloadCache || !cachedResponse) {
                        const response = await fetch(url, {
                            headers: {
                                'Authorization': `token ${token}`,
                                'Accept': 'application/vnd.github.v3+json'
                            }
                        });
                        if(useDownloadCache) {
                            await cache.put(url, response);
                            const a = await cache.match(url);
                            return await a.json();
                        } else {
                            return await response.json();
                        }
                    }

                    return cachedResponse.json();
                } catch (error) {
                    console.log(error);
                }
            }

            async function fetchCache(url) {
                try {
                    const cache = await caches.open(cacheKey);
                    const cachedResponse = await cache.match(url);

                    if (!useDownloadCache || !cachedResponse) {
                        const response = await fetch(url);

                        if(useDownloadCache) {
                            await cache.put(url, response);
                            return await cache.match(url);
                        } else {
                            return response;
                        }
                    }

                    return cachedResponse;
                } catch (error) {
                    console.log(error);
                }
            }

            function getGithubRawUrl(filePath) {
                return `https://raw.githubusercontent.com/${repoOwner}/${repoName}/${branchName}/${filePath}`;
            }

            function getFileAsBlobCache(fileUrl) {
                return new Promise((resolve, reject)=>{
                    fetchCache(fileUrl)
                      .then((response) => {
                        if (!response.ok) {
                          reject(`HTTP error! Status: ${response.status}`);
                        }

                        resolve(response.blob());
                      })
                });
            }
            function getFileAsBlob(fileUrl) {
                return new Promise((resolve, reject)=>{
                    const myRequest = new Request(fileUrl);

                    fetch(myRequest)
                      .then((response) => {
                        if (!response.ok) {
                          reject(`HTTP error! Status: ${response.status}`);
                        }

                        resolve(response.blob());
                      })
                });
            }

            async function fetchLatest( ) {
                displayOutput('Fetching latest.. 1%')
                // document.getElementById('targetCommit').value = "HEAD";

                // currentCommit = document.getElementById('currentCommit').value.trim();
                // targetCommit = document.getElementById('targetCommit').value.trim();

                const url = `https://api.github.com/repos/${repoOwner}/${repoName}/git/trees/main?recursive=1`;

                try {
                    const version = JSON.parse(await getVersion(versionURL)) || {};
                    const zipSize = version.size;

                    console.log({zipSize: bytesToMB(zipSize) + ' MB'});
                    displayOutput('Fetching latest.. 33%')
                    const tree = await fetchGitCache(url);
                    const data = tree.tree.filter(f=>f.path.startsWith(folderPath));

                    const latest = await fetchGitCache(`https://api.github.com/repos/${repoOwner}/${repoName}/commits?per_page=1&page=1`);

                    currentCommit = latest[0].sha;
                    targetCommit  = latest[0].sha;

                    console.log({data, currentCommit, latest});
                    displayOutput('Fetching latest.. 45%')
                    // document.getElementById('currentCommit').value = currentCommit;
                    // document.getElementById('targetCommit').value = targetCommit;

                    const fileNames = data.map((file) =>{
                        return {
                            filename: file.path,
                            raw_url: getGithubRawUrl(file.path),
                            sha:file.sha,
                            size:file.size
                        }
                    });

                    // simulate changes
                    const totalChangeSize = await updateCurrentVersion({version: latest[0].sha, files: fileNames}, false);

                    if(totalChangeSize==0) {
                        displayOutput(`Already latest`)
                    } else {
                        console.log('updating by delta', bytesToMB(totalChangeSize) + ' MB')
                        await updateCurrentVersion({version: latest[0].sha, files: fileNames}, true, totalChangeSize);
                        console.log('update done')
                    }

                    // apply changes
                    // if(totalChangeSize < zipSize) {
                    // } else {
                    //     console.log('updating by zip', zipSize)
                    //     fetchZip( );
                    //     return;
                    // }

                    // displayOutput(current.files.length);
                } catch (error) {
                    console.error('Error fetching commits:', error);
                    displayOutput('Error fetching commits: ' + error.message);
                }
            }

            async function generateGitHubSHA1(fileBlob) {
                // Step 1: Convert Blob to ArrayBuffer
                const arrayBuffer = await fileBlob.arrayBuffer();
                const fileSize = fileBlob.size;

                // Step 2: Create a Git object header: "blob <size>\0"
                const encoder = new TextEncoder();
                const header = encoder.encode(`blob ${fileSize}\0`);

                // Step 3: Concatenate header and file content
                const combined = new Uint8Array(header.length + arrayBuffer.byteLength);
                combined.set(header, 0);
                combined.set(new Uint8Array(arrayBuffer), header.length);

                // Step 4: Compute SHA-1 hash of the combined content
                const hashBuffer = await crypto.subtle.digest('SHA-1', combined);

                // Step 5: Convert ArrayBuffer to hexadecimal string
                const hashArray = Array.from(new Uint8Array(hashBuffer));
                const hashHex = hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');

                // Step 6: Display the result
                return hashHex;
            }

            // document.getElementById('fetchZip').addEventListener('click', () => {
            //     fetchZip( );
            // });

            // document.getElementById('fetchUpdate').addEventListener('click', () => {
            //     fetchUpdate( );
            // });

            await fetchUpdate( );

            return current;
        }

        async function startDownloadTwo() {
            const fileList = await startUpdate();

            document.getElementById('progress-bar2').style.width = '0.01%';
            document.getElementById('progress-percent').innerText = `Extracting 0.01 %`;

            fileList.files = fileList.files.map(f=>{
                f.filename = f.filename.replace(folderPath, '');
                return f;
            });

            console.log(fileList);

            setTimeout(()=>{
                loadFromCurrent(fileList.files)
            }, 300);
        };