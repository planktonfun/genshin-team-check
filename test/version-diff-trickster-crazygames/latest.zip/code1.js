gdjs.CharacterCreationCode = {};
gdjs.CharacterCreationCode.forEachCount0_4 = 0;

gdjs.CharacterCreationCode.forEachCount1_4 = 0;

gdjs.CharacterCreationCode.forEachCount2_4 = 0;

gdjs.CharacterCreationCode.forEachCount3_4 = 0;

gdjs.CharacterCreationCode.forEachCount4_4 = 0;

gdjs.CharacterCreationCode.forEachCount5_4 = 0;

gdjs.CharacterCreationCode.forEachCount6_4 = 0;

gdjs.CharacterCreationCode.forEachCount7_4 = 0;

gdjs.CharacterCreationCode.forEachCount8_4 = 0;

gdjs.CharacterCreationCode.forEachIndex3 = 0;

gdjs.CharacterCreationCode.forEachIndex4 = 0;

gdjs.CharacterCreationCode.forEachObjects3 = [];

gdjs.CharacterCreationCode.forEachObjects4 = [];

gdjs.CharacterCreationCode.forEachTemporary3 = null;

gdjs.CharacterCreationCode.forEachTemporary4 = null;

gdjs.CharacterCreationCode.forEachTotalCount3 = 0;

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;

gdjs.CharacterCreationCode.GDGuideObjects1= [];
gdjs.CharacterCreationCode.GDGuideObjects2= [];
gdjs.CharacterCreationCode.GDGuideObjects3= [];
gdjs.CharacterCreationCode.GDGuideObjects4= [];
gdjs.CharacterCreationCode.GDGuideObjects5= [];
gdjs.CharacterCreationCode.GDGuideObjects6= [];
gdjs.CharacterCreationCode.GDGuideObjects7= [];
gdjs.CharacterCreationCode.GDleftObjects1= [];
gdjs.CharacterCreationCode.GDleftObjects2= [];
gdjs.CharacterCreationCode.GDleftObjects3= [];
gdjs.CharacterCreationCode.GDleftObjects4= [];
gdjs.CharacterCreationCode.GDleftObjects5= [];
gdjs.CharacterCreationCode.GDleftObjects6= [];
gdjs.CharacterCreationCode.GDleftObjects7= [];
gdjs.CharacterCreationCode.GDleftupObjects1= [];
gdjs.CharacterCreationCode.GDleftupObjects2= [];
gdjs.CharacterCreationCode.GDleftupObjects3= [];
gdjs.CharacterCreationCode.GDleftupObjects4= [];
gdjs.CharacterCreationCode.GDleftupObjects5= [];
gdjs.CharacterCreationCode.GDleftupObjects6= [];
gdjs.CharacterCreationCode.GDleftupObjects7= [];
gdjs.CharacterCreationCode.GDmiddleObjects1= [];
gdjs.CharacterCreationCode.GDmiddleObjects2= [];
gdjs.CharacterCreationCode.GDmiddleObjects3= [];
gdjs.CharacterCreationCode.GDmiddleObjects4= [];
gdjs.CharacterCreationCode.GDmiddleObjects5= [];
gdjs.CharacterCreationCode.GDmiddleObjects6= [];
gdjs.CharacterCreationCode.GDmiddleObjects7= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects1= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects2= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects3= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects4= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects5= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects6= [];
gdjs.CharacterCreationCode.GDlowerLeftObjects7= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects1= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects2= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects3= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects4= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects5= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects6= [];
gdjs.CharacterCreationCode.GDpanelTitleObjects7= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects1= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects2= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects3= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects4= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects5= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects6= [];
gdjs.CharacterCreationCode.GDpanelSubTitleObjects7= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects1= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects2= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects3= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects4= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects5= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects6= [];
gdjs.CharacterCreationCode.GDpanelDescriptionObjects7= [];
gdjs.CharacterCreationCode.GDrightupObjects1= [];
gdjs.CharacterCreationCode.GDrightupObjects2= [];
gdjs.CharacterCreationCode.GDrightupObjects3= [];
gdjs.CharacterCreationCode.GDrightupObjects4= [];
gdjs.CharacterCreationCode.GDrightupObjects5= [];
gdjs.CharacterCreationCode.GDrightupObjects6= [];
gdjs.CharacterCreationCode.GDrightupObjects7= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects1= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects2= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects3= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects4= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects5= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects6= [];
gdjs.CharacterCreationCode.GDrightUpText1Objects7= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects1= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects2= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects3= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects4= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects5= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects6= [];
gdjs.CharacterCreationCode.GDrightUpText2Objects7= [];
gdjs.CharacterCreationCode.GDrightupInputObjects1= [];
gdjs.CharacterCreationCode.GDrightupInputObjects2= [];
gdjs.CharacterCreationCode.GDrightupInputObjects3= [];
gdjs.CharacterCreationCode.GDrightupInputObjects4= [];
gdjs.CharacterCreationCode.GDrightupInputObjects5= [];
gdjs.CharacterCreationCode.GDrightupInputObjects6= [];
gdjs.CharacterCreationCode.GDrightupInputObjects7= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects1= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects2= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects3= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects4= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects5= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects6= [];
gdjs.CharacterCreationCode.GDrightmiddleObjects7= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects1= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects2= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects3= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects4= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects5= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects6= [];
gdjs.CharacterCreationCode.GDcreateButtonObjects7= [];
gdjs.CharacterCreationCode.GDbackButtonObjects1= [];
gdjs.CharacterCreationCode.GDbackButtonObjects2= [];
gdjs.CharacterCreationCode.GDbackButtonObjects3= [];
gdjs.CharacterCreationCode.GDbackButtonObjects4= [];
gdjs.CharacterCreationCode.GDbackButtonObjects5= [];
gdjs.CharacterCreationCode.GDbackButtonObjects6= [];
gdjs.CharacterCreationCode.GDbackButtonObjects7= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects2= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects3= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects4= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects5= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects6= [];
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects7= [];
gdjs.CharacterCreationCode.GDiconsObjects1= [];
gdjs.CharacterCreationCode.GDiconsObjects2= [];
gdjs.CharacterCreationCode.GDiconsObjects3= [];
gdjs.CharacterCreationCode.GDiconsObjects4= [];
gdjs.CharacterCreationCode.GDiconsObjects5= [];
gdjs.CharacterCreationCode.GDiconsObjects6= [];
gdjs.CharacterCreationCode.GDiconsObjects7= [];
gdjs.CharacterCreationCode.GDBadgesObjects1= [];
gdjs.CharacterCreationCode.GDBadgesObjects2= [];
gdjs.CharacterCreationCode.GDBadgesObjects3= [];
gdjs.CharacterCreationCode.GDBadgesObjects4= [];
gdjs.CharacterCreationCode.GDBadgesObjects5= [];
gdjs.CharacterCreationCode.GDBadgesObjects6= [];
gdjs.CharacterCreationCode.GDBadgesObjects7= [];
gdjs.CharacterCreationCode.GDArrowsObjects1= [];
gdjs.CharacterCreationCode.GDArrowsObjects2= [];
gdjs.CharacterCreationCode.GDArrowsObjects3= [];
gdjs.CharacterCreationCode.GDArrowsObjects4= [];
gdjs.CharacterCreationCode.GDArrowsObjects5= [];
gdjs.CharacterCreationCode.GDArrowsObjects6= [];
gdjs.CharacterCreationCode.GDArrowsObjects7= [];
gdjs.CharacterCreationCode.GDnumbersObjects1= [];
gdjs.CharacterCreationCode.GDnumbersObjects2= [];
gdjs.CharacterCreationCode.GDnumbersObjects3= [];
gdjs.CharacterCreationCode.GDnumbersObjects4= [];
gdjs.CharacterCreationCode.GDnumbersObjects5= [];
gdjs.CharacterCreationCode.GDnumbersObjects6= [];
gdjs.CharacterCreationCode.GDnumbersObjects7= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects1= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects2= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects3= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects4= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects5= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects6= [];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects7= [];
gdjs.CharacterCreationCode.GDundoObjects1= [];
gdjs.CharacterCreationCode.GDundoObjects2= [];
gdjs.CharacterCreationCode.GDundoObjects3= [];
gdjs.CharacterCreationCode.GDundoObjects4= [];
gdjs.CharacterCreationCode.GDundoObjects5= [];
gdjs.CharacterCreationCode.GDundoObjects6= [];
gdjs.CharacterCreationCode.GDundoObjects7= [];
gdjs.CharacterCreationCode.GDdyesObjects1= [];
gdjs.CharacterCreationCode.GDdyesObjects2= [];
gdjs.CharacterCreationCode.GDdyesObjects3= [];
gdjs.CharacterCreationCode.GDdyesObjects4= [];
gdjs.CharacterCreationCode.GDdyesObjects5= [];
gdjs.CharacterCreationCode.GDdyesObjects6= [];
gdjs.CharacterCreationCode.GDdyesObjects7= [];
gdjs.CharacterCreationCode.GDAvatarsObjects1= [];
gdjs.CharacterCreationCode.GDAvatarsObjects2= [];
gdjs.CharacterCreationCode.GDAvatarsObjects3= [];
gdjs.CharacterCreationCode.GDAvatarsObjects4= [];
gdjs.CharacterCreationCode.GDAvatarsObjects5= [];
gdjs.CharacterCreationCode.GDAvatarsObjects6= [];
gdjs.CharacterCreationCode.GDAvatarsObjects7= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects1= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects2= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects3= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects4= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects5= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects6= [];
gdjs.CharacterCreationCode.GDhoverInfoObjects7= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects1= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects2= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects3= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects4= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects5= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects6= [];
gdjs.CharacterCreationCode.GDhoverTriggerObjects7= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects2= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects3= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects4= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects5= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects6= [];
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects7= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects2= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects3= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects4= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects5= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects6= [];
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects7= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects2= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects3= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects4= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects5= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects6= [];
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects7= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects2= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects3= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects4= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects5= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects6= [];
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects7= [];
gdjs.CharacterCreationCode.GDCursorsObjects1= [];
gdjs.CharacterCreationCode.GDCursorsObjects2= [];
gdjs.CharacterCreationCode.GDCursorsObjects3= [];
gdjs.CharacterCreationCode.GDCursorsObjects4= [];
gdjs.CharacterCreationCode.GDCursorsObjects5= [];
gdjs.CharacterCreationCode.GDCursorsObjects6= [];
gdjs.CharacterCreationCode.GDCursorsObjects7= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects1= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects2= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects3= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects4= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects5= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects6= [];
gdjs.CharacterCreationCode.GDWarpzoneObjects7= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects1= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects2= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects3= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects4= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects5= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects6= [];
gdjs.CharacterCreationCode.GDSpawningPointObjects7= [];
gdjs.CharacterCreationCode.GDTransitionObjects1= [];
gdjs.CharacterCreationCode.GDTransitionObjects2= [];
gdjs.CharacterCreationCode.GDTransitionObjects3= [];
gdjs.CharacterCreationCode.GDTransitionObjects4= [];
gdjs.CharacterCreationCode.GDTransitionObjects5= [];
gdjs.CharacterCreationCode.GDTransitionObjects6= [];
gdjs.CharacterCreationCode.GDTransitionObjects7= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects1= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects4= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects5= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects6= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects7= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects1= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects2= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects3= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects4= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects5= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects6= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects7= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects1= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects2= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects3= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects4= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects5= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects6= [];
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects7= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects1= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects2= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects3= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects4= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects5= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects6= [];
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects7= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects1= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects2= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects3= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects4= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects5= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects6= [];
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects7= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects1= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects2= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects3= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects4= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects5= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects6= [];
gdjs.CharacterCreationCode.GDAnnouncementIconObjects7= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects1= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects2= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects4= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects5= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects6= [];
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects7= [];


gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects = Hashtable.newFrom({"rightup": gdjs.CharacterCreationCode.GDrightupObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightUpText1Objects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightUpText2Objects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightupInputObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDdyesObjects4Objects = Hashtable.newFrom({"rightUpText1": gdjs.CharacterCreationCode.GDrightUpText1Objects4, "rightUpText2": gdjs.CharacterCreationCode.GDrightUpText2Objects4, "rightupInput": gdjs.CharacterCreationCode.GDrightupInputObjects4, "undo": gdjs.CharacterCreationCode.GDundoObjects4, "dyes": gdjs.CharacterCreationCode.GDdyesObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects = Hashtable.newFrom({"rightup": gdjs.CharacterCreationCode.GDrightupObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects = Hashtable.newFrom({"rightup": gdjs.CharacterCreationCode.GDrightupObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects = Hashtable.newFrom({"rightup": gdjs.CharacterCreationCode.GDrightupObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects = Hashtable.newFrom({"rightup": gdjs.CharacterCreationCode.GDrightupObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects = Hashtable.newFrom({"rightup": gdjs.CharacterCreationCode.GDrightupObjects4});
gdjs.CharacterCreationCode.eventsList0 = function(runtimeScene) {

};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects = Hashtable.newFrom({"rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightMiddleTextObjects4Objects = Hashtable.newFrom({"rightMiddleText": gdjs.CharacterCreationCode.GDrightMiddleTextObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects = Hashtable.newFrom({"rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects4});
gdjs.CharacterCreationCode.eventsList1 = function(runtimeScene) {

};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects = Hashtable.newFrom({"rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDnumbersObjects4Objects = Hashtable.newFrom({"numbers": gdjs.CharacterCreationCode.GDnumbersObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects = Hashtable.newFrom({"rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects4});
gdjs.CharacterCreationCode.eventsList2 = function(runtimeScene) {

};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects4Objects = Hashtable.newFrom({"Arrows": gdjs.CharacterCreationCode.GDArrowsObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects = Hashtable.newFrom({"rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects = Hashtable.newFrom({"rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects4});
gdjs.CharacterCreationCode.eventsList3 = function(runtimeScene) {

};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects = Hashtable.newFrom({"lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDBadgesObjects4Objects = Hashtable.newFrom({"Badges": gdjs.CharacterCreationCode.GDBadgesObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects = Hashtable.newFrom({"lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects4});
gdjs.CharacterCreationCode.eventsList4 = function(runtimeScene) {

};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects = Hashtable.newFrom({"lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDpanelTitleObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDpanelSubTitleObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDpanelDescriptionObjects4Objects = Hashtable.newFrom({"panelTitle": gdjs.CharacterCreationCode.GDpanelTitleObjects4, "panelSubTitle": gdjs.CharacterCreationCode.GDpanelSubTitleObjects4, "panelDescription": gdjs.CharacterCreationCode.GDpanelDescriptionObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects = Hashtable.newFrom({"lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects = Hashtable.newFrom({"lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects = Hashtable.newFrom({"lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects4});
gdjs.CharacterCreationCode.eventsList5 = function(runtimeScene) {

};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDleftupObjects4Objects = Hashtable.newFrom({"leftup": gdjs.CharacterCreationCode.GDleftupObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects4Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects4});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDleftupObjects4Objects = Hashtable.newFrom({"leftup": gdjs.CharacterCreationCode.GDleftupObjects4});
gdjs.CharacterCreationCode.eventsList6 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList7 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList8 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList9 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList10 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList11 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList12 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList13 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList14 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.CharacterCreationCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("255;255;255", 1, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dyes"), gdjs.CharacterCreationCode.GDdyesObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightUpText1"), gdjs.CharacterCreationCode.GDrightUpText1Objects3);
gdjs.copyArray(runtimeScene.getObjects("rightUpText2"), gdjs.CharacterCreationCode.GDrightUpText2Objects3);
gdjs.copyArray(runtimeScene.getObjects("rightupInput"), gdjs.CharacterCreationCode.GDrightupInputObjects3);
gdjs.copyArray(runtimeScene.getObjects("undo"), gdjs.CharacterCreationCode.GDundoObjects3);

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;
gdjs.CharacterCreationCode.forEachObjects4.length = 0;
gdjs.CharacterCreationCode.forEachCount0_4 = gdjs.CharacterCreationCode.GDrightUpText1Objects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount0_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightUpText1Objects3);
gdjs.CharacterCreationCode.forEachCount1_4 = gdjs.CharacterCreationCode.GDrightUpText2Objects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount1_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightUpText2Objects3);
gdjs.CharacterCreationCode.forEachCount2_4 = gdjs.CharacterCreationCode.GDrightupInputObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount2_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightupInputObjects3);
gdjs.CharacterCreationCode.forEachCount3_4 = gdjs.CharacterCreationCode.GDundoObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount3_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDundoObjects3);
gdjs.CharacterCreationCode.forEachCount4_4 = gdjs.CharacterCreationCode.GDdyesObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount4_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDdyesObjects3);
for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachTotalCount4;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("rightup"), gdjs.CharacterCreationCode.GDrightupObjects4);
gdjs.CharacterCreationCode.GDdyesObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightUpText1Objects4.length = 0;

gdjs.CharacterCreationCode.GDrightUpText2Objects4.length = 0;

gdjs.CharacterCreationCode.GDrightupInputObjects4.length = 0;

gdjs.CharacterCreationCode.GDundoObjects4.length = 0;


if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4) {
    gdjs.CharacterCreationCode.GDrightUpText1Objects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4) {
    gdjs.CharacterCreationCode.GDrightUpText2Objects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4) {
    gdjs.CharacterCreationCode.GDrightupInputObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4) {
    gdjs.CharacterCreationCode.GDundoObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4) {
    gdjs.CharacterCreationCode.GDdyesObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightUpText1Objects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightUpText2Objects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightupInputObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDdyesObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDrightUpText1Objects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightUpText1Objects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightUpText2Objects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightUpText2Objects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupInputObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupInputObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDundoObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDundoObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDdyesObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDdyesObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("rightMiddleText"), gdjs.CharacterCreationCode.GDrightMiddleTextObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDrightMiddleTextObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects4);
gdjs.CharacterCreationCode.GDrightMiddleTextObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDrightMiddleTextObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDrightMiddleTextObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightMiddleTextObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDrightMiddleTextObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightMiddleTextObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("numbers"), gdjs.CharacterCreationCode.GDnumbersObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDnumbersObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects4);
gdjs.CharacterCreationCode.GDnumbersObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDnumbersObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDnumbersObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDnumbersObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDnumbersObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDnumbersObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDArrowsObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects4);
gdjs.CharacterCreationCode.GDArrowsObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDArrowsObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDArrowsObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDArrowsObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDArrowsObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Badges"), gdjs.CharacterCreationCode.GDBadgesObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDBadgesObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects4);
gdjs.CharacterCreationCode.GDBadgesObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDBadgesObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDBadgesObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDBadgesObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDBadgesObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDBadgesObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("panelDescription"), gdjs.CharacterCreationCode.GDpanelDescriptionObjects3);
gdjs.copyArray(runtimeScene.getObjects("panelSubTitle"), gdjs.CharacterCreationCode.GDpanelSubTitleObjects3);
gdjs.copyArray(runtimeScene.getObjects("panelTitle"), gdjs.CharacterCreationCode.GDpanelTitleObjects3);

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;
gdjs.CharacterCreationCode.forEachObjects4.length = 0;
gdjs.CharacterCreationCode.forEachCount0_4 = gdjs.CharacterCreationCode.GDpanelTitleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount0_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDpanelTitleObjects3);
gdjs.CharacterCreationCode.forEachCount1_4 = gdjs.CharacterCreationCode.GDpanelSubTitleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount1_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDpanelSubTitleObjects3);
gdjs.CharacterCreationCode.forEachCount2_4 = gdjs.CharacterCreationCode.GDpanelDescriptionObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount2_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDpanelDescriptionObjects3);
for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachTotalCount4;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects4);
gdjs.CharacterCreationCode.GDpanelDescriptionObjects4.length = 0;

gdjs.CharacterCreationCode.GDpanelSubTitleObjects4.length = 0;

gdjs.CharacterCreationCode.GDpanelTitleObjects4.length = 0;


if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4) {
    gdjs.CharacterCreationCode.GDpanelTitleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4) {
    gdjs.CharacterCreationCode.GDpanelSubTitleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4) {
    gdjs.CharacterCreationCode.GDpanelDescriptionObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDpanelTitleObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDpanelSubTitleObjects4ObjectsGDgdjs_9546CharacterCreationCode_9546GDpanelDescriptionObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDpanelTitleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDpanelTitleObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDpanelSubTitleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDpanelSubTitleObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDpanelDescriptionObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDpanelDescriptionObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDiconsObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("leftup"), gdjs.CharacterCreationCode.GDleftupObjects4);
gdjs.CharacterCreationCode.GDiconsObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDiconsObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDiconsObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDleftupObjects4Objects, gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDiconsObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDiconsObjects4[i].getBehavior("Sticker").Stick(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDleftupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("hoverTrigger"), gdjs.CharacterCreationCode.GDhoverTriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.CharacterCreationCode.GDleftObjects3);
gdjs.copyArray(runtimeScene.getObjects("leftup"), gdjs.CharacterCreationCode.GDleftupObjects3);
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("middle"), gdjs.CharacterCreationCode.GDmiddleObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightup"), gdjs.CharacterCreationCode.GDrightupObjects3);

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;
gdjs.CharacterCreationCode.forEachObjects4.length = 0;
gdjs.CharacterCreationCode.forEachCount0_4 = gdjs.CharacterCreationCode.GDleftObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount0_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDleftObjects3);
gdjs.CharacterCreationCode.forEachCount1_4 = gdjs.CharacterCreationCode.GDleftupObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount1_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDleftupObjects3);
gdjs.CharacterCreationCode.forEachCount2_4 = gdjs.CharacterCreationCode.GDmiddleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount2_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDmiddleObjects3);
gdjs.CharacterCreationCode.forEachCount3_4 = gdjs.CharacterCreationCode.GDlowerLeftObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount3_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDlowerLeftObjects3);
gdjs.CharacterCreationCode.forEachCount4_4 = gdjs.CharacterCreationCode.GDrightupObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount4_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightupObjects3);
gdjs.CharacterCreationCode.forEachCount5_4 = gdjs.CharacterCreationCode.GDrightmiddleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount5_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightmiddleObjects3);
gdjs.CharacterCreationCode.forEachCount6_4 = gdjs.CharacterCreationCode.GDcreateButtonObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount6_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDcreateButtonObjects3);
gdjs.CharacterCreationCode.forEachCount7_4 = gdjs.CharacterCreationCode.GDbackButtonObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount7_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDbackButtonObjects3);
gdjs.CharacterCreationCode.forEachCount8_4 = gdjs.CharacterCreationCode.GDhoverTriggerObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount8_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDhoverTriggerObjects3);
for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachTotalCount4;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDbackButtonObjects4.length = 0;

gdjs.CharacterCreationCode.GDcreateButtonObjects4.length = 0;

gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length = 0;

gdjs.CharacterCreationCode.GDleftObjects4.length = 0;

gdjs.CharacterCreationCode.GDleftupObjects4.length = 0;

gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;

gdjs.CharacterCreationCode.GDmiddleObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightmiddleObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightupObjects4.length = 0;


if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4) {
    gdjs.CharacterCreationCode.GDleftObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4) {
    gdjs.CharacterCreationCode.GDleftupObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4) {
    gdjs.CharacterCreationCode.GDmiddleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4) {
    gdjs.CharacterCreationCode.GDrightupObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4+gdjs.CharacterCreationCode.forEachCount6_4) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4+gdjs.CharacterCreationCode.forEachCount6_4+gdjs.CharacterCreationCode.forEachCount7_4) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4+gdjs.CharacterCreationCode.forEachCount6_4+gdjs.CharacterCreationCode.forEachCount7_4+gdjs.CharacterCreationCode.forEachCount8_4) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDleftObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDleftObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDleftupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftupObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDleftupObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDleftupObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDmiddleObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDmiddleObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDrightupObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDrightupObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getPointX("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getVariables().get("x")).setNumber((gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getPointX("")));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDleftObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDleftObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDleftupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftupObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDleftupObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDleftupObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDmiddleObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDmiddleObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDrightupObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDrightupObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getPointY("")));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].returnVariable(gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getVariables().get("y")).setNumber((gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getPointY("")));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.CharacterCreationCode.GDleftObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDleftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDleftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDleftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDleftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects4[i].setOpacity(0);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDlowerLeftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDlowerLeftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDlowerLeftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].setY(gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 700 + (gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getHeight()));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("leftup"), gdjs.CharacterCreationCode.GDleftupObjects3);
gdjs.copyArray(runtimeScene.getObjects("middle"), gdjs.CharacterCreationCode.GDmiddleObjects3);

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;
gdjs.CharacterCreationCode.forEachObjects4.length = 0;
gdjs.CharacterCreationCode.forEachCount0_4 = gdjs.CharacterCreationCode.GDleftupObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount0_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDleftupObjects3);
gdjs.CharacterCreationCode.forEachCount1_4 = gdjs.CharacterCreationCode.GDmiddleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount1_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDmiddleObjects3);
for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachTotalCount4;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDleftupObjects4.length = 0;

gdjs.CharacterCreationCode.GDmiddleObjects4.length = 0;


if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4) {
    gdjs.CharacterCreationCode.GDleftupObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4) {
    gdjs.CharacterCreationCode.GDmiddleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftupObjects4[i].setX(-(700) - (gdjs.CharacterCreationCode.GDleftupObjects4[i].getWidth()));
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects4[i].setX(-(700) - (gdjs.CharacterCreationCode.GDmiddleObjects4[i].getWidth()));
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("hoverTrigger"), gdjs.CharacterCreationCode.GDhoverTriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightup"), gdjs.CharacterCreationCode.GDrightupObjects3);

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;
gdjs.CharacterCreationCode.forEachObjects4.length = 0;
gdjs.CharacterCreationCode.forEachCount0_4 = gdjs.CharacterCreationCode.GDcreateButtonObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount0_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDcreateButtonObjects3);
gdjs.CharacterCreationCode.forEachCount1_4 = gdjs.CharacterCreationCode.GDrightupObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount1_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightupObjects3);
gdjs.CharacterCreationCode.forEachCount2_4 = gdjs.CharacterCreationCode.GDrightmiddleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount2_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightmiddleObjects3);
gdjs.CharacterCreationCode.forEachCount3_4 = gdjs.CharacterCreationCode.GDbackButtonObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount3_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDbackButtonObjects3);
gdjs.CharacterCreationCode.forEachCount4_4 = gdjs.CharacterCreationCode.GDhoverTriggerObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount4_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDhoverTriggerObjects3);
for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachTotalCount4;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDbackButtonObjects4.length = 0;

gdjs.CharacterCreationCode.GDcreateButtonObjects4.length = 0;

gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightmiddleObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightupObjects4.length = 0;


if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4) {
    gdjs.CharacterCreationCode.GDrightupObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + (gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getWidth()) + 500);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupObjects4[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + (gdjs.CharacterCreationCode.GDrightupObjects4[i].getWidth()) + 500);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + (gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getWidth()) + 500);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + (gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getWidth()) + 500);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + (gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getWidth()) + 500);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("index").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("hoverTrigger"), gdjs.CharacterCreationCode.GDhoverTriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.CharacterCreationCode.GDleftObjects3);
gdjs.copyArray(runtimeScene.getObjects("leftup"), gdjs.CharacterCreationCode.GDleftupObjects3);
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects3);
gdjs.copyArray(runtimeScene.getObjects("middle"), gdjs.CharacterCreationCode.GDmiddleObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects3);
gdjs.copyArray(runtimeScene.getObjects("rightup"), gdjs.CharacterCreationCode.GDrightupObjects3);

gdjs.CharacterCreationCode.forEachTotalCount4 = 0;
gdjs.CharacterCreationCode.forEachObjects4.length = 0;
gdjs.CharacterCreationCode.forEachCount0_4 = gdjs.CharacterCreationCode.GDleftObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount0_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDleftObjects3);
gdjs.CharacterCreationCode.forEachCount1_4 = gdjs.CharacterCreationCode.GDleftupObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount1_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDleftupObjects3);
gdjs.CharacterCreationCode.forEachCount2_4 = gdjs.CharacterCreationCode.GDmiddleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount2_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDmiddleObjects3);
gdjs.CharacterCreationCode.forEachCount3_4 = gdjs.CharacterCreationCode.GDlowerLeftObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount3_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDlowerLeftObjects3);
gdjs.CharacterCreationCode.forEachCount4_4 = gdjs.CharacterCreationCode.GDrightupObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount4_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightupObjects3);
gdjs.CharacterCreationCode.forEachCount5_4 = gdjs.CharacterCreationCode.GDrightmiddleObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount5_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDrightmiddleObjects3);
gdjs.CharacterCreationCode.forEachCount6_4 = gdjs.CharacterCreationCode.GDcreateButtonObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount6_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDcreateButtonObjects3);
gdjs.CharacterCreationCode.forEachCount7_4 = gdjs.CharacterCreationCode.GDbackButtonObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount7_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDbackButtonObjects3);
gdjs.CharacterCreationCode.forEachCount8_4 = gdjs.CharacterCreationCode.GDhoverTriggerObjects3.length;
gdjs.CharacterCreationCode.forEachTotalCount4 += gdjs.CharacterCreationCode.forEachCount8_4;
gdjs.CharacterCreationCode.forEachObjects4.push.apply(gdjs.CharacterCreationCode.forEachObjects4,gdjs.CharacterCreationCode.GDhoverTriggerObjects3);
for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachTotalCount4;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDbackButtonObjects4.length = 0;

gdjs.CharacterCreationCode.GDcreateButtonObjects4.length = 0;

gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length = 0;

gdjs.CharacterCreationCode.GDleftObjects4.length = 0;

gdjs.CharacterCreationCode.GDleftupObjects4.length = 0;

gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;

gdjs.CharacterCreationCode.GDmiddleObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightmiddleObjects4.length = 0;

gdjs.CharacterCreationCode.GDrightupObjects4.length = 0;


if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4) {
    gdjs.CharacterCreationCode.GDleftObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4) {
    gdjs.CharacterCreationCode.GDleftupObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4) {
    gdjs.CharacterCreationCode.GDmiddleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4) {
    gdjs.CharacterCreationCode.GDrightupObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4+gdjs.CharacterCreationCode.forEachCount6_4) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4+gdjs.CharacterCreationCode.forEachCount6_4+gdjs.CharacterCreationCode.forEachCount7_4) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
else if (gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.forEachCount0_4+gdjs.CharacterCreationCode.forEachCount1_4+gdjs.CharacterCreationCode.forEachCount2_4+gdjs.CharacterCreationCode.forEachCount3_4+gdjs.CharacterCreationCode.forEachCount4_4+gdjs.CharacterCreationCode.forEachCount5_4+gdjs.CharacterCreationCode.forEachCount6_4+gdjs.CharacterCreationCode.forEachCount7_4+gdjs.CharacterCreationCode.forEachCount8_4) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4.push(gdjs.CharacterCreationCode.forEachObjects4[gdjs.CharacterCreationCode.forEachIndex4]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDleftObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDleftupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftupObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDleftupObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDmiddleObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDrightupObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDrightmiddleObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDrightmiddleObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDcreateButtonObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDbackButtonObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getBehavior("Tween").addObjectPositionXTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDhoverTriggerObjects4[i].getVariables().get("x"))), "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
}{runtimeScene.getScene().getVariables().get("index").add(1);
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects3);

for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDlowerLeftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDlowerLeftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDlowerLeftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getBehavior("Tween").addObjectPositionYTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getVariables().get("y"))), "easeFromTo", 500 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.CharacterCreationCode.GDleftObjects2);

for (gdjs.CharacterCreationCode.forEachIndex3 = 0;gdjs.CharacterCreationCode.forEachIndex3 < gdjs.CharacterCreationCode.GDleftObjects2.length;++gdjs.CharacterCreationCode.forEachIndex3) {
gdjs.CharacterCreationCode.GDleftObjects3.length = 0;


gdjs.CharacterCreationCode.forEachTemporary3 = gdjs.CharacterCreationCode.GDleftObjects2[gdjs.CharacterCreationCode.forEachIndex3];
gdjs.CharacterCreationCode.GDleftObjects3.push(gdjs.CharacterCreationCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects3[i].getBehavior("Tween").addObjectOpacityTween("", 255, "easeFromTo", 1000 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) * 250), false);
}
}}
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDleftupObjects2Objects = Hashtable.newFrom({"leftup": gdjs.CharacterCreationCode.GDleftupObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects2});
gdjs.CharacterCreationCode.eventsList16 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList17 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList18 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList19 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList20 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList21 = function(runtimeScene) {

{


const keyIteratorReference5 = runtimeScene.getScene().getVariables().get("id");
const valueIteratorReference5 = runtimeScene.getScene().getVariables().get("value");
const iterableReference5 = runtimeScene.getScene().getVariables().get("distributedVariables");
if(!iterableReference5.isPrimitive()) {
for(
    const iteratorKey5 in 
    iterableReference5.getType() === "structure"
      ? iterableReference5.getAllChildren()
      : iterableReference5.getType() === "array"
        ? iterableReference5.getAllChildrenArray()
        : []
) {
    if(iterableReference5.getType() === "structure")
        keyIteratorReference5.setString(iteratorKey5);
    else if(iterableReference5.getType() === "array")
        keyIteratorReference5.setNumber(iteratorKey5);
    const structureChildVariable5 = iterableReference5.getChild(iteratorKey5)
    valueIteratorReference5.castTo(structureChildVariable5.getType())
    if(structureChildVariable5.isPrimitive()) {
        valueIteratorReference5.setValue(structureChildVariable5.getValue());
    } else if (structureChildVariable5.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference5.replaceChildren(structureChildVariable5.getAllChildren());
    } else if (structureChildVariable5.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference5.replaceChildrenArray(structureChildVariable5.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("numbers"), gdjs.CharacterCreationCode.GDnumbersObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDnumbersObjects5.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDnumbersObjects5[i].getVariableString(gdjs.CharacterCreationCode.GDnumbersObjects5[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("id")) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDnumbersObjects5[k] = gdjs.CharacterCreationCode.GDnumbersObjects5[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDnumbersObjects5.length = k;
if (isConditionTrue_0)
{
{for(var i = 0, len = gdjs.CharacterCreationCode.GDnumbersObjects5.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDnumbersObjects5[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("value")));
}
}}
}
}

}


};gdjs.CharacterCreationCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.CharacterCreationCode.GDleftupObjects2, gdjs.CharacterCreationCode.GDleftupObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDleftupObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDleftupObjects4[0].getVariables()).get("id"))) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("type")));
}
if (isConditionTrue_0) {
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().get("distribution")), runtimeScene.getScene().getVariables().get("distributedVariables"));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.CharacterCreationCode.GDleftObjects2, gdjs.CharacterCreationCode.GDleftObjects3);


for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDleftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDleftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDleftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDleftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects4[i].setOpacity(0);
}
}}
}

}


{

gdjs.copyArray(gdjs.CharacterCreationCode.GDleftObjects2, gdjs.CharacterCreationCode.GDleftObjects3);


for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDleftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDleftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDleftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDleftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects4[i].getBehavior("Tween").addObjectOpacityTween("", 255, "easeFromTo", 900, false);
}
}}
}

}


{

gdjs.copyArray(gdjs.CharacterCreationCode.GDlowerLeftObjects2, gdjs.CharacterCreationCode.GDlowerLeftObjects3);


for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDlowerLeftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDlowerLeftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDlowerLeftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].setY(gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 700);
}
}}
}

}


{

gdjs.copyArray(gdjs.CharacterCreationCode.GDlowerLeftObjects2, gdjs.CharacterCreationCode.GDlowerLeftObjects3);


for (gdjs.CharacterCreationCode.forEachIndex4 = 0;gdjs.CharacterCreationCode.forEachIndex4 < gdjs.CharacterCreationCode.GDlowerLeftObjects3.length;++gdjs.CharacterCreationCode.forEachIndex4) {
gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;


gdjs.CharacterCreationCode.forEachTemporary4 = gdjs.CharacterCreationCode.GDlowerLeftObjects3[gdjs.CharacterCreationCode.forEachIndex4];
gdjs.CharacterCreationCode.GDlowerLeftObjects4.push(gdjs.CharacterCreationCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getBehavior("Tween").addObjectPositionYTween("", (gdjs.RuntimeObject.getVariableNumber(gdjs.CharacterCreationCode.GDlowerLeftObjects4[i].getVariables().get("y"))), "easeFromTo", 900, false);
}
}}
}

}


{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().get("type");
const valueIteratorReference3 = runtimeScene.getScene().getVariables().get("distribution");
const iterableReference3 = runtimeScene.getScene().getVariables().getFromIndex(0);
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{

{ //Subevents: 
gdjs.CharacterCreationCode.eventsList22(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects2Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects2, "createButton": gdjs.CharacterCreationCode.GDcreateButtonObjects2, "backButton": gdjs.CharacterCreationCode.GDbackButtonObjects2, "Arrows": gdjs.CharacterCreationCode.GDArrowsObjects2, "undo": gdjs.CharacterCreationCode.GDundoObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects2Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects2, "createButton": gdjs.CharacterCreationCode.GDcreateButtonObjects2, "backButton": gdjs.CharacterCreationCode.GDbackButtonObjects2, "Arrows": gdjs.CharacterCreationCode.GDArrowsObjects2, "undo": gdjs.CharacterCreationCode.GDundoObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects3Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects3});
gdjs.CharacterCreationCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.CharacterCreationCode.GDmiddleObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects2[i].setX(-(700) - (gdjs.CharacterCreationCode.GDmiddleObjects2[i].getWidth()));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects2[i].getBehavior("Tween").addObjectPositionXTween("", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - Math.abs((gdjs.CharacterCreationCode.GDmiddleObjects2[i].getPointX("")) - (gdjs.CharacterCreationCode.GDmiddleObjects2[i].getCenterXInScene())) - 90, "easeFromTo", 1000, false);
}
}}

}


};gdjs.CharacterCreationCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.CharacterCreationCode.GDiconsObjects2 */
gdjs.copyArray(runtimeScene.getObjects("middle"), gdjs.CharacterCreationCode.GDmiddleObjects2);
gdjs.copyArray(runtimeScene.getObjects("panelTitle"), gdjs.CharacterCreationCode.GDpanelTitleObjects2);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDmiddleObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDmiddleObjects2[i].setAnimationName((( gdjs.CharacterCreationCode.GDiconsObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDiconsObjects2[0].getAnimationName()));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDpanelTitleObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDpanelTitleObjects2[i].setAnimationName((( gdjs.CharacterCreationCode.GDiconsObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDiconsObjects2[0].getAnimationName()));
}
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.CharacterCreationCode.GDiconsObjects2, gdjs.CharacterCreationCode.GDiconsObjects3);

{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects3Objects);
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDiconsObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDiconsObjects3[i].setAnimationFrame(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.CharacterCreationCode.GDiconsObjects2, gdjs.CharacterCreationCode.GDiconsObjects3);

{for(var i = 0, len = gdjs.CharacterCreationCode.GDiconsObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDiconsObjects3[i].setAnimationFrame(2);
}
}}

}


{

/* Reuse gdjs.CharacterCreationCode.GDiconsObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("character")) != (( gdjs.CharacterCreationCode.GDiconsObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDiconsObjects2[0].getAnimationName());
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDiconsObjects2 */
{runtimeScene.getScene().getVariables().get("character").setString((( gdjs.CharacterCreationCode.GDiconsObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDiconsObjects2[0].getAnimationName()));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDdyesObjects2Objects = Hashtable.newFrom({"dyes": gdjs.CharacterCreationCode.GDdyesObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDdyesObjects3Objects = Hashtable.newFrom({"dyes": gdjs.CharacterCreationCode.GDdyesObjects3});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDdyesObjects2Objects = Hashtable.newFrom({"dyes": gdjs.CharacterCreationCode.GDdyesObjects2});
gdjs.CharacterCreationCode.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.CharacterCreationCode.GDdyesObjects2, gdjs.CharacterCreationCode.GDdyesObjects3);

{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDdyesObjects3Objects);
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDdyesObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDdyesObjects3[i].setAnimationFrame(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDdyesObjects2Objects) == 1;
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDdyesObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDdyesObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDdyesObjects2[i].setAnimationFrame(1);
}
}}

}


};gdjs.CharacterCreationCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects2Objects = Hashtable.newFrom({"createButton": gdjs.CharacterCreationCode.GDcreateButtonObjects2, "backButton": gdjs.CharacterCreationCode.GDbackButtonObjects2, "Arrows": gdjs.CharacterCreationCode.GDArrowsObjects2, "undo": gdjs.CharacterCreationCode.GDundoObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2Objects = Hashtable.newFrom({"backButton": gdjs.CharacterCreationCode.GDbackButtonObjects2});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2Objects = Hashtable.newFrom({"createButton": gdjs.CharacterCreationCode.GDcreateButtonObjects2});
gdjs.CharacterCreationCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("rightupInput"), gdjs.CharacterCreationCode.GDrightupInputObjects2);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupInputObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupInputObjects2[i].setString(gdjs.evtsExt__InterfaceFunctions__FormatPlayerName.func(runtimeScene, (gdjs.CharacterCreationCode.GDrightupInputObjects2[i].getString()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{gdjs.evtsExt__OnlineMultiplayerFirebase__CheckIfPlayerNameExist.func(runtimeScene, (( gdjs.CharacterCreationCode.GDrightupInputObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDrightupInputObjects2[0].getString()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "retrieving player info", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("MaxHp").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("MonsterDictionary").getChild("player").getChild("baseStats").getChild("HP")));
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("Hp").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("MonsterDictionary").getChild("player").getChild("baseStats").getChild("HP")));
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("Mana").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("MonsterDictionary").getChild("player").getChild("baseStats").getChild("MP")));
}}

}


};gdjs.CharacterCreationCode.asyncCallback63355604 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.CharacterCreationCode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback63355604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().get("distributedVariables")), runtimeScene.getGame().getVariables().getFromIndex(6));
}{runtimeScene.getGame().getVariables().getFromIndex(8).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("selected")));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("MaxMana").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("MonsterDictionary").getChild("player").getChild("baseStats").getChild("MP")));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "moving to game scene", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Entering World", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("_containsBadWords"), true);
if (isConditionTrue_0) {
gdjs.copyArray(asyncObjectsList.getObjects("rightupInput"), gdjs.CharacterCreationCode.GDrightupInputObjects4);

{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Name contains inappropriate words!", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDrightupInputObjects4.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDrightupInputObjects4[i].setString("");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("_containsBadWords"), false);
if (isConditionTrue_0) {
gdjs.copyArray(asyncObjectsList.getObjects("rightupInput"), gdjs.CharacterCreationCode.GDrightupInputObjects3);

{runtimeScene.getGame().getVariables().getFromIndex(7).setString(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("character")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setString((( gdjs.CharacterCreationCode.GDrightupInputObjects3.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDrightupInputObjects3[0].getString()));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.CharacterCreationCode.asyncCallback63350284 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.CharacterCreationCode.eventsList35 = function(runtimeScene) {

{

/* Reuse gdjs.CharacterCreationCode.GDrightupInputObjects2 */

{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.CharacterCreationCode.GDrightupInputObjects2) asyncObjectsList.addObject("rightupInput", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__InterfaceFunctions__ContainsBadWords.func(runtimeScene, (( gdjs.CharacterCreationCode.GDrightupInputObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDrightupInputObjects2[0].getString()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback63350284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.CharacterCreationCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("rightupInput"), gdjs.CharacterCreationCode.GDrightupInputObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDrightupInputObjects3.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDrightupInputObjects3[i].getString() == "" ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDrightupInputObjects3[k] = gdjs.CharacterCreationCode.GDrightupInputObjects3[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDrightupInputObjects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Please enter a name -(12346)", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rightupInput"), gdjs.CharacterCreationCode.GDrightupInputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDrightupInputObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDrightupInputObjects2[i].getString() != "" ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDrightupInputObjects2[k] = gdjs.CharacterCreationCode.GDrightupInputObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDrightupInputObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("SavedData").getChild("NameAlreadyTaken"), true);
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "This name already exist - (12345)", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("SavedData").getChild("NameAlreadyTaken"), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("PlayerRetrieved"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(63346380);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "retrieving player info", "loading-end", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2Objects = Hashtable.newFrom({"Arrows": gdjs.CharacterCreationCode.GDArrowsObjects2});
gdjs.CharacterCreationCode.eventsList40 = function(runtimeScene) {

};gdjs.CharacterCreationCode.eventsList41 = function(runtimeScene) {

{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().get("id");
const valueIteratorReference3 = runtimeScene.getScene().getVariables().get("value");
const iterableReference3 = runtimeScene.getScene().getVariables().get("distributedVariables");
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("numbers"), gdjs.CharacterCreationCode.GDnumbersObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDnumbersObjects3.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDnumbersObjects3[i].getVariableString(gdjs.CharacterCreationCode.GDnumbersObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("id")) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDnumbersObjects3[k] = gdjs.CharacterCreationCode.GDnumbersObjects3[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDnumbersObjects3.length = k;
if (isConditionTrue_0)
{
{for(var i = 0, len = gdjs.CharacterCreationCode.GDnumbersObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDnumbersObjects3[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("value")));
}
}}
}
}

}


};gdjs.CharacterCreationCode.eventsList42 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.CharacterCreationCode.GDArrowsObjects2 */
{gdjs.evtsExt__InterfaceFunctions__CalculateDistributionPoints.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("selected")), (( gdjs.CharacterCreationCode.GDArrowsObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDArrowsObjects2[0].getAnimationName()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList41(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDhoverTriggerObjects2Objects = Hashtable.newFrom({"hoverTrigger": gdjs.CharacterCreationCode.GDhoverTriggerObjects2});
gdjs.CharacterCreationCode.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hoverInfo"), gdjs.CharacterCreationCode.GDhoverInfoObjects2);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextCharm"), gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects2);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextMagic"), gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects2);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextPower"), gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects2);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextSense"), gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects2);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects2[i].hide();
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects2[i].hide();
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects2[i].hide();
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects2[i].hide();
}
}}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDhoverTriggerObjects1Objects = Hashtable.newFrom({"hoverTrigger": gdjs.CharacterCreationCode.GDhoverTriggerObjects1});
gdjs.CharacterCreationCode.eventsList44 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hoverInfo"), gdjs.CharacterCreationCode.GDhoverInfoObjects2);
gdjs.copyArray(gdjs.CharacterCreationCode.GDhoverTriggerObjects1, gdjs.CharacterCreationCode.GDhoverTriggerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDhoverInfoObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDhoverInfoObjects2[i].getVariableString(gdjs.CharacterCreationCode.GDhoverInfoObjects2[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDhoverTriggerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDhoverTriggerObjects2[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDhoverInfoObjects2[k] = gdjs.CharacterCreationCode.GDhoverInfoObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDhoverInfoObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDhoverInfoObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextCharm"), gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextMagic"), gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextPower"), gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1);
gdjs.copyArray(runtimeScene.getObjects("hoverInfoTextSense"), gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1);
/* Reuse gdjs.CharacterCreationCode.GDhoverTriggerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1[i].getVariableString(gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDhoverTriggerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDhoverTriggerObjects1[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1[k] = gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1[i].getVariableString(gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDhoverTriggerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDhoverTriggerObjects1[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1[k] = gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1[i].getVariableString(gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDhoverTriggerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDhoverTriggerObjects1[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1[k] = gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1[i].getVariableString(gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDhoverTriggerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDhoverTriggerObjects1[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1[k] = gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1 */
/* Reuse gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1 */
/* Reuse gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1 */
/* Reuse gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1[i].hide(false);
}
}}

}


};gdjs.CharacterCreationCode.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects2);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects2);
gdjs.copyArray(runtimeScene.getObjects("undo"), gdjs.CharacterCreationCode.GDundoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDiconsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDiconsObjects2[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDiconsObjects2[k] = gdjs.CharacterCreationCode.GDiconsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDiconsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDcreateButtonObjects2[k] = gdjs.CharacterCreationCode.GDcreateButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDcreateButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDbackButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDbackButtonObjects2[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDbackButtonObjects2[k] = gdjs.CharacterCreationCode.GDbackButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDbackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDArrowsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDArrowsObjects2[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDArrowsObjects2[k] = gdjs.CharacterCreationCode.GDArrowsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDArrowsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDundoObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDundoObjects2[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDundoObjects2[k] = gdjs.CharacterCreationCode.GDundoObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDundoObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDArrowsObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDbackButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDcreateButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDiconsObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDundoObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDiconsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDiconsObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDArrowsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDArrowsObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDundoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDundoObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects2);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects2);
gdjs.copyArray(runtimeScene.getObjects("undo"), gdjs.CharacterCreationCode.GDundoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDiconsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDiconsObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDiconsObjects2[k] = gdjs.CharacterCreationCode.GDiconsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDiconsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDcreateButtonObjects2[k] = gdjs.CharacterCreationCode.GDcreateButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDcreateButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDbackButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDbackButtonObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDbackButtonObjects2[k] = gdjs.CharacterCreationCode.GDbackButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDbackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDArrowsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDArrowsObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDArrowsObjects2[k] = gdjs.CharacterCreationCode.GDArrowsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDArrowsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDundoObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDundoObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDundoObjects2[k] = gdjs.CharacterCreationCode.GDundoObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDundoObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDArrowsObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDbackButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDcreateButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDiconsObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDundoObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDiconsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDiconsObjects2[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects2[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDArrowsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDArrowsObjects2[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDundoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDundoObjects2[i].setAnimationFrame(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dyes"), gdjs.CharacterCreationCode.GDdyesObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDdyesObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects2);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("undo"), gdjs.CharacterCreationCode.GDundoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDcreateButtonObjects2[k] = gdjs.CharacterCreationCode.GDcreateButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDcreateButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDbackButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDbackButtonObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDbackButtonObjects2[k] = gdjs.CharacterCreationCode.GDbackButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDbackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDArrowsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDArrowsObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDArrowsObjects2[k] = gdjs.CharacterCreationCode.GDArrowsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDArrowsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDundoObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDundoObjects2[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDundoObjects2[k] = gdjs.CharacterCreationCode.GDundoObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDundoObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDArrowsObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDbackButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDcreateButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDundoObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDArrowsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDArrowsObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDundoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDundoObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects2);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("undo"), gdjs.CharacterCreationCode.GDundoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDundoObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDArrowsObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDbackButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDcreateButtonObjects2 */
/* Reuse gdjs.CharacterCreationCode.GDundoObjects2 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].setAnimationFrame(2);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDbackButtonObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDbackButtonObjects2[i].setAnimationFrame(2);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDArrowsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDArrowsObjects2[i].setAnimationFrame(2);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDundoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDundoObjects2[i].setAnimationFrame(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Login", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList30(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.CharacterCreationCode.eventsList39(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("hoverTrigger"), gdjs.CharacterCreationCode.GDhoverTriggerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDhoverTriggerObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("hoverTrigger"), gdjs.CharacterCreationCode.GDhoverTriggerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDhoverTriggerObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList44(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList46 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("selected").setString("magic");
}{runtimeScene.getScene().getVariables().get("character").setString("dragon");
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("selected")))), runtimeScene.getScene().getVariables().get("distributedVariables"));
}{gdjs.evtsExt__JsonLoader__LoadJSONToScene.func(runtimeScene, "dictionaries\\monsters.json", runtimeScene.getScene().getVariables().get("MonsterDictionary"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "moving to character creation", "loading-end", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.CharacterCreationCode.GDAvatarsObjects2);
gdjs.copyArray(runtimeScene.getObjects("rightup"), gdjs.CharacterCreationCode.GDrightupObjects2);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDAvatarsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDAvatarsObjects2[i].setCenterPositionInScene((( gdjs.CharacterCreationCode.GDrightupObjects2.length === 0 ) ? 0 :gdjs.CharacterCreationCode.GDrightupObjects2[0].getPointX("Avatar")),(( gdjs.CharacterCreationCode.GDrightupObjects2.length === 0 ) ? 0 :gdjs.CharacterCreationCode.GDrightupObjects2[0].getPointY("Avatar")));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDAvatarsObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDAvatarsObjects2[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("character")));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("panelDescription"), gdjs.CharacterCreationCode.GDpanelDescriptionObjects2);
gdjs.copyArray(runtimeScene.getObjects("panelSubTitle"), gdjs.CharacterCreationCode.GDpanelSubTitleObjects2);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDpanelSubTitleObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDpanelSubTitleObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("character"))).getChild("text1")));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDpanelDescriptionObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDpanelDescriptionObjects2[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("character"))).getChild("text2")));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects2);
gdjs.copyArray(runtimeScene.getObjects("leftup"), gdjs.CharacterCreationCode.GDleftupObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDleftupObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("selected")) != (gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDleftupObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDleftupObjects2[0].getVariables()).get("id")));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(63327596);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Badges"), gdjs.CharacterCreationCode.GDBadgesObjects2);
gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.CharacterCreationCode.GDleftObjects2);
/* Reuse gdjs.CharacterCreationCode.GDleftupObjects2 */
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects2);
{runtimeScene.getScene().getVariables().get("selected").setString((gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDleftupObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDleftupObjects2[0].getVariables()).get("id"))));
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDleftObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDleftObjects2[i].setAnimationName((gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDleftupObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDleftupObjects2[0].getVariables()).get("id"))));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects2[i].setAnimationName((gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDleftupObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDleftupObjects2[0].getVariables()).get("id"))));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDBadgesObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDBadgesObjects2[i].setAnimationName((gdjs.RuntimeObject.getVariableString(((gdjs.CharacterCreationCode.GDleftupObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CharacterCreationCode.GDleftupObjects2[0].getVariables()).get("id"))));
}
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList23(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.CharacterCreationCode.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.mapOfEmptyGDCursorsObjects = Hashtable.newFrom({"Cursors": []});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDCursorsObjects1Objects = Hashtable.newFrom({"Cursors": gdjs.CharacterCreationCode.GDCursorsObjects1});
gdjs.CharacterCreationCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.CharacterCreationCode.mapOfEmptyGDCursorsObjects) == 0;
if (isConditionTrue_0) {
gdjs.CharacterCreationCode.GDCursorsObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDCursorsObjects1Objects, 0, 0, "Interface");
}}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDleftObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDmiddleObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightupObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDleftupObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDCreateCharacterBackgroundObjects1Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects1, "left": gdjs.CharacterCreationCode.GDleftObjects1, "middle": gdjs.CharacterCreationCode.GDmiddleObjects1, "rightup": gdjs.CharacterCreationCode.GDrightupObjects1, "rightmiddle": gdjs.CharacterCreationCode.GDrightmiddleObjects1, "lowerLeft": gdjs.CharacterCreationCode.GDlowerLeftObjects1, "leftup": gdjs.CharacterCreationCode.GDleftupObjects1, "createButton": gdjs.CharacterCreationCode.GDcreateButtonObjects1, "backButton": gdjs.CharacterCreationCode.GDbackButtonObjects1, "CreateCharacterBackground": gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1});
gdjs.CharacterCreationCode.eventsList48 = function(runtimeScene) {

{

/* Reuse gdjs.CharacterCreationCode.GDCursorsObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDCursorsObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDCursorsObjects1[i].isCurrentAnimationName("Hand") ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDCursorsObjects1[k] = gdjs.CharacterCreationCode.GDCursorsObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDCursorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDCursorsObjects1 */
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("Click");
}
}}

}


};gdjs.CharacterCreationCode.eventsList49 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDdyesObjects2Objects = Hashtable.newFrom({"icons": gdjs.CharacterCreationCode.GDiconsObjects2, "createButton": gdjs.CharacterCreationCode.GDcreateButtonObjects2, "Arrows": gdjs.CharacterCreationCode.GDArrowsObjects2, "dyes": gdjs.CharacterCreationCode.GDdyesObjects2});
gdjs.CharacterCreationCode.mapOf = Hashtable.newFrom({});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2Objects = Hashtable.newFrom({"backButton": gdjs.CharacterCreationCode.GDbackButtonObjects2});
gdjs.CharacterCreationCode.mapOf = Hashtable.newFrom({});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDundoObjects1Objects = Hashtable.newFrom({"undo": gdjs.CharacterCreationCode.GDundoObjects1});
gdjs.CharacterCreationCode.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.CharacterCreationCode.GDArrowsObjects2);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("dyes"), gdjs.CharacterCreationCode.GDdyesObjects2);
gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDiconsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDiconsObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDiconsObjects2[k] = gdjs.CharacterCreationCode.GDiconsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDiconsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDcreateButtonObjects2[k] = gdjs.CharacterCreationCode.GDcreateButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDcreateButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDArrowsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDArrowsObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDArrowsObjects2[k] = gdjs.CharacterCreationCode.GDArrowsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDArrowsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDdyesObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDdyesObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDdyesObjects2[k] = gdjs.CharacterCreationCode.GDdyesObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDdyesObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDArrowsObjects2ObjectsGDgdjs_9546CharacterCreationCode_9546GDdyesObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.CharacterCreationCode.GDdyesObjects2.length === 0 ) ? (( gdjs.CharacterCreationCode.GDArrowsObjects2.length === 0 ) ? (( gdjs.CharacterCreationCode.GDcreateButtonObjects2.length === 0 ) ? (( gdjs.CharacterCreationCode.GDiconsObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDiconsObjects2[0].getLayer()) :gdjs.CharacterCreationCode.GDcreateButtonObjects2[0].getLayer()) :gdjs.CharacterCreationCode.GDArrowsObjects2[0].getLayer()) :gdjs.CharacterCreationCode.GDdyesObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDiconsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDiconsObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDiconsObjects2[k] = gdjs.CharacterCreationCode.GDiconsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDiconsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDcreateButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDcreateButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDcreateButtonObjects2[k] = gdjs.CharacterCreationCode.GDcreateButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDcreateButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDArrowsObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDArrowsObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDArrowsObjects2[k] = gdjs.CharacterCreationCode.GDArrowsObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDArrowsObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDdyesObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDdyesObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDdyesObjects2[k] = gdjs.CharacterCreationCode.GDdyesObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDdyesObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_click.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("SFXVolume")), 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_create_btnselect.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("SFXVolume")), 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDbackButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDbackButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDbackButtonObjects2[k] = gdjs.CharacterCreationCode.GDbackButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDbackButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.CharacterCreationCode.GDbackButtonObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDbackButtonObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDbackButtonObjects2.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDbackButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDbackButtonObjects2[k] = gdjs.CharacterCreationCode.GDbackButtonObjects2[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDbackButtonObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_close.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("SFXVolume")), 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_open.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("SFXVolume")), 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("undo"), gdjs.CharacterCreationCode.GDundoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDundoObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDundoObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDundoObjects1[k] = gdjs.CharacterCreationCode.GDundoObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDundoObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDundoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.CharacterCreationCode.GDundoObjects1.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDundoObjects1[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDundoObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDundoObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDundoObjects1[k] = gdjs.CharacterCreationCode.GDundoObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDundoObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_spinbtn.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("SFXVolume")), 1);
}}

}


};gdjs.CharacterCreationCode.mapOfEmptyGDTransparentBackgroundText2Objects = Hashtable.newFrom({"TransparentBackgroundText2": []});
gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDTransparentBackgroundText2Objects2Objects = Hashtable.newFrom({"TransparentBackgroundText2": gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects2});
gdjs.CharacterCreationCode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.CharacterCreationCode.mapOfEmptyGDTransparentBackgroundText2Objects) == 0;
if (isConditionTrue_0) {
/* Reuse gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2 */
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDTransparentBackgroundText2Objects2Objects, -(100), -(100), (( gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2[0].getLayer()));
}}

}


};gdjs.CharacterCreationCode.eventsList52 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText2"), gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3[i].setText(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3[i].setX(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3[i].setY(142);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText2"), gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3[i].setWidth((( gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length === 0 ) ? 0 :gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3[0].getWidth()) + 15);
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3[i].setHeight(32);
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3[i].setCenterPositionInScene((( gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length === 0 ) ? 0 :gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3[0].getCenterXInScene()),(( gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length === 0 ) ? 0 :gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3[0].getCenterYInScene()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) != "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3[i].hide(false);
}
}}

}


{



}


};gdjs.CharacterCreationCode.eventsList53 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("hoverInfo"), gdjs.CharacterCreationCode.GDhoverInfoObjects2);
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects2);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDlowerLeftObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDlowerLeftObjects2[i].setOpacity(125);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDhoverInfoObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDhoverInfoObjects2[i].setOpacity(125);
}
for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2[i].setOpacity(125);
}
}{for(var i = 0, len = gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2[i].setOpacity(62.5);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList51(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.CharacterCreationCode.eventsList52(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TransparentMessageTimer") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TransparentTextMessageSeconds"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66008860);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.asyncCallback68689988 = function (runtimeScene, asyncObjectsList) {
}
gdjs.CharacterCreationCode.eventsList54 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__LoadSDK.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68689988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList55 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(19).setString(gdjs.evtsExt__CrazyGamesAdApi__GetUserId.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "handle-login", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.asyncCallback68692468 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList55(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.CharacterCreationCode.eventsList56 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__UserSignIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68692468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(19).setString(gdjs.evtTools.common.toString(gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp")));
}{gdjs.evtTools.storage.writeStringInJSONFile("localSession", "guestLogin", gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "handle-login", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.eventsList58 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__CrazyGamesAdApi__UserSignedIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Retrieving data...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList56(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__CrazyGamesAdApi__UserSignedIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.CharacterCreationCode.asyncCallback68691356 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList58(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.CharacterCreationCode.eventsList59 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__GetUserSignIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68691356(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList60 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(19).setString(gdjs.evtsExt__CrazyGamesAdApi__GetUserId.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "handle-login", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.asyncCallback68696588 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList60(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.CharacterCreationCode.eventsList61 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__UserSignIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68696588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList62 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "handle-login", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.eventsList63 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__CrazyGamesAdApi__UserSignedIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Retrieving data...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList61(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__CrazyGamesAdApi__UserSignedIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList62(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.CharacterCreationCode.asyncCallback68695660 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList63(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.CharacterCreationCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__GetUserSignIn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68695660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList65 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), false);
}{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrieveUserCards.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Logging in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.asyncCallback68706844 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("ReviveInPlace"));
}}
gdjs.CharacterCreationCode.eventsList66 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__DisplayCrazyGamesAd.func(runtimeScene, "midgame", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68706844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList67 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) >= 60 * 3);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList66(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) < 60 * 3);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("ReviveInPlace"));
}}

}


};gdjs.CharacterCreationCode.eventsList68 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__CrazyGamesAdApi__IsSDKLoaded.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList67(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__CrazyGamesAdApi__IsSDKLoaded.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("ReviveInPlace"));
}}

}


};gdjs.CharacterCreationCode.eventsList69 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedDataString.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "pink";
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList68(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedDataString.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "yellow";
if (isConditionTrue_0) {
}

}


};gdjs.CharacterCreationCode.eventsList70 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedDataString.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "FinishedTutorial";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__DisplayHappyTime.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.asyncCallback68710932 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.CharacterCreationCode.eventsList71 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__DisplayCrazyGamesAd.func(runtimeScene, "rewarded", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68710932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.asyncCallback68713700 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}
gdjs.CharacterCreationCode.eventsList72 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__DisplayCrazyGamesAd.func(runtimeScene, "midgame", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.CharacterCreationCode.asyncCallback68713700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.CharacterCreationCode.eventsList73 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedDataString.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "changing room";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__CrazyGamesAdApi__IsSDKLoaded.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) >= 60 * 3);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList72(runtimeScene);} //End of subevents
}

}


};gdjs.CharacterCreationCode.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "login-as-guest";
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Signing in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList59(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "login-as-user";
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Signing in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList64(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "landing-page";
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "handle-login";
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList65(runtimeScene);} //End of subevents
}

}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "revived";
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList69(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "quest-event";
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList70(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "claim-ad-rewarded";
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList71(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "loading-start";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetLoadingStarted.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList73(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "loading-end";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetLoadingStopped.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "game-start";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetGameplayStarted.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "game-end";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetGameplayStoped.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.CharacterCreationCode.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.CharacterCreationCode.eventsList46(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList47(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("Attack");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("isOnNpcObject"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("chat");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("Blocked");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("Warp");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("pick");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CreateCharacterBackground"), gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CharacterCreationCode.GDbackButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("createButton"), gdjs.CharacterCreationCode.GDcreateButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.CharacterCreationCode.GDiconsObjects1);
gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.CharacterCreationCode.GDleftObjects1);
gdjs.copyArray(runtimeScene.getObjects("leftup"), gdjs.CharacterCreationCode.GDleftupObjects1);
gdjs.copyArray(runtimeScene.getObjects("lowerLeft"), gdjs.CharacterCreationCode.GDlowerLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("middle"), gdjs.CharacterCreationCode.GDmiddleObjects1);
gdjs.copyArray(runtimeScene.getObjects("rightmiddle"), gdjs.CharacterCreationCode.GDrightmiddleObjects1);
gdjs.copyArray(runtimeScene.getObjects("rightup"), gdjs.CharacterCreationCode.GDrightupObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CharacterCreationCode.mapOfGDgdjs_9546CharacterCreationCode_9546GDiconsObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDleftObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDmiddleObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightupObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDrightmiddleObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDlowerLeftObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDleftupObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDcreateButtonObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDbackButtonObjects1ObjectsGDgdjs_9546CharacterCreationCode_9546GDCreateCharacterBackgroundObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDiconsObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDiconsObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDiconsObjects1[k] = gdjs.CharacterCreationCode.GDiconsObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDiconsObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDleftObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDleftObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDleftObjects1[k] = gdjs.CharacterCreationCode.GDleftObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDleftObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDmiddleObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDmiddleObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDmiddleObjects1[k] = gdjs.CharacterCreationCode.GDmiddleObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDmiddleObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDrightupObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDrightupObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDrightupObjects1[k] = gdjs.CharacterCreationCode.GDrightupObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDrightupObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDrightmiddleObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDrightmiddleObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDrightmiddleObjects1[k] = gdjs.CharacterCreationCode.GDrightmiddleObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDrightmiddleObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDlowerLeftObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDlowerLeftObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDlowerLeftObjects1[k] = gdjs.CharacterCreationCode.GDlowerLeftObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDlowerLeftObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDleftupObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDleftupObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDleftupObjects1[k] = gdjs.CharacterCreationCode.GDleftupObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDleftupObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDcreateButtonObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDcreateButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDcreateButtonObjects1[k] = gdjs.CharacterCreationCode.GDcreateButtonObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDcreateButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDbackButtonObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDbackButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDbackButtonObjects1[k] = gdjs.CharacterCreationCode.GDbackButtonObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDbackButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1.length;i<l;++i) {
    if ( gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1[k] = gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1[i];
        ++k;
    }
}
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDbackButtonObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDcreateButtonObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDleftupObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDlowerLeftObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDrightmiddleObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDrightupObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDmiddleObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDleftObjects1.length === 0 ) ? (( gdjs.CharacterCreationCode.GDiconsObjects1.length === 0 ) ? "" :gdjs.CharacterCreationCode.GDiconsObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDleftObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDmiddleObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDrightupObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDrightmiddleObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDlowerLeftObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDleftupObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDcreateButtonObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDbackButtonObjects1[0].getLayer()) :gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1[0].getLayer()));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("Arrow");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UsingSkill"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("skill");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UsingDrill"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("dig");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.CharacterCreationCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.CharacterCreationCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.CharacterCreationCode.GDCursorsObjects1[i].setAnimationName("Hand");
}
}
{ //Subevents
gdjs.CharacterCreationCode.eventsList49(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(65582132);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList50(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.CharacterCreationCode.eventsList53(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.CharacterCreationCode.eventsList54(runtimeScene);} //End of subevents
}

}


{


let stopDoWhile_0 = false;
do {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__Notified.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.CharacterCreationCode.eventsList74(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};

gdjs.CharacterCreationCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CharacterCreationCode.GDGuideObjects1.length = 0;
gdjs.CharacterCreationCode.GDGuideObjects2.length = 0;
gdjs.CharacterCreationCode.GDGuideObjects3.length = 0;
gdjs.CharacterCreationCode.GDGuideObjects4.length = 0;
gdjs.CharacterCreationCode.GDGuideObjects5.length = 0;
gdjs.CharacterCreationCode.GDGuideObjects6.length = 0;
gdjs.CharacterCreationCode.GDGuideObjects7.length = 0;
gdjs.CharacterCreationCode.GDleftObjects1.length = 0;
gdjs.CharacterCreationCode.GDleftObjects2.length = 0;
gdjs.CharacterCreationCode.GDleftObjects3.length = 0;
gdjs.CharacterCreationCode.GDleftObjects4.length = 0;
gdjs.CharacterCreationCode.GDleftObjects5.length = 0;
gdjs.CharacterCreationCode.GDleftObjects6.length = 0;
gdjs.CharacterCreationCode.GDleftObjects7.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects1.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects2.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects3.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects4.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects5.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects6.length = 0;
gdjs.CharacterCreationCode.GDleftupObjects7.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects1.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects2.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects3.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects4.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects5.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects6.length = 0;
gdjs.CharacterCreationCode.GDmiddleObjects7.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects1.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects2.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects3.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects4.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects5.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects6.length = 0;
gdjs.CharacterCreationCode.GDlowerLeftObjects7.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects1.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects2.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects3.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects4.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects5.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects6.length = 0;
gdjs.CharacterCreationCode.GDpanelTitleObjects7.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects1.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects2.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects3.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects4.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects5.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects6.length = 0;
gdjs.CharacterCreationCode.GDpanelSubTitleObjects7.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects1.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects2.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects3.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects4.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects5.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects6.length = 0;
gdjs.CharacterCreationCode.GDpanelDescriptionObjects7.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects1.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects2.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects3.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects4.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects5.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects6.length = 0;
gdjs.CharacterCreationCode.GDrightupObjects7.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects1.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects2.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects3.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects4.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects5.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects6.length = 0;
gdjs.CharacterCreationCode.GDrightUpText1Objects7.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects1.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects2.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects3.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects4.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects5.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects6.length = 0;
gdjs.CharacterCreationCode.GDrightUpText2Objects7.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects1.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects2.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects3.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects4.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects5.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects6.length = 0;
gdjs.CharacterCreationCode.GDrightupInputObjects7.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects1.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects2.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects3.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects4.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects5.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects6.length = 0;
gdjs.CharacterCreationCode.GDrightmiddleObjects7.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects1.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects2.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects3.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects4.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects5.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects6.length = 0;
gdjs.CharacterCreationCode.GDcreateButtonObjects7.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects1.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects2.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects3.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects4.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects5.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects6.length = 0;
gdjs.CharacterCreationCode.GDbackButtonObjects7.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects1.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects2.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects3.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects4.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects5.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects6.length = 0;
gdjs.CharacterCreationCode.GDCreateCharacterBackgroundObjects7.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects1.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects2.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects3.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects4.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects5.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects6.length = 0;
gdjs.CharacterCreationCode.GDiconsObjects7.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects1.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects2.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects3.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects4.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects5.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects6.length = 0;
gdjs.CharacterCreationCode.GDBadgesObjects7.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects1.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects2.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects3.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects4.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects5.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects6.length = 0;
gdjs.CharacterCreationCode.GDArrowsObjects7.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects1.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects2.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects3.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects4.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects5.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects6.length = 0;
gdjs.CharacterCreationCode.GDnumbersObjects7.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects1.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects2.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects3.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects4.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects5.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects6.length = 0;
gdjs.CharacterCreationCode.GDrightMiddleTextObjects7.length = 0;
gdjs.CharacterCreationCode.GDundoObjects1.length = 0;
gdjs.CharacterCreationCode.GDundoObjects2.length = 0;
gdjs.CharacterCreationCode.GDundoObjects3.length = 0;
gdjs.CharacterCreationCode.GDundoObjects4.length = 0;
gdjs.CharacterCreationCode.GDundoObjects5.length = 0;
gdjs.CharacterCreationCode.GDundoObjects6.length = 0;
gdjs.CharacterCreationCode.GDundoObjects7.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects1.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects2.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects3.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects4.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects5.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects6.length = 0;
gdjs.CharacterCreationCode.GDdyesObjects7.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects1.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects2.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects3.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects4.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects5.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects6.length = 0;
gdjs.CharacterCreationCode.GDAvatarsObjects7.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects1.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects2.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects3.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects4.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects5.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects6.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoObjects7.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects1.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects2.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects3.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects4.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects5.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects6.length = 0;
gdjs.CharacterCreationCode.GDhoverTriggerObjects7.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects1.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects2.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects3.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects4.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects5.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects6.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextPowerObjects7.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects1.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects2.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects3.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects4.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects5.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects6.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextSenseObjects7.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects1.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects2.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects3.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects4.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects5.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects6.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextMagicObjects7.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects1.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects2.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects3.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects4.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects5.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects6.length = 0;
gdjs.CharacterCreationCode.GDhoverInfoTextCharmObjects7.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects1.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects2.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects3.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects4.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects5.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects6.length = 0;
gdjs.CharacterCreationCode.GDCursorsObjects7.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects1.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects2.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects3.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects4.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects5.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects6.length = 0;
gdjs.CharacterCreationCode.GDWarpzoneObjects7.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects1.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects2.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects3.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects4.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects5.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects6.length = 0;
gdjs.CharacterCreationCode.GDSpawningPointObjects7.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects1.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects2.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects3.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects4.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects5.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects6.length = 0;
gdjs.CharacterCreationCode.GDTransitionObjects7.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects1.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects2.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects3.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects4.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects5.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects6.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundObjects7.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects1.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects2.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects3.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects4.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects5.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects6.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundTextObjects7.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects1.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects2.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects3.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects4.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects5.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects6.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBackgroundObjects7.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects1.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects2.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects3.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects4.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects5.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects6.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementMaskObjects7.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects1.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects2.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects3.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects4.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects5.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects6.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementBitmapTextObjects7.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects1.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects2.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects3.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects4.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects5.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects6.length = 0;
gdjs.CharacterCreationCode.GDAnnouncementIconObjects7.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects1.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects2.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects3.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects4.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects5.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects6.length = 0;
gdjs.CharacterCreationCode.GDTransparentBackgroundText2Objects7.length = 0;

gdjs.CharacterCreationCode.eventsList75(runtimeScene);

return;

}

gdjs['CharacterCreationCode'] = gdjs.CharacterCreationCode;
