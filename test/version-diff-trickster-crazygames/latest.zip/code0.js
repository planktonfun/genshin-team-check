gdjs.LoginCode = {};
gdjs.LoginCode.GDOkayButtonObjects2_1final = [];

gdjs.LoginCode.forEachIndex3 = 0;

gdjs.LoginCode.forEachObjects3 = [];

gdjs.LoginCode.forEachTemporary3 = null;

gdjs.LoginCode.forEachTotalCount3 = 0;

gdjs.LoginCode.GDRestoreButtonObjects1= [];
gdjs.LoginCode.GDRestoreButtonObjects2= [];
gdjs.LoginCode.GDRestoreButtonObjects3= [];
gdjs.LoginCode.GDRestoreButtonObjects4= [];
gdjs.LoginCode.GDRestoreButtonObjects5= [];
gdjs.LoginCode.GDRestoreButtonObjects6= [];
gdjs.LoginCode.GDRestoreButtonObjects7= [];
gdjs.LoginCode.GDRestoreButtonObjects8= [];
gdjs.LoginCode.GDRestoreButtonObjects9= [];
gdjs.LoginCode.GDRestoreButtonObjects10= [];
gdjs.LoginCode.GDRestoreButtonObjects11= [];
gdjs.LoginCode.GDRestoreButtonObjects12= [];
gdjs.LoginCode.GDRestoreButtonObjects13= [];
gdjs.LoginCode.GDRestoreButtonObjects14= [];
gdjs.LoginCode.GDRestoreButtonObjects15= [];
gdjs.LoginCode.GDRestoreButtonObjects16= [];
gdjs.LoginCode.GDRestoreButtonObjects17= [];
gdjs.LoginCode.GDRestoreButtonObjects18= [];
gdjs.LoginCode.GDRestoreButtonObjects19= [];
gdjs.LoginCode.GDRestoreButtonObjects20= [];
gdjs.LoginCode.GDRestoreButtonObjects21= [];
gdjs.LoginCode.GDRestoreButtonObjects22= [];
gdjs.LoginCode.GDRestoreButtonObjects23= [];
gdjs.LoginCode.GDRestoreButtonObjects24= [];
gdjs.LoginCode.GDRestoreButtonObjects25= [];
gdjs.LoginCode.GDRestoreButtonObjects26= [];
gdjs.LoginCode.GDRestoreButtonObjects27= [];
gdjs.LoginCode.GDDeleteTextObjects1= [];
gdjs.LoginCode.GDDeleteTextObjects2= [];
gdjs.LoginCode.GDDeleteTextObjects3= [];
gdjs.LoginCode.GDDeleteTextObjects4= [];
gdjs.LoginCode.GDDeleteTextObjects5= [];
gdjs.LoginCode.GDDeleteTextObjects6= [];
gdjs.LoginCode.GDDeleteTextObjects7= [];
gdjs.LoginCode.GDDeleteTextObjects8= [];
gdjs.LoginCode.GDDeleteTextObjects9= [];
gdjs.LoginCode.GDDeleteTextObjects10= [];
gdjs.LoginCode.GDDeleteTextObjects11= [];
gdjs.LoginCode.GDDeleteTextObjects12= [];
gdjs.LoginCode.GDDeleteTextObjects13= [];
gdjs.LoginCode.GDDeleteTextObjects14= [];
gdjs.LoginCode.GDDeleteTextObjects15= [];
gdjs.LoginCode.GDDeleteTextObjects16= [];
gdjs.LoginCode.GDDeleteTextObjects17= [];
gdjs.LoginCode.GDDeleteTextObjects18= [];
gdjs.LoginCode.GDDeleteTextObjects19= [];
gdjs.LoginCode.GDDeleteTextObjects20= [];
gdjs.LoginCode.GDDeleteTextObjects21= [];
gdjs.LoginCode.GDDeleteTextObjects22= [];
gdjs.LoginCode.GDDeleteTextObjects23= [];
gdjs.LoginCode.GDDeleteTextObjects24= [];
gdjs.LoginCode.GDDeleteTextObjects25= [];
gdjs.LoginCode.GDDeleteTextObjects26= [];
gdjs.LoginCode.GDDeleteTextObjects27= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects1= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects2= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects3= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects4= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects5= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects6= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects7= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects8= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects9= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects10= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects11= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects12= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects13= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects14= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects15= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects16= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects17= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects18= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects19= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects20= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects21= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects22= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects23= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects24= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects25= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects26= [];
gdjs.LoginCode.GDDeleteTextBackgroundObjects27= [];
gdjs.LoginCode.GDLoadingScreenObjects1= [];
gdjs.LoginCode.GDLoadingScreenObjects2= [];
gdjs.LoginCode.GDLoadingScreenObjects3= [];
gdjs.LoginCode.GDLoadingScreenObjects4= [];
gdjs.LoginCode.GDLoadingScreenObjects5= [];
gdjs.LoginCode.GDLoadingScreenObjects6= [];
gdjs.LoginCode.GDLoadingScreenObjects7= [];
gdjs.LoginCode.GDLoadingScreenObjects8= [];
gdjs.LoginCode.GDLoadingScreenObjects9= [];
gdjs.LoginCode.GDLoadingScreenObjects10= [];
gdjs.LoginCode.GDLoadingScreenObjects11= [];
gdjs.LoginCode.GDLoadingScreenObjects12= [];
gdjs.LoginCode.GDLoadingScreenObjects13= [];
gdjs.LoginCode.GDLoadingScreenObjects14= [];
gdjs.LoginCode.GDLoadingScreenObjects15= [];
gdjs.LoginCode.GDLoadingScreenObjects16= [];
gdjs.LoginCode.GDLoadingScreenObjects17= [];
gdjs.LoginCode.GDLoadingScreenObjects18= [];
gdjs.LoginCode.GDLoadingScreenObjects19= [];
gdjs.LoginCode.GDLoadingScreenObjects20= [];
gdjs.LoginCode.GDLoadingScreenObjects21= [];
gdjs.LoginCode.GDLoadingScreenObjects22= [];
gdjs.LoginCode.GDLoadingScreenObjects23= [];
gdjs.LoginCode.GDLoadingScreenObjects24= [];
gdjs.LoginCode.GDLoadingScreenObjects25= [];
gdjs.LoginCode.GDLoadingScreenObjects26= [];
gdjs.LoginCode.GDLoadingScreenObjects27= [];
gdjs.LoginCode.GDPlayerNameTextObjects1= [];
gdjs.LoginCode.GDPlayerNameTextObjects2= [];
gdjs.LoginCode.GDPlayerNameTextObjects3= [];
gdjs.LoginCode.GDPlayerNameTextObjects4= [];
gdjs.LoginCode.GDPlayerNameTextObjects5= [];
gdjs.LoginCode.GDPlayerNameTextObjects6= [];
gdjs.LoginCode.GDPlayerNameTextObjects7= [];
gdjs.LoginCode.GDPlayerNameTextObjects8= [];
gdjs.LoginCode.GDPlayerNameTextObjects9= [];
gdjs.LoginCode.GDPlayerNameTextObjects10= [];
gdjs.LoginCode.GDPlayerNameTextObjects11= [];
gdjs.LoginCode.GDPlayerNameTextObjects12= [];
gdjs.LoginCode.GDPlayerNameTextObjects13= [];
gdjs.LoginCode.GDPlayerNameTextObjects14= [];
gdjs.LoginCode.GDPlayerNameTextObjects15= [];
gdjs.LoginCode.GDPlayerNameTextObjects16= [];
gdjs.LoginCode.GDPlayerNameTextObjects17= [];
gdjs.LoginCode.GDPlayerNameTextObjects18= [];
gdjs.LoginCode.GDPlayerNameTextObjects19= [];
gdjs.LoginCode.GDPlayerNameTextObjects20= [];
gdjs.LoginCode.GDPlayerNameTextObjects21= [];
gdjs.LoginCode.GDPlayerNameTextObjects22= [];
gdjs.LoginCode.GDPlayerNameTextObjects23= [];
gdjs.LoginCode.GDPlayerNameTextObjects24= [];
gdjs.LoginCode.GDPlayerNameTextObjects25= [];
gdjs.LoginCode.GDPlayerNameTextObjects26= [];
gdjs.LoginCode.GDPlayerNameTextObjects27= [];
gdjs.LoginCode.GDAvatarsObjects1= [];
gdjs.LoginCode.GDAvatarsObjects2= [];
gdjs.LoginCode.GDAvatarsObjects3= [];
gdjs.LoginCode.GDAvatarsObjects4= [];
gdjs.LoginCode.GDAvatarsObjects5= [];
gdjs.LoginCode.GDAvatarsObjects6= [];
gdjs.LoginCode.GDAvatarsObjects7= [];
gdjs.LoginCode.GDAvatarsObjects8= [];
gdjs.LoginCode.GDAvatarsObjects9= [];
gdjs.LoginCode.GDAvatarsObjects10= [];
gdjs.LoginCode.GDAvatarsObjects11= [];
gdjs.LoginCode.GDAvatarsObjects12= [];
gdjs.LoginCode.GDAvatarsObjects13= [];
gdjs.LoginCode.GDAvatarsObjects14= [];
gdjs.LoginCode.GDAvatarsObjects15= [];
gdjs.LoginCode.GDAvatarsObjects16= [];
gdjs.LoginCode.GDAvatarsObjects17= [];
gdjs.LoginCode.GDAvatarsObjects18= [];
gdjs.LoginCode.GDAvatarsObjects19= [];
gdjs.LoginCode.GDAvatarsObjects20= [];
gdjs.LoginCode.GDAvatarsObjects21= [];
gdjs.LoginCode.GDAvatarsObjects22= [];
gdjs.LoginCode.GDAvatarsObjects23= [];
gdjs.LoginCode.GDAvatarsObjects24= [];
gdjs.LoginCode.GDAvatarsObjects25= [];
gdjs.LoginCode.GDAvatarsObjects26= [];
gdjs.LoginCode.GDAvatarsObjects27= [];
gdjs.LoginCode.GDPlayerJobTextObjects1= [];
gdjs.LoginCode.GDPlayerJobTextObjects2= [];
gdjs.LoginCode.GDPlayerJobTextObjects3= [];
gdjs.LoginCode.GDPlayerJobTextObjects4= [];
gdjs.LoginCode.GDPlayerJobTextObjects5= [];
gdjs.LoginCode.GDPlayerJobTextObjects6= [];
gdjs.LoginCode.GDPlayerJobTextObjects7= [];
gdjs.LoginCode.GDPlayerJobTextObjects8= [];
gdjs.LoginCode.GDPlayerJobTextObjects9= [];
gdjs.LoginCode.GDPlayerJobTextObjects10= [];
gdjs.LoginCode.GDPlayerJobTextObjects11= [];
gdjs.LoginCode.GDPlayerJobTextObjects12= [];
gdjs.LoginCode.GDPlayerJobTextObjects13= [];
gdjs.LoginCode.GDPlayerJobTextObjects14= [];
gdjs.LoginCode.GDPlayerJobTextObjects15= [];
gdjs.LoginCode.GDPlayerJobTextObjects16= [];
gdjs.LoginCode.GDPlayerJobTextObjects17= [];
gdjs.LoginCode.GDPlayerJobTextObjects18= [];
gdjs.LoginCode.GDPlayerJobTextObjects19= [];
gdjs.LoginCode.GDPlayerJobTextObjects20= [];
gdjs.LoginCode.GDPlayerJobTextObjects21= [];
gdjs.LoginCode.GDPlayerJobTextObjects22= [];
gdjs.LoginCode.GDPlayerJobTextObjects23= [];
gdjs.LoginCode.GDPlayerJobTextObjects24= [];
gdjs.LoginCode.GDPlayerJobTextObjects25= [];
gdjs.LoginCode.GDPlayerJobTextObjects26= [];
gdjs.LoginCode.GDPlayerJobTextObjects27= [];
gdjs.LoginCode.GDPlayerTypeTextObjects1= [];
gdjs.LoginCode.GDPlayerTypeTextObjects2= [];
gdjs.LoginCode.GDPlayerTypeTextObjects3= [];
gdjs.LoginCode.GDPlayerTypeTextObjects4= [];
gdjs.LoginCode.GDPlayerTypeTextObjects5= [];
gdjs.LoginCode.GDPlayerTypeTextObjects6= [];
gdjs.LoginCode.GDPlayerTypeTextObjects7= [];
gdjs.LoginCode.GDPlayerTypeTextObjects8= [];
gdjs.LoginCode.GDPlayerTypeTextObjects9= [];
gdjs.LoginCode.GDPlayerTypeTextObjects10= [];
gdjs.LoginCode.GDPlayerTypeTextObjects11= [];
gdjs.LoginCode.GDPlayerTypeTextObjects12= [];
gdjs.LoginCode.GDPlayerTypeTextObjects13= [];
gdjs.LoginCode.GDPlayerTypeTextObjects14= [];
gdjs.LoginCode.GDPlayerTypeTextObjects15= [];
gdjs.LoginCode.GDPlayerTypeTextObjects16= [];
gdjs.LoginCode.GDPlayerTypeTextObjects17= [];
gdjs.LoginCode.GDPlayerTypeTextObjects18= [];
gdjs.LoginCode.GDPlayerTypeTextObjects19= [];
gdjs.LoginCode.GDPlayerTypeTextObjects20= [];
gdjs.LoginCode.GDPlayerTypeTextObjects21= [];
gdjs.LoginCode.GDPlayerTypeTextObjects22= [];
gdjs.LoginCode.GDPlayerTypeTextObjects23= [];
gdjs.LoginCode.GDPlayerTypeTextObjects24= [];
gdjs.LoginCode.GDPlayerTypeTextObjects25= [];
gdjs.LoginCode.GDPlayerTypeTextObjects26= [];
gdjs.LoginCode.GDPlayerTypeTextObjects27= [];
gdjs.LoginCode.GDPlayerLevelTextObjects1= [];
gdjs.LoginCode.GDPlayerLevelTextObjects2= [];
gdjs.LoginCode.GDPlayerLevelTextObjects3= [];
gdjs.LoginCode.GDPlayerLevelTextObjects4= [];
gdjs.LoginCode.GDPlayerLevelTextObjects5= [];
gdjs.LoginCode.GDPlayerLevelTextObjects6= [];
gdjs.LoginCode.GDPlayerLevelTextObjects7= [];
gdjs.LoginCode.GDPlayerLevelTextObjects8= [];
gdjs.LoginCode.GDPlayerLevelTextObjects9= [];
gdjs.LoginCode.GDPlayerLevelTextObjects10= [];
gdjs.LoginCode.GDPlayerLevelTextObjects11= [];
gdjs.LoginCode.GDPlayerLevelTextObjects12= [];
gdjs.LoginCode.GDPlayerLevelTextObjects13= [];
gdjs.LoginCode.GDPlayerLevelTextObjects14= [];
gdjs.LoginCode.GDPlayerLevelTextObjects15= [];
gdjs.LoginCode.GDPlayerLevelTextObjects16= [];
gdjs.LoginCode.GDPlayerLevelTextObjects17= [];
gdjs.LoginCode.GDPlayerLevelTextObjects18= [];
gdjs.LoginCode.GDPlayerLevelTextObjects19= [];
gdjs.LoginCode.GDPlayerLevelTextObjects20= [];
gdjs.LoginCode.GDPlayerLevelTextObjects21= [];
gdjs.LoginCode.GDPlayerLevelTextObjects22= [];
gdjs.LoginCode.GDPlayerLevelTextObjects23= [];
gdjs.LoginCode.GDPlayerLevelTextObjects24= [];
gdjs.LoginCode.GDPlayerLevelTextObjects25= [];
gdjs.LoginCode.GDPlayerLevelTextObjects26= [];
gdjs.LoginCode.GDPlayerLevelTextObjects27= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects1= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects2= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects3= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects4= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects5= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects6= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects7= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects8= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects9= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects10= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects11= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects12= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects13= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects14= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects15= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects16= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects17= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects18= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects19= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects20= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects21= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects22= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects23= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects24= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects25= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects26= [];
gdjs.LoginCode.GDPlayerGaldersTextObjects27= [];
gdjs.LoginCode.GDStartButtonObjects1= [];
gdjs.LoginCode.GDStartButtonObjects2= [];
gdjs.LoginCode.GDStartButtonObjects3= [];
gdjs.LoginCode.GDStartButtonObjects4= [];
gdjs.LoginCode.GDStartButtonObjects5= [];
gdjs.LoginCode.GDStartButtonObjects6= [];
gdjs.LoginCode.GDStartButtonObjects7= [];
gdjs.LoginCode.GDStartButtonObjects8= [];
gdjs.LoginCode.GDStartButtonObjects9= [];
gdjs.LoginCode.GDStartButtonObjects10= [];
gdjs.LoginCode.GDStartButtonObjects11= [];
gdjs.LoginCode.GDStartButtonObjects12= [];
gdjs.LoginCode.GDStartButtonObjects13= [];
gdjs.LoginCode.GDStartButtonObjects14= [];
gdjs.LoginCode.GDStartButtonObjects15= [];
gdjs.LoginCode.GDStartButtonObjects16= [];
gdjs.LoginCode.GDStartButtonObjects17= [];
gdjs.LoginCode.GDStartButtonObjects18= [];
gdjs.LoginCode.GDStartButtonObjects19= [];
gdjs.LoginCode.GDStartButtonObjects20= [];
gdjs.LoginCode.GDStartButtonObjects21= [];
gdjs.LoginCode.GDStartButtonObjects22= [];
gdjs.LoginCode.GDStartButtonObjects23= [];
gdjs.LoginCode.GDStartButtonObjects24= [];
gdjs.LoginCode.GDStartButtonObjects25= [];
gdjs.LoginCode.GDStartButtonObjects26= [];
gdjs.LoginCode.GDStartButtonObjects27= [];
gdjs.LoginCode.GDNicknameObjects1= [];
gdjs.LoginCode.GDNicknameObjects2= [];
gdjs.LoginCode.GDNicknameObjects3= [];
gdjs.LoginCode.GDNicknameObjects4= [];
gdjs.LoginCode.GDNicknameObjects5= [];
gdjs.LoginCode.GDNicknameObjects6= [];
gdjs.LoginCode.GDNicknameObjects7= [];
gdjs.LoginCode.GDNicknameObjects8= [];
gdjs.LoginCode.GDNicknameObjects9= [];
gdjs.LoginCode.GDNicknameObjects10= [];
gdjs.LoginCode.GDNicknameObjects11= [];
gdjs.LoginCode.GDNicknameObjects12= [];
gdjs.LoginCode.GDNicknameObjects13= [];
gdjs.LoginCode.GDNicknameObjects14= [];
gdjs.LoginCode.GDNicknameObjects15= [];
gdjs.LoginCode.GDNicknameObjects16= [];
gdjs.LoginCode.GDNicknameObjects17= [];
gdjs.LoginCode.GDNicknameObjects18= [];
gdjs.LoginCode.GDNicknameObjects19= [];
gdjs.LoginCode.GDNicknameObjects20= [];
gdjs.LoginCode.GDNicknameObjects21= [];
gdjs.LoginCode.GDNicknameObjects22= [];
gdjs.LoginCode.GDNicknameObjects23= [];
gdjs.LoginCode.GDNicknameObjects24= [];
gdjs.LoginCode.GDNicknameObjects25= [];
gdjs.LoginCode.GDNicknameObjects26= [];
gdjs.LoginCode.GDNicknameObjects27= [];
gdjs.LoginCode.GDLoginButtonObjects1= [];
gdjs.LoginCode.GDLoginButtonObjects2= [];
gdjs.LoginCode.GDLoginButtonObjects3= [];
gdjs.LoginCode.GDLoginButtonObjects4= [];
gdjs.LoginCode.GDLoginButtonObjects5= [];
gdjs.LoginCode.GDLoginButtonObjects6= [];
gdjs.LoginCode.GDLoginButtonObjects7= [];
gdjs.LoginCode.GDLoginButtonObjects8= [];
gdjs.LoginCode.GDLoginButtonObjects9= [];
gdjs.LoginCode.GDLoginButtonObjects10= [];
gdjs.LoginCode.GDLoginButtonObjects11= [];
gdjs.LoginCode.GDLoginButtonObjects12= [];
gdjs.LoginCode.GDLoginButtonObjects13= [];
gdjs.LoginCode.GDLoginButtonObjects14= [];
gdjs.LoginCode.GDLoginButtonObjects15= [];
gdjs.LoginCode.GDLoginButtonObjects16= [];
gdjs.LoginCode.GDLoginButtonObjects17= [];
gdjs.LoginCode.GDLoginButtonObjects18= [];
gdjs.LoginCode.GDLoginButtonObjects19= [];
gdjs.LoginCode.GDLoginButtonObjects20= [];
gdjs.LoginCode.GDLoginButtonObjects21= [];
gdjs.LoginCode.GDLoginButtonObjects22= [];
gdjs.LoginCode.GDLoginButtonObjects23= [];
gdjs.LoginCode.GDLoginButtonObjects24= [];
gdjs.LoginCode.GDLoginButtonObjects25= [];
gdjs.LoginCode.GDLoginButtonObjects26= [];
gdjs.LoginCode.GDLoginButtonObjects27= [];
gdjs.LoginCode.GDLoginButton2Objects1= [];
gdjs.LoginCode.GDLoginButton2Objects2= [];
gdjs.LoginCode.GDLoginButton2Objects3= [];
gdjs.LoginCode.GDLoginButton2Objects4= [];
gdjs.LoginCode.GDLoginButton2Objects5= [];
gdjs.LoginCode.GDLoginButton2Objects6= [];
gdjs.LoginCode.GDLoginButton2Objects7= [];
gdjs.LoginCode.GDLoginButton2Objects8= [];
gdjs.LoginCode.GDLoginButton2Objects9= [];
gdjs.LoginCode.GDLoginButton2Objects10= [];
gdjs.LoginCode.GDLoginButton2Objects11= [];
gdjs.LoginCode.GDLoginButton2Objects12= [];
gdjs.LoginCode.GDLoginButton2Objects13= [];
gdjs.LoginCode.GDLoginButton2Objects14= [];
gdjs.LoginCode.GDLoginButton2Objects15= [];
gdjs.LoginCode.GDLoginButton2Objects16= [];
gdjs.LoginCode.GDLoginButton2Objects17= [];
gdjs.LoginCode.GDLoginButton2Objects18= [];
gdjs.LoginCode.GDLoginButton2Objects19= [];
gdjs.LoginCode.GDLoginButton2Objects20= [];
gdjs.LoginCode.GDLoginButton2Objects21= [];
gdjs.LoginCode.GDLoginButton2Objects22= [];
gdjs.LoginCode.GDLoginButton2Objects23= [];
gdjs.LoginCode.GDLoginButton2Objects24= [];
gdjs.LoginCode.GDLoginButton2Objects25= [];
gdjs.LoginCode.GDLoginButton2Objects26= [];
gdjs.LoginCode.GDLoginButton2Objects27= [];
gdjs.LoginCode.GDExitButtonObjects1= [];
gdjs.LoginCode.GDExitButtonObjects2= [];
gdjs.LoginCode.GDExitButtonObjects3= [];
gdjs.LoginCode.GDExitButtonObjects4= [];
gdjs.LoginCode.GDExitButtonObjects5= [];
gdjs.LoginCode.GDExitButtonObjects6= [];
gdjs.LoginCode.GDExitButtonObjects7= [];
gdjs.LoginCode.GDExitButtonObjects8= [];
gdjs.LoginCode.GDExitButtonObjects9= [];
gdjs.LoginCode.GDExitButtonObjects10= [];
gdjs.LoginCode.GDExitButtonObjects11= [];
gdjs.LoginCode.GDExitButtonObjects12= [];
gdjs.LoginCode.GDExitButtonObjects13= [];
gdjs.LoginCode.GDExitButtonObjects14= [];
gdjs.LoginCode.GDExitButtonObjects15= [];
gdjs.LoginCode.GDExitButtonObjects16= [];
gdjs.LoginCode.GDExitButtonObjects17= [];
gdjs.LoginCode.GDExitButtonObjects18= [];
gdjs.LoginCode.GDExitButtonObjects19= [];
gdjs.LoginCode.GDExitButtonObjects20= [];
gdjs.LoginCode.GDExitButtonObjects21= [];
gdjs.LoginCode.GDExitButtonObjects22= [];
gdjs.LoginCode.GDExitButtonObjects23= [];
gdjs.LoginCode.GDExitButtonObjects24= [];
gdjs.LoginCode.GDExitButtonObjects25= [];
gdjs.LoginCode.GDExitButtonObjects26= [];
gdjs.LoginCode.GDExitButtonObjects27= [];
gdjs.LoginCode.GDLoginTextObjects1= [];
gdjs.LoginCode.GDLoginTextObjects2= [];
gdjs.LoginCode.GDLoginTextObjects3= [];
gdjs.LoginCode.GDLoginTextObjects4= [];
gdjs.LoginCode.GDLoginTextObjects5= [];
gdjs.LoginCode.GDLoginTextObjects6= [];
gdjs.LoginCode.GDLoginTextObjects7= [];
gdjs.LoginCode.GDLoginTextObjects8= [];
gdjs.LoginCode.GDLoginTextObjects9= [];
gdjs.LoginCode.GDLoginTextObjects10= [];
gdjs.LoginCode.GDLoginTextObjects11= [];
gdjs.LoginCode.GDLoginTextObjects12= [];
gdjs.LoginCode.GDLoginTextObjects13= [];
gdjs.LoginCode.GDLoginTextObjects14= [];
gdjs.LoginCode.GDLoginTextObjects15= [];
gdjs.LoginCode.GDLoginTextObjects16= [];
gdjs.LoginCode.GDLoginTextObjects17= [];
gdjs.LoginCode.GDLoginTextObjects18= [];
gdjs.LoginCode.GDLoginTextObjects19= [];
gdjs.LoginCode.GDLoginTextObjects20= [];
gdjs.LoginCode.GDLoginTextObjects21= [];
gdjs.LoginCode.GDLoginTextObjects22= [];
gdjs.LoginCode.GDLoginTextObjects23= [];
gdjs.LoginCode.GDLoginTextObjects24= [];
gdjs.LoginCode.GDLoginTextObjects25= [];
gdjs.LoginCode.GDLoginTextObjects26= [];
gdjs.LoginCode.GDLoginTextObjects27= [];
gdjs.LoginCode.GDLoginText2Objects1= [];
gdjs.LoginCode.GDLoginText2Objects2= [];
gdjs.LoginCode.GDLoginText2Objects3= [];
gdjs.LoginCode.GDLoginText2Objects4= [];
gdjs.LoginCode.GDLoginText2Objects5= [];
gdjs.LoginCode.GDLoginText2Objects6= [];
gdjs.LoginCode.GDLoginText2Objects7= [];
gdjs.LoginCode.GDLoginText2Objects8= [];
gdjs.LoginCode.GDLoginText2Objects9= [];
gdjs.LoginCode.GDLoginText2Objects10= [];
gdjs.LoginCode.GDLoginText2Objects11= [];
gdjs.LoginCode.GDLoginText2Objects12= [];
gdjs.LoginCode.GDLoginText2Objects13= [];
gdjs.LoginCode.GDLoginText2Objects14= [];
gdjs.LoginCode.GDLoginText2Objects15= [];
gdjs.LoginCode.GDLoginText2Objects16= [];
gdjs.LoginCode.GDLoginText2Objects17= [];
gdjs.LoginCode.GDLoginText2Objects18= [];
gdjs.LoginCode.GDLoginText2Objects19= [];
gdjs.LoginCode.GDLoginText2Objects20= [];
gdjs.LoginCode.GDLoginText2Objects21= [];
gdjs.LoginCode.GDLoginText2Objects22= [];
gdjs.LoginCode.GDLoginText2Objects23= [];
gdjs.LoginCode.GDLoginText2Objects24= [];
gdjs.LoginCode.GDLoginText2Objects25= [];
gdjs.LoginCode.GDLoginText2Objects26= [];
gdjs.LoginCode.GDLoginText2Objects27= [];
gdjs.LoginCode.GDExitTextObjects1= [];
gdjs.LoginCode.GDExitTextObjects2= [];
gdjs.LoginCode.GDExitTextObjects3= [];
gdjs.LoginCode.GDExitTextObjects4= [];
gdjs.LoginCode.GDExitTextObjects5= [];
gdjs.LoginCode.GDExitTextObjects6= [];
gdjs.LoginCode.GDExitTextObjects7= [];
gdjs.LoginCode.GDExitTextObjects8= [];
gdjs.LoginCode.GDExitTextObjects9= [];
gdjs.LoginCode.GDExitTextObjects10= [];
gdjs.LoginCode.GDExitTextObjects11= [];
gdjs.LoginCode.GDExitTextObjects12= [];
gdjs.LoginCode.GDExitTextObjects13= [];
gdjs.LoginCode.GDExitTextObjects14= [];
gdjs.LoginCode.GDExitTextObjects15= [];
gdjs.LoginCode.GDExitTextObjects16= [];
gdjs.LoginCode.GDExitTextObjects17= [];
gdjs.LoginCode.GDExitTextObjects18= [];
gdjs.LoginCode.GDExitTextObjects19= [];
gdjs.LoginCode.GDExitTextObjects20= [];
gdjs.LoginCode.GDExitTextObjects21= [];
gdjs.LoginCode.GDExitTextObjects22= [];
gdjs.LoginCode.GDExitTextObjects23= [];
gdjs.LoginCode.GDExitTextObjects24= [];
gdjs.LoginCode.GDExitTextObjects25= [];
gdjs.LoginCode.GDExitTextObjects26= [];
gdjs.LoginCode.GDExitTextObjects27= [];
gdjs.LoginCode.GDloadingImgObjects1= [];
gdjs.LoginCode.GDloadingImgObjects2= [];
gdjs.LoginCode.GDloadingImgObjects3= [];
gdjs.LoginCode.GDloadingImgObjects4= [];
gdjs.LoginCode.GDloadingImgObjects5= [];
gdjs.LoginCode.GDloadingImgObjects6= [];
gdjs.LoginCode.GDloadingImgObjects7= [];
gdjs.LoginCode.GDloadingImgObjects8= [];
gdjs.LoginCode.GDloadingImgObjects9= [];
gdjs.LoginCode.GDloadingImgObjects10= [];
gdjs.LoginCode.GDloadingImgObjects11= [];
gdjs.LoginCode.GDloadingImgObjects12= [];
gdjs.LoginCode.GDloadingImgObjects13= [];
gdjs.LoginCode.GDloadingImgObjects14= [];
gdjs.LoginCode.GDloadingImgObjects15= [];
gdjs.LoginCode.GDloadingImgObjects16= [];
gdjs.LoginCode.GDloadingImgObjects17= [];
gdjs.LoginCode.GDloadingImgObjects18= [];
gdjs.LoginCode.GDloadingImgObjects19= [];
gdjs.LoginCode.GDloadingImgObjects20= [];
gdjs.LoginCode.GDloadingImgObjects21= [];
gdjs.LoginCode.GDloadingImgObjects22= [];
gdjs.LoginCode.GDloadingImgObjects23= [];
gdjs.LoginCode.GDloadingImgObjects24= [];
gdjs.LoginCode.GDloadingImgObjects25= [];
gdjs.LoginCode.GDloadingImgObjects26= [];
gdjs.LoginCode.GDloadingImgObjects27= [];
gdjs.LoginCode.GDNewTiledSpriteObjects1= [];
gdjs.LoginCode.GDNewTiledSpriteObjects2= [];
gdjs.LoginCode.GDNewTiledSpriteObjects3= [];
gdjs.LoginCode.GDNewTiledSpriteObjects4= [];
gdjs.LoginCode.GDNewTiledSpriteObjects5= [];
gdjs.LoginCode.GDNewTiledSpriteObjects6= [];
gdjs.LoginCode.GDNewTiledSpriteObjects7= [];
gdjs.LoginCode.GDNewTiledSpriteObjects8= [];
gdjs.LoginCode.GDNewTiledSpriteObjects9= [];
gdjs.LoginCode.GDNewTiledSpriteObjects10= [];
gdjs.LoginCode.GDNewTiledSpriteObjects11= [];
gdjs.LoginCode.GDNewTiledSpriteObjects12= [];
gdjs.LoginCode.GDNewTiledSpriteObjects13= [];
gdjs.LoginCode.GDNewTiledSpriteObjects14= [];
gdjs.LoginCode.GDNewTiledSpriteObjects15= [];
gdjs.LoginCode.GDNewTiledSpriteObjects16= [];
gdjs.LoginCode.GDNewTiledSpriteObjects17= [];
gdjs.LoginCode.GDNewTiledSpriteObjects18= [];
gdjs.LoginCode.GDNewTiledSpriteObjects19= [];
gdjs.LoginCode.GDNewTiledSpriteObjects20= [];
gdjs.LoginCode.GDNewTiledSpriteObjects21= [];
gdjs.LoginCode.GDNewTiledSpriteObjects22= [];
gdjs.LoginCode.GDNewTiledSpriteObjects23= [];
gdjs.LoginCode.GDNewTiledSpriteObjects24= [];
gdjs.LoginCode.GDNewTiledSpriteObjects25= [];
gdjs.LoginCode.GDNewTiledSpriteObjects26= [];
gdjs.LoginCode.GDNewTiledSpriteObjects27= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects1= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects2= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects3= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects4= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects5= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects6= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects7= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects8= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects9= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects10= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects11= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects12= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects13= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects14= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects15= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects16= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects17= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects18= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects19= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects20= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects21= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects22= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects23= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects24= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects25= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects26= [];
gdjs.LoginCode.GDCharacterSelectBackgroundObjects27= [];
gdjs.LoginCode.GDSelectedObjects1= [];
gdjs.LoginCode.GDSelectedObjects2= [];
gdjs.LoginCode.GDSelectedObjects3= [];
gdjs.LoginCode.GDSelectedObjects4= [];
gdjs.LoginCode.GDSelectedObjects5= [];
gdjs.LoginCode.GDSelectedObjects6= [];
gdjs.LoginCode.GDSelectedObjects7= [];
gdjs.LoginCode.GDSelectedObjects8= [];
gdjs.LoginCode.GDSelectedObjects9= [];
gdjs.LoginCode.GDSelectedObjects10= [];
gdjs.LoginCode.GDSelectedObjects11= [];
gdjs.LoginCode.GDSelectedObjects12= [];
gdjs.LoginCode.GDSelectedObjects13= [];
gdjs.LoginCode.GDSelectedObjects14= [];
gdjs.LoginCode.GDSelectedObjects15= [];
gdjs.LoginCode.GDSelectedObjects16= [];
gdjs.LoginCode.GDSelectedObjects17= [];
gdjs.LoginCode.GDSelectedObjects18= [];
gdjs.LoginCode.GDSelectedObjects19= [];
gdjs.LoginCode.GDSelectedObjects20= [];
gdjs.LoginCode.GDSelectedObjects21= [];
gdjs.LoginCode.GDSelectedObjects22= [];
gdjs.LoginCode.GDSelectedObjects23= [];
gdjs.LoginCode.GDSelectedObjects24= [];
gdjs.LoginCode.GDSelectedObjects25= [];
gdjs.LoginCode.GDSelectedObjects26= [];
gdjs.LoginCode.GDSelectedObjects27= [];
gdjs.LoginCode.GDCardsBackgroundObjects1= [];
gdjs.LoginCode.GDCardsBackgroundObjects2= [];
gdjs.LoginCode.GDCardsBackgroundObjects3= [];
gdjs.LoginCode.GDCardsBackgroundObjects4= [];
gdjs.LoginCode.GDCardsBackgroundObjects5= [];
gdjs.LoginCode.GDCardsBackgroundObjects6= [];
gdjs.LoginCode.GDCardsBackgroundObjects7= [];
gdjs.LoginCode.GDCardsBackgroundObjects8= [];
gdjs.LoginCode.GDCardsBackgroundObjects9= [];
gdjs.LoginCode.GDCardsBackgroundObjects10= [];
gdjs.LoginCode.GDCardsBackgroundObjects11= [];
gdjs.LoginCode.GDCardsBackgroundObjects12= [];
gdjs.LoginCode.GDCardsBackgroundObjects13= [];
gdjs.LoginCode.GDCardsBackgroundObjects14= [];
gdjs.LoginCode.GDCardsBackgroundObjects15= [];
gdjs.LoginCode.GDCardsBackgroundObjects16= [];
gdjs.LoginCode.GDCardsBackgroundObjects17= [];
gdjs.LoginCode.GDCardsBackgroundObjects18= [];
gdjs.LoginCode.GDCardsBackgroundObjects19= [];
gdjs.LoginCode.GDCardsBackgroundObjects20= [];
gdjs.LoginCode.GDCardsBackgroundObjects21= [];
gdjs.LoginCode.GDCardsBackgroundObjects22= [];
gdjs.LoginCode.GDCardsBackgroundObjects23= [];
gdjs.LoginCode.GDCardsBackgroundObjects24= [];
gdjs.LoginCode.GDCardsBackgroundObjects25= [];
gdjs.LoginCode.GDCardsBackgroundObjects26= [];
gdjs.LoginCode.GDCardsBackgroundObjects27= [];
gdjs.LoginCode.GDcreateCharacterObjects1= [];
gdjs.LoginCode.GDcreateCharacterObjects2= [];
gdjs.LoginCode.GDcreateCharacterObjects3= [];
gdjs.LoginCode.GDcreateCharacterObjects4= [];
gdjs.LoginCode.GDcreateCharacterObjects5= [];
gdjs.LoginCode.GDcreateCharacterObjects6= [];
gdjs.LoginCode.GDcreateCharacterObjects7= [];
gdjs.LoginCode.GDcreateCharacterObjects8= [];
gdjs.LoginCode.GDcreateCharacterObjects9= [];
gdjs.LoginCode.GDcreateCharacterObjects10= [];
gdjs.LoginCode.GDcreateCharacterObjects11= [];
gdjs.LoginCode.GDcreateCharacterObjects12= [];
gdjs.LoginCode.GDcreateCharacterObjects13= [];
gdjs.LoginCode.GDcreateCharacterObjects14= [];
gdjs.LoginCode.GDcreateCharacterObjects15= [];
gdjs.LoginCode.GDcreateCharacterObjects16= [];
gdjs.LoginCode.GDcreateCharacterObjects17= [];
gdjs.LoginCode.GDcreateCharacterObjects18= [];
gdjs.LoginCode.GDcreateCharacterObjects19= [];
gdjs.LoginCode.GDcreateCharacterObjects20= [];
gdjs.LoginCode.GDcreateCharacterObjects21= [];
gdjs.LoginCode.GDcreateCharacterObjects22= [];
gdjs.LoginCode.GDcreateCharacterObjects23= [];
gdjs.LoginCode.GDcreateCharacterObjects24= [];
gdjs.LoginCode.GDcreateCharacterObjects25= [];
gdjs.LoginCode.GDcreateCharacterObjects26= [];
gdjs.LoginCode.GDcreateCharacterObjects27= [];
gdjs.LoginCode.GDdeleteButtonObjects1= [];
gdjs.LoginCode.GDdeleteButtonObjects2= [];
gdjs.LoginCode.GDdeleteButtonObjects3= [];
gdjs.LoginCode.GDdeleteButtonObjects4= [];
gdjs.LoginCode.GDdeleteButtonObjects5= [];
gdjs.LoginCode.GDdeleteButtonObjects6= [];
gdjs.LoginCode.GDdeleteButtonObjects7= [];
gdjs.LoginCode.GDdeleteButtonObjects8= [];
gdjs.LoginCode.GDdeleteButtonObjects9= [];
gdjs.LoginCode.GDdeleteButtonObjects10= [];
gdjs.LoginCode.GDdeleteButtonObjects11= [];
gdjs.LoginCode.GDdeleteButtonObjects12= [];
gdjs.LoginCode.GDdeleteButtonObjects13= [];
gdjs.LoginCode.GDdeleteButtonObjects14= [];
gdjs.LoginCode.GDdeleteButtonObjects15= [];
gdjs.LoginCode.GDdeleteButtonObjects16= [];
gdjs.LoginCode.GDdeleteButtonObjects17= [];
gdjs.LoginCode.GDdeleteButtonObjects18= [];
gdjs.LoginCode.GDdeleteButtonObjects19= [];
gdjs.LoginCode.GDdeleteButtonObjects20= [];
gdjs.LoginCode.GDdeleteButtonObjects21= [];
gdjs.LoginCode.GDdeleteButtonObjects22= [];
gdjs.LoginCode.GDdeleteButtonObjects23= [];
gdjs.LoginCode.GDdeleteButtonObjects24= [];
gdjs.LoginCode.GDdeleteButtonObjects25= [];
gdjs.LoginCode.GDdeleteButtonObjects26= [];
gdjs.LoginCode.GDdeleteButtonObjects27= [];
gdjs.LoginCode.GDOkayButtonObjects1= [];
gdjs.LoginCode.GDOkayButtonObjects2= [];
gdjs.LoginCode.GDOkayButtonObjects3= [];
gdjs.LoginCode.GDOkayButtonObjects4= [];
gdjs.LoginCode.GDOkayButtonObjects5= [];
gdjs.LoginCode.GDOkayButtonObjects6= [];
gdjs.LoginCode.GDOkayButtonObjects7= [];
gdjs.LoginCode.GDOkayButtonObjects8= [];
gdjs.LoginCode.GDOkayButtonObjects9= [];
gdjs.LoginCode.GDOkayButtonObjects10= [];
gdjs.LoginCode.GDOkayButtonObjects11= [];
gdjs.LoginCode.GDOkayButtonObjects12= [];
gdjs.LoginCode.GDOkayButtonObjects13= [];
gdjs.LoginCode.GDOkayButtonObjects14= [];
gdjs.LoginCode.GDOkayButtonObjects15= [];
gdjs.LoginCode.GDOkayButtonObjects16= [];
gdjs.LoginCode.GDOkayButtonObjects17= [];
gdjs.LoginCode.GDOkayButtonObjects18= [];
gdjs.LoginCode.GDOkayButtonObjects19= [];
gdjs.LoginCode.GDOkayButtonObjects20= [];
gdjs.LoginCode.GDOkayButtonObjects21= [];
gdjs.LoginCode.GDOkayButtonObjects22= [];
gdjs.LoginCode.GDOkayButtonObjects23= [];
gdjs.LoginCode.GDOkayButtonObjects24= [];
gdjs.LoginCode.GDOkayButtonObjects25= [];
gdjs.LoginCode.GDOkayButtonObjects26= [];
gdjs.LoginCode.GDOkayButtonObjects27= [];
gdjs.LoginCode.GDBackButtonObjects1= [];
gdjs.LoginCode.GDBackButtonObjects2= [];
gdjs.LoginCode.GDBackButtonObjects3= [];
gdjs.LoginCode.GDBackButtonObjects4= [];
gdjs.LoginCode.GDBackButtonObjects5= [];
gdjs.LoginCode.GDBackButtonObjects6= [];
gdjs.LoginCode.GDBackButtonObjects7= [];
gdjs.LoginCode.GDBackButtonObjects8= [];
gdjs.LoginCode.GDBackButtonObjects9= [];
gdjs.LoginCode.GDBackButtonObjects10= [];
gdjs.LoginCode.GDBackButtonObjects11= [];
gdjs.LoginCode.GDBackButtonObjects12= [];
gdjs.LoginCode.GDBackButtonObjects13= [];
gdjs.LoginCode.GDBackButtonObjects14= [];
gdjs.LoginCode.GDBackButtonObjects15= [];
gdjs.LoginCode.GDBackButtonObjects16= [];
gdjs.LoginCode.GDBackButtonObjects17= [];
gdjs.LoginCode.GDBackButtonObjects18= [];
gdjs.LoginCode.GDBackButtonObjects19= [];
gdjs.LoginCode.GDBackButtonObjects20= [];
gdjs.LoginCode.GDBackButtonObjects21= [];
gdjs.LoginCode.GDBackButtonObjects22= [];
gdjs.LoginCode.GDBackButtonObjects23= [];
gdjs.LoginCode.GDBackButtonObjects24= [];
gdjs.LoginCode.GDBackButtonObjects25= [];
gdjs.LoginCode.GDBackButtonObjects26= [];
gdjs.LoginCode.GDBackButtonObjects27= [];
gdjs.LoginCode.GDCursorsObjects1= [];
gdjs.LoginCode.GDCursorsObjects2= [];
gdjs.LoginCode.GDCursorsObjects3= [];
gdjs.LoginCode.GDCursorsObjects4= [];
gdjs.LoginCode.GDCursorsObjects5= [];
gdjs.LoginCode.GDCursorsObjects6= [];
gdjs.LoginCode.GDCursorsObjects7= [];
gdjs.LoginCode.GDCursorsObjects8= [];
gdjs.LoginCode.GDCursorsObjects9= [];
gdjs.LoginCode.GDCursorsObjects10= [];
gdjs.LoginCode.GDCursorsObjects11= [];
gdjs.LoginCode.GDCursorsObjects12= [];
gdjs.LoginCode.GDCursorsObjects13= [];
gdjs.LoginCode.GDCursorsObjects14= [];
gdjs.LoginCode.GDCursorsObjects15= [];
gdjs.LoginCode.GDCursorsObjects16= [];
gdjs.LoginCode.GDCursorsObjects17= [];
gdjs.LoginCode.GDCursorsObjects18= [];
gdjs.LoginCode.GDCursorsObjects19= [];
gdjs.LoginCode.GDCursorsObjects20= [];
gdjs.LoginCode.GDCursorsObjects21= [];
gdjs.LoginCode.GDCursorsObjects22= [];
gdjs.LoginCode.GDCursorsObjects23= [];
gdjs.LoginCode.GDCursorsObjects24= [];
gdjs.LoginCode.GDCursorsObjects25= [];
gdjs.LoginCode.GDCursorsObjects26= [];
gdjs.LoginCode.GDCursorsObjects27= [];
gdjs.LoginCode.GDWarpzoneObjects1= [];
gdjs.LoginCode.GDWarpzoneObjects2= [];
gdjs.LoginCode.GDWarpzoneObjects3= [];
gdjs.LoginCode.GDWarpzoneObjects4= [];
gdjs.LoginCode.GDWarpzoneObjects5= [];
gdjs.LoginCode.GDWarpzoneObjects6= [];
gdjs.LoginCode.GDWarpzoneObjects7= [];
gdjs.LoginCode.GDWarpzoneObjects8= [];
gdjs.LoginCode.GDWarpzoneObjects9= [];
gdjs.LoginCode.GDWarpzoneObjects10= [];
gdjs.LoginCode.GDWarpzoneObjects11= [];
gdjs.LoginCode.GDWarpzoneObjects12= [];
gdjs.LoginCode.GDWarpzoneObjects13= [];
gdjs.LoginCode.GDWarpzoneObjects14= [];
gdjs.LoginCode.GDWarpzoneObjects15= [];
gdjs.LoginCode.GDWarpzoneObjects16= [];
gdjs.LoginCode.GDWarpzoneObjects17= [];
gdjs.LoginCode.GDWarpzoneObjects18= [];
gdjs.LoginCode.GDWarpzoneObjects19= [];
gdjs.LoginCode.GDWarpzoneObjects20= [];
gdjs.LoginCode.GDWarpzoneObjects21= [];
gdjs.LoginCode.GDWarpzoneObjects22= [];
gdjs.LoginCode.GDWarpzoneObjects23= [];
gdjs.LoginCode.GDWarpzoneObjects24= [];
gdjs.LoginCode.GDWarpzoneObjects25= [];
gdjs.LoginCode.GDWarpzoneObjects26= [];
gdjs.LoginCode.GDWarpzoneObjects27= [];
gdjs.LoginCode.GDSpawningPointObjects1= [];
gdjs.LoginCode.GDSpawningPointObjects2= [];
gdjs.LoginCode.GDSpawningPointObjects3= [];
gdjs.LoginCode.GDSpawningPointObjects4= [];
gdjs.LoginCode.GDSpawningPointObjects5= [];
gdjs.LoginCode.GDSpawningPointObjects6= [];
gdjs.LoginCode.GDSpawningPointObjects7= [];
gdjs.LoginCode.GDSpawningPointObjects8= [];
gdjs.LoginCode.GDSpawningPointObjects9= [];
gdjs.LoginCode.GDSpawningPointObjects10= [];
gdjs.LoginCode.GDSpawningPointObjects11= [];
gdjs.LoginCode.GDSpawningPointObjects12= [];
gdjs.LoginCode.GDSpawningPointObjects13= [];
gdjs.LoginCode.GDSpawningPointObjects14= [];
gdjs.LoginCode.GDSpawningPointObjects15= [];
gdjs.LoginCode.GDSpawningPointObjects16= [];
gdjs.LoginCode.GDSpawningPointObjects17= [];
gdjs.LoginCode.GDSpawningPointObjects18= [];
gdjs.LoginCode.GDSpawningPointObjects19= [];
gdjs.LoginCode.GDSpawningPointObjects20= [];
gdjs.LoginCode.GDSpawningPointObjects21= [];
gdjs.LoginCode.GDSpawningPointObjects22= [];
gdjs.LoginCode.GDSpawningPointObjects23= [];
gdjs.LoginCode.GDSpawningPointObjects24= [];
gdjs.LoginCode.GDSpawningPointObjects25= [];
gdjs.LoginCode.GDSpawningPointObjects26= [];
gdjs.LoginCode.GDSpawningPointObjects27= [];
gdjs.LoginCode.GDTransitionObjects1= [];
gdjs.LoginCode.GDTransitionObjects2= [];
gdjs.LoginCode.GDTransitionObjects3= [];
gdjs.LoginCode.GDTransitionObjects4= [];
gdjs.LoginCode.GDTransitionObjects5= [];
gdjs.LoginCode.GDTransitionObjects6= [];
gdjs.LoginCode.GDTransitionObjects7= [];
gdjs.LoginCode.GDTransitionObjects8= [];
gdjs.LoginCode.GDTransitionObjects9= [];
gdjs.LoginCode.GDTransitionObjects10= [];
gdjs.LoginCode.GDTransitionObjects11= [];
gdjs.LoginCode.GDTransitionObjects12= [];
gdjs.LoginCode.GDTransitionObjects13= [];
gdjs.LoginCode.GDTransitionObjects14= [];
gdjs.LoginCode.GDTransitionObjects15= [];
gdjs.LoginCode.GDTransitionObjects16= [];
gdjs.LoginCode.GDTransitionObjects17= [];
gdjs.LoginCode.GDTransitionObjects18= [];
gdjs.LoginCode.GDTransitionObjects19= [];
gdjs.LoginCode.GDTransitionObjects20= [];
gdjs.LoginCode.GDTransitionObjects21= [];
gdjs.LoginCode.GDTransitionObjects22= [];
gdjs.LoginCode.GDTransitionObjects23= [];
gdjs.LoginCode.GDTransitionObjects24= [];
gdjs.LoginCode.GDTransitionObjects25= [];
gdjs.LoginCode.GDTransitionObjects26= [];
gdjs.LoginCode.GDTransitionObjects27= [];
gdjs.LoginCode.GDTransparentBackgroundObjects1= [];
gdjs.LoginCode.GDTransparentBackgroundObjects2= [];
gdjs.LoginCode.GDTransparentBackgroundObjects3= [];
gdjs.LoginCode.GDTransparentBackgroundObjects4= [];
gdjs.LoginCode.GDTransparentBackgroundObjects5= [];
gdjs.LoginCode.GDTransparentBackgroundObjects6= [];
gdjs.LoginCode.GDTransparentBackgroundObjects7= [];
gdjs.LoginCode.GDTransparentBackgroundObjects8= [];
gdjs.LoginCode.GDTransparentBackgroundObjects9= [];
gdjs.LoginCode.GDTransparentBackgroundObjects10= [];
gdjs.LoginCode.GDTransparentBackgroundObjects11= [];
gdjs.LoginCode.GDTransparentBackgroundObjects12= [];
gdjs.LoginCode.GDTransparentBackgroundObjects13= [];
gdjs.LoginCode.GDTransparentBackgroundObjects14= [];
gdjs.LoginCode.GDTransparentBackgroundObjects15= [];
gdjs.LoginCode.GDTransparentBackgroundObjects16= [];
gdjs.LoginCode.GDTransparentBackgroundObjects17= [];
gdjs.LoginCode.GDTransparentBackgroundObjects18= [];
gdjs.LoginCode.GDTransparentBackgroundObjects19= [];
gdjs.LoginCode.GDTransparentBackgroundObjects20= [];
gdjs.LoginCode.GDTransparentBackgroundObjects21= [];
gdjs.LoginCode.GDTransparentBackgroundObjects22= [];
gdjs.LoginCode.GDTransparentBackgroundObjects23= [];
gdjs.LoginCode.GDTransparentBackgroundObjects24= [];
gdjs.LoginCode.GDTransparentBackgroundObjects25= [];
gdjs.LoginCode.GDTransparentBackgroundObjects26= [];
gdjs.LoginCode.GDTransparentBackgroundObjects27= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects1= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects2= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects3= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects4= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects5= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects6= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects7= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects8= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects9= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects10= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects11= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects12= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects13= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects14= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects15= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects16= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects17= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects18= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects19= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects20= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects21= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects22= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects23= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects24= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects25= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects26= [];
gdjs.LoginCode.GDTransparentBackgroundTextObjects27= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects1= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects2= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects3= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects4= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects5= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects6= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects7= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects8= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects9= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects10= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects11= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects12= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects13= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects14= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects15= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects16= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects17= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects18= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects19= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects20= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects21= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects22= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects23= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects24= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects25= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects26= [];
gdjs.LoginCode.GDAnnouncementBackgroundObjects27= [];
gdjs.LoginCode.GDAnnouncementMaskObjects1= [];
gdjs.LoginCode.GDAnnouncementMaskObjects2= [];
gdjs.LoginCode.GDAnnouncementMaskObjects3= [];
gdjs.LoginCode.GDAnnouncementMaskObjects4= [];
gdjs.LoginCode.GDAnnouncementMaskObjects5= [];
gdjs.LoginCode.GDAnnouncementMaskObjects6= [];
gdjs.LoginCode.GDAnnouncementMaskObjects7= [];
gdjs.LoginCode.GDAnnouncementMaskObjects8= [];
gdjs.LoginCode.GDAnnouncementMaskObjects9= [];
gdjs.LoginCode.GDAnnouncementMaskObjects10= [];
gdjs.LoginCode.GDAnnouncementMaskObjects11= [];
gdjs.LoginCode.GDAnnouncementMaskObjects12= [];
gdjs.LoginCode.GDAnnouncementMaskObjects13= [];
gdjs.LoginCode.GDAnnouncementMaskObjects14= [];
gdjs.LoginCode.GDAnnouncementMaskObjects15= [];
gdjs.LoginCode.GDAnnouncementMaskObjects16= [];
gdjs.LoginCode.GDAnnouncementMaskObjects17= [];
gdjs.LoginCode.GDAnnouncementMaskObjects18= [];
gdjs.LoginCode.GDAnnouncementMaskObjects19= [];
gdjs.LoginCode.GDAnnouncementMaskObjects20= [];
gdjs.LoginCode.GDAnnouncementMaskObjects21= [];
gdjs.LoginCode.GDAnnouncementMaskObjects22= [];
gdjs.LoginCode.GDAnnouncementMaskObjects23= [];
gdjs.LoginCode.GDAnnouncementMaskObjects24= [];
gdjs.LoginCode.GDAnnouncementMaskObjects25= [];
gdjs.LoginCode.GDAnnouncementMaskObjects26= [];
gdjs.LoginCode.GDAnnouncementMaskObjects27= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects1= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects2= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects3= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects4= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects5= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects6= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects7= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects8= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects9= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects10= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects11= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects12= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects13= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects14= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects15= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects16= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects17= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects18= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects19= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects20= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects21= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects22= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects23= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects24= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects25= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects26= [];
gdjs.LoginCode.GDAnnouncementBitmapTextObjects27= [];
gdjs.LoginCode.GDAnnouncementIconObjects1= [];
gdjs.LoginCode.GDAnnouncementIconObjects2= [];
gdjs.LoginCode.GDAnnouncementIconObjects3= [];
gdjs.LoginCode.GDAnnouncementIconObjects4= [];
gdjs.LoginCode.GDAnnouncementIconObjects5= [];
gdjs.LoginCode.GDAnnouncementIconObjects6= [];
gdjs.LoginCode.GDAnnouncementIconObjects7= [];
gdjs.LoginCode.GDAnnouncementIconObjects8= [];
gdjs.LoginCode.GDAnnouncementIconObjects9= [];
gdjs.LoginCode.GDAnnouncementIconObjects10= [];
gdjs.LoginCode.GDAnnouncementIconObjects11= [];
gdjs.LoginCode.GDAnnouncementIconObjects12= [];
gdjs.LoginCode.GDAnnouncementIconObjects13= [];
gdjs.LoginCode.GDAnnouncementIconObjects14= [];
gdjs.LoginCode.GDAnnouncementIconObjects15= [];
gdjs.LoginCode.GDAnnouncementIconObjects16= [];
gdjs.LoginCode.GDAnnouncementIconObjects17= [];
gdjs.LoginCode.GDAnnouncementIconObjects18= [];
gdjs.LoginCode.GDAnnouncementIconObjects19= [];
gdjs.LoginCode.GDAnnouncementIconObjects20= [];
gdjs.LoginCode.GDAnnouncementIconObjects21= [];
gdjs.LoginCode.GDAnnouncementIconObjects22= [];
gdjs.LoginCode.GDAnnouncementIconObjects23= [];
gdjs.LoginCode.GDAnnouncementIconObjects24= [];
gdjs.LoginCode.GDAnnouncementIconObjects25= [];
gdjs.LoginCode.GDAnnouncementIconObjects26= [];
gdjs.LoginCode.GDAnnouncementIconObjects27= [];


gdjs.LoginCode.userFunc0x1c7b730 = function(runtimeScene) {
"use strict";
window.runtimeScene=runtimeScene;
};
gdjs.LoginCode.eventsList0 = function(runtimeScene) {

{


gdjs.LoginCode.userFunc0x1c7b730(runtimeScene);

}


};gdjs.LoginCode.userFunc0x20bc230 = function(runtimeScene) {
"use strict";
window.addEventListener("keydown", function (event) {
    // Check if Page Down (key code 34) is pressed
    if (event.key === "PageDown" || event.keyCode === 34) {
        event.preventDefault(); // Prevent the default scroll action
    }
    if (event.key === "PageUp" || event.keyCode === 33) {
        event.preventDefault(); // Prevent the default scroll action
    }
});
};
gdjs.LoginCode.eventsList1 = function(runtimeScene) {

{



}


{



}


};gdjs.LoginCode.userFunc0x1c75368 = function(runtimeScene) {
"use strict";
var a = {
        "GlobalVariables": {
            "Raw": {
                "Exp": 0,
                "TmExp": 0
            },
            "Equipment": {
                "Hat": "",
                "Weapon": "",
                "Shield": "",
                "Pet": ""
            },
            "Indicators": {
                "Bonus": {
                    "Exp": 0,
                    "TmExp": 0
                },
                "Exp": 0,
                "Galders": 0,
                "Hp": 420,
                "Lv": 1,
                "Mana": 50,
                "MaxHp": 480,
                "MaxMana": 170,
                "MessageCount": 0,
                "SkillPoints": 0,
                "TmExp": 0,
                "TmLv": 0,
                "Weight": 18
            },
            "DistributedLevels": {
                "charm": 2,
                "magic": 4,
                "power": 1,
                "sense": 3
            },
            "SelectedCharacter": "Dragon",
            "LearnedSkills": [],
            "SkillLevels": {},
            "ItemObtained": [],
            "LocalBank": [],
            "localBankGalders": 0,
            "ChatMessages": [],
            "AnnouncementMessages": [],
            "QuestState": {},
            "ShortcutSlots": {
                "num_1": {
                    "map": [],
                    "panelType": 1
                },
                "num_2": {
                    "map": [],
                    "panelType": 1
                },
                "num_3": {
                    "map": [],
                    "panelType": 1
                }
            },
            "SaveData": {
                "CurrentMap": 0,
                "ItemIcons": "0",
                "SkillIcons": "0"
            },
            "BossKills": {},
            "AppliedPoints": {
                "used": 0,
                "basePoints": {}
            },
            "SpawningPointId": "Initial",
            "Type": "magic"
        }
    };

const GlobalVariables = a.GlobalVariables;
for(var i in GlobalVariables) {
    var data = GlobalVariables[i];
    runtimeScene.getGame().getVariables().get(i).fromJSObject(data);
}

if(window.equipmentManager) {
    equipmentManager.reset();
}

// fix chat bug
window.lad = false;
window.retrieveFirstTime = false;

};
gdjs.LoginCode.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.LoginCode.userFunc0x20bc230(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LoadingScreen"), gdjs.LoginCode.GDLoadingScreenObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDLoadingScreenObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoadingScreenObjects2[i].setAnimation(gdjs.evtTools.common.mod(gdjs.evtTools.runtimeScene.getTime(runtimeScene, "mon"), 3));
}
}{for(var i = 0, len = gdjs.LoginCode.GDLoadingScreenObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoadingScreenObjects2[i].getBehavior("Resizable").setSize(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton2"), gdjs.LoginCode.GDLoginButton2Objects2);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginText2"), gdjs.LoginCode.GDLoginText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButton2Objects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButton2Objects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginText2Objects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginText2Objects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Character Selection");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("DeleteTextBackground"), gdjs.LoginCode.GDDeleteTextBackgroundObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextBackgroundObjects2[i].getBehavior("Opacity").setOpacity(175);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide();
}
}
{ //Subevents
gdjs.LoginCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.readStringFromJSONFile("localSession", "guestLogin", runtimeScene, runtimeScene.getScene().getVariables().get("UserName"));
}{runtimeScene.getGame().getVariables().getFromIndex(19).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserName")));
}}

}


{



}


{


gdjs.LoginCode.userFunc0x1c75368(runtimeScene);

}


{



}


};gdjs.LoginCode.userFunc0x17a8bf8 = function(runtimeScene) {
"use strict";
console.time('test load speed')
};
gdjs.LoginCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Mobs"), true);
}}

}


};gdjs.LoginCode.asyncCallback68263828 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Clione.webp", "SpriteSheets\\Clione_animations.json", "clione", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68263828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68264220 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\BluePenguin.webp", "SpriteSheets\\BluePenguin_animations.json", "bluepenguin", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68264220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68263492 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Bad_Fury.webp", "SpriteSheets\\Bad_Fury_animations.json", "bad_fury", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68263492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68263564 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Little_Cora.webp", "SpriteSheets\\Little_Cora_animations.json", "little_cora", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68263564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68263188 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Bustshell.webp", "SpriteSheets\\Bustshell_animations.json", "bustshell", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68263188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68261628 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Janus.webp", "SpriteSheets\\Janus_animations.json", "janus", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68261628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68261124 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Glyph_Stone.webp", "SpriteSheets\\Glyph_Stone_animations.json", "glyph_stone", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68261124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68260748 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Mad_Captain.webp", "SpriteSheets\\Mad_Captain_animations.json", "captain", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68260748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68261380 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Mad_Lieutenant.webp", "SpriteSheets\\Mad_Lieutenant_animations.json", "lieutenant", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68261380(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68258836 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Wise_Sphinx.webp", "SpriteSheets\\Wise_Sphinx_animations.json", "sphinx", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68258836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68258764 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Sergeant.webp", "SpriteSheets\\Sergeant_animations.json", "sergeant", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68258764(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68260468 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Tutankhamen.webp", "SpriteSheets\\Tutankhamen_animations.json", "tutankhamen", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68260468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68258988 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Torobbie.webp", "SpriteSheets\\Torobbie_animations.json", "torobbie", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68258988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68258692 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Thiefmon.webp", "SpriteSheets\\Thiefmon_animations.json", "dummy", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68258692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68259628 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Thiefmon.webp", "SpriteSheets\\Thiefmon_animations.json", "thiefmon", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68259628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68259076 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForMobs.func(runtimeScene, "SpriteSheets\\Tottochi.webp", "SpriteSheets\\Tottochi_animations.json", "tottochi", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68259076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Npc"), true);
}}

}


};gdjs.LoginCode.asyncCallback68268852 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Bunny_Maid.webp", "SpriteSheets\\Bunny_Maid_npc.json", "Bunny_Maid", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68268852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68269516 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Lifeguard_Bean.webp", "SpriteSheets\\Lifeguard_Bean_npc.json", "Lifeguard_Bean", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68269516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68266356 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Merchant_Lorena.webp", "SpriteSheets\\Merchant_Lorena_npc.json", "Merchant_Lorena", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68266356(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68267228 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Hunter_Yuri.webp", "SpriteSheets\\Hunter_Yuri_npc.json", "Hunter_Yuri", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68267228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68267156 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Winnie.webp", "SpriteSheets\\Winnie_npc.json", "Winnie", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68267156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68267996 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Pet_Trainer_Shara.webp", "SpriteSheets\\Pet_Trainer_Shara_npc.json", "Pet_Trainer_Shara", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68267996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68268284 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Lifeguard_Deen.webp", "SpriteSheets\\Lifeguard_Deen_npc.json", "Lifeguard_Deen", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68268284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68267868 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Louis_Bitton.webp", "SpriteSheets\\Louis_Bitton_npc.json", "Louis_Bitton", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68267868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68267468 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Kochi.webp", "SpriteSheets\\Kochi_npc.json", "Kochi", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68267468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68266212 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Tinnie.webp", "SpriteSheets\\Tinnie_npc.json", "Tinnie", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68266212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68266636 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForNpcs.func(runtimeScene, "SpriteSheets\\Heidi.webp", "SpriteSheets\\Heidi_npc.json", "Heidi", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68266636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68280852 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Characters"), true);
}}
gdjs.LoginCode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\TreasureHunter.webp", "SpriteSheets\\TreasureHunter_character.json", "TreasureHunter", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68280852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68280260 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\ThiefMaster.webp", "SpriteSheets\\ThiefMaster_character.json", "ThiefMaster", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68280260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68279892 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\SoulMaster.webp", "SpriteSheets\\SoulMaster_character.json", "SoulMaster", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68279892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68279524 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList35 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Talent.webp", "SpriteSheets\\Talent_character.json", "Talent", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68279524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68279156 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList35(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList36 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Sheep.webp", "SpriteSheets\\Sheep_character.json", "Sheep", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68279156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68278572 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList36(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Rabbit.webp", "SpriteSheets\\Rabbit_character.json", "Bunny", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68278572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68277852 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Primadonna.webp", "SpriteSheets\\Primadonna_character.json", "Primadonna", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68277852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68277532 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Mercenary.webp", "SpriteSheets\\Mercenary_character.json", "Mercenary", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68277532(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68277284 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList40 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Magician.webp", "SpriteSheets\\Magician_character.json", "Magician", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68277284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68277156 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Lion.webp", "SpriteSheets\\Lion_character.json", "Lion", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68277156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68276796 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList42 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Knight.webp", "SpriteSheets\\Knight_character.json", "Knight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68276796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68276548 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList42(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList43 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Inventor.webp", "SpriteSheets\\Inventor_character.json", "Inventor", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68276548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68276156 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList43(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList44 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Duke.webp", "SpriteSheets\\Duke_character.json", "Duke", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68276156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68275452 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\DarkLord.webp", "SpriteSheets\\DarkLord_character.json", "DarkLord", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68275452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68273804 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList46 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\CyberHunter.webp", "SpriteSheets\\CyberHunter_character.json", "CyberHunter", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68273804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68274708 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList47 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Cat.webp", "SpriteSheets\\Cat_character.json", "Cat", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68274708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68274300 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList47(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList48 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\CardMaster.webp", "SpriteSheets\\CardMaster_character.json", "CardMaster", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68274300(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68273876 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList48(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList49 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Buffalo.webp", "SpriteSheets\\Buffalo_character.json", "Bull", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68273876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68271628 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList49(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList50 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Boxer.webp", "SpriteSheets\\Boxer_character.json", "Boxer", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68271628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68272796 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList50(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList51 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Bard.webp", "SpriteSheets\\Bard_character.json", "Bard", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68272796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68271556 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList51(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList52 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Raccoon.webp", "SpriteSheets\\Raccoon_character.json", "Racoon", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68271556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68272420 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList52(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList53 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\Champion.webp", "SpriteSheets\\Champion_character.json", "Champion", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68272420(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68271796 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList53(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\DragonR.webp", "SpriteSheets\\Dragon_character.json", "Dragon", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68271796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68271868 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList55 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacters.func(runtimeScene, "SpriteSheets\\FoxR.webp", "SpriteSheets\\Fox_character.json", "Fox", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68271868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68271100 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList55(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList56 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResourceForCharacterIcons.func(runtimeScene, "SpriteSheets\\overlay.webp", "SpriteSheets\\overlay.json", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68271100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.asyncCallback68281708 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Items"), true);
}}
gdjs.LoginCode.eventsList57 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__DynamicResource__AddImageFromAtlasResource.func(runtimeScene, "SpriteSheets\\spritesheet.webp", "SpriteSheets\\spritesheet.json", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68281708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList58 = function(runtimeScene) {

{


gdjs.LoginCode.userFunc0x17a8bf8(runtimeScene);

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList19(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Pets"), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList31(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList56(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList57(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.userFunc0x31a29e0 = function(runtimeScene) {
"use strict";
console.timeEnd('test load speed')
};
gdjs.LoginCode.eventsList59 = function(runtimeScene) {

{


gdjs.LoginCode.userFunc0x31a29e0(runtimeScene);

}


};gdjs.LoginCode.eventsList60 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("loadingImg"), gdjs.LoginCode.GDloadingImgObjects1);
{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "spritesheet assets", "loading-end", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LoginCode.GDloadingImgObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDloadingImgObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].hide(false);
}
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.eventsList61 = function(runtimeScene) {

{



}


};gdjs.LoginCode.eventsList62 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LoginCode.GDNicknameObjects2 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), false);
}{runtimeScene.getGame().getVariables().getFromIndex(19).setString((( gdjs.LoginCode.GDNicknameObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDNicknameObjects2[0].getString()));
}
{ //Subevents
gdjs.LoginCode.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(1), true);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Trickster Online - Trickster Online.mp3", 1, true, 50, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
gdjs.copyArray(gdjs.LoginCode.GDStartButtonObjects1, gdjs.LoginCode.GDStartButtonObjects2);

{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].setString("");
}
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "login input", "login-input-displayed", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)) != "0";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)));
}
}
{ //Subevents
gdjs.LoginCode.eventsList62(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("SavedData").getChild("AlreadyHasLogin"), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton2"), gdjs.LoginCode.GDLoginButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText2"), gdjs.LoginCode.GDLoginText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButton2Objects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButton2Objects1[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDLoginText2Objects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginText2Objects1[i].hide(false);
}
}}

}


};gdjs.LoginCode.eventsList64 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList63(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.LoginCode.GDExitButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButton2Objects1Objects = Hashtable.newFrom({"LoginButton2": gdjs.LoginCode.GDLoginButton2Objects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButtonObjects1Objects = Hashtable.newFrom({"LoginButton": gdjs.LoginCode.GDLoginButtonObjects1});
gdjs.LoginCode.eventsList65 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.LoginCode.GDNicknameObjects1, gdjs.LoginCode.GDNicknameObjects2);

{gdjs.evtTools.storage.writeStringInJSONFile("localSession", "guestLogin", (( gdjs.LoginCode.GDNicknameObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDNicknameObjects2[0].getString()));
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LoginCode.GDNicknameObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(19).setString((( gdjs.LoginCode.GDNicknameObjects1.length === 0 ) ? "" :gdjs.LoginCode.GDNicknameObjects1[0].getString()));
}{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrieveUserCards.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Logging in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


};gdjs.LoginCode.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDNicknameObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDNicknameObjects1[i].getString() != "" ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDNicknameObjects1[k] = gdjs.LoginCode.GDNicknameObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDNicknameObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList67 = function(runtimeScene) {

{

/* Reuse gdjs.LoginCode.GDDeleteTextObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects3[k] = gdjs.LoginCode.GDDeleteTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects3[i].returnVariable(gdjs.LoginCode.GDDeleteTextObjects3[i].getVariables().get("deletedTimestamp")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("cardDetails").getChild("deleteTimestamp")));
}
}}

}


};gdjs.LoginCode.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDAvatarsObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDAvatarsObjects4[i].getVariableNumber(gdjs.LoginCode.GDAvatarsObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDAvatarsObjects4[k] = gdjs.LoginCode.GDAvatarsObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDAvatarsObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDAvatarsObjects4 */
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

{for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects4[i].getBehavior("Animation").setAnimationName(gdjs.evtTools.string.toLowerCase(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("avatar"))));
}
}{for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects4[i].setCenterXInScene((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("avatar")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerNameTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerNameTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerNameTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerNameTextObjects4[k] = gdjs.LoginCode.GDPlayerNameTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerNameTextObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDPlayerNameTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects4[i].setBBText(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("name")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerJobTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerJobTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerJobTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerJobTextObjects4[k] = gdjs.LoginCode.GDPlayerJobTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerJobTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerJobTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects4[i].setBBText(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("job")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerJobTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerTypeTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerTypeTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerTypeTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerTypeTextObjects4[k] = gdjs.LoginCode.GDPlayerTypeTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerTypeTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerTypeTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects4[i].setBBText(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("type")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerTypeTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerLevelTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerLevelTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerLevelTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerLevelTextObjects4[k] = gdjs.LoginCode.GDPlayerLevelTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerLevelTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerLevelTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects4[i].setBBText(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("level")));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerLevelTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerGaldersTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerGaldersTextObjects4[k] = gdjs.LoginCode.GDPlayerGaldersTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerGaldersTextObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDCardsBackgroundObjects3, gdjs.LoginCode.GDCardsBackgroundObjects4);

/* Reuse gdjs.LoginCode.GDPlayerGaldersTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].setBBText("[color=#b36a4c]");
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].setBBText(gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].getBBText() + (gdjs.evtsExt__InterfaceFunctions__ConvertToCurrencyFormat.func(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("cardDetails").getChild("galders")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].setBBText(gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].getBBText() + ("[/color] G"));
}
}{for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].setX((( gdjs.LoginCode.GDCardsBackgroundObjects4.length === 0 ) ? 0 :gdjs.LoginCode.GDCardsBackgroundObjects4[0].getPointX("borderRight")) - (gdjs.LoginCode.GDPlayerGaldersTextObjects4[i].getWidth()));
}
}}

}


{

gdjs.copyArray(gdjs.LoginCode.GDDeleteTextObjects1, gdjs.LoginCode.GDDeleteTextObjects3);

gdjs.copyArray(gdjs.LoginCode.GDDeleteTextBackgroundObjects1, gdjs.LoginCode.GDDeleteTextBackgroundObjects3);

gdjs.copyArray(gdjs.LoginCode.GDRestoreButtonObjects1, gdjs.LoginCode.GDRestoreButtonObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("cardDetails").getChild("deleteTimestamp")) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextBackgroundObjects3[k] = gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects3[k] = gdjs.LoginCode.GDDeleteTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects3[i].getVariableNumber(gdjs.LoginCode.GDRestoreButtonObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects3[k] = gdjs.LoginCode.GDRestoreButtonObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects3 */
/* Reuse gdjs.LoginCode.GDDeleteTextBackgroundObjects3 */
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.LoginCode.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList69 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerNameTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerNameTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerNameTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerNameTextObjects3[k] = gdjs.LoginCode.GDPlayerNameTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerNameTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerJobTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerJobTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerJobTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerJobTextObjects3[k] = gdjs.LoginCode.GDPlayerJobTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerJobTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerTypeTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerTypeTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerTypeTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerTypeTextObjects3[k] = gdjs.LoginCode.GDPlayerTypeTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerTypeTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerLevelTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerLevelTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerLevelTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerLevelTextObjects3[k] = gdjs.LoginCode.GDPlayerLevelTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerLevelTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerGaldersTextObjects3[k] = gdjs.LoginCode.GDPlayerGaldersTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerGaldersTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDAvatarsObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDAvatarsObjects3[i].getVariableNumber(gdjs.LoginCode.GDAvatarsObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDAvatarsObjects3[k] = gdjs.LoginCode.GDAvatarsObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDAvatarsObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDAvatarsObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerGaldersTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerJobTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerLevelTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerNameTextObjects3 */
/* Reuse gdjs.LoginCode.GDPlayerTypeTextObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCardsBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCardsBackgroundObjects3[i].getVariableNumber(gdjs.LoginCode.GDCardsBackgroundObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("index")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCardsBackgroundObjects3[k] = gdjs.LoginCode.GDCardsBackgroundObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDCardsBackgroundObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDCardsBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDCardsBackgroundObjects3[i].getBehavior("Animation").setAnimationName(gdjs.evtTools.string.toLowerCase(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("cardDetails").getChild("type"))));
}
}
{ //Subevents
gdjs.LoginCode.eventsList68(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList70 = function(runtimeScene) {

{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().get("index");
const valueIteratorReference2 = runtimeScene.getScene().getVariables().get("cardDetails");
const iterableReference2 = runtimeScene.getScene().getVariables().get("UserCards");
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().get("index").add(1);
}
{ //Subevents: 
gdjs.LoginCode.eventsList69(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.LoginCode.eventsList71 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].getVariableNumber(gdjs.LoginCode.GDSelectedObjects2[i].getVariables().get("id")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDSelectedObjects2 */
{for(var i = 0, len = gdjs.LoginCode.GDSelectedObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDSelectedObjects2[i].getBehavior("Animation").setAnimationName("highlight");
}
}{runtimeScene.getScene().getVariables().get("SelectedCardIndex").setNumber(1);
}{runtimeScene.getScene().getVariables().get("SelectedPlayerName").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("name")));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setString(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("job")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList70(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList72 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects2);
gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDCardsBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDCardsBackgroundObjects2[i].getBehavior("Animation").setAnimationName("empty");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("UserCards")) > 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList71(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList73 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrievedError"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton2"), gdjs.LoginCode.GDLoginButton2Objects2);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginText2"), gdjs.LoginCode.GDLoginText2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrievedError"), false);
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "An Error occured, please try again in a second or two", 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "loading-end", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButton2Objects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButton2Objects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginText2Objects2.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginText2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects2[i].hide(false);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DeleteText"), gdjs.LoginCode.GDDeleteTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("DeleteTextBackground"), gdjs.LoginCode.GDDeleteTextBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects1);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), false);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Character Selection");
}{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextBackgroundObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextBackgroundObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects1[i].hide();
}
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "loading-end", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList72(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2Objects = Hashtable.newFrom({"createCharacter": gdjs.LoginCode.GDcreateCharacterObjects2});
gdjs.LoginCode.asyncCallback62813628 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "CharacterCreation", false);
}}
gdjs.LoginCode.eventsList74 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.LoginCode.asyncCallback62813628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("UserRetrievedCount")) == 3);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "No more slots left!", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("UserRetrievedCount")) < 3);
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Character creation...", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "moving to character creation", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList74(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2Objects = Hashtable.newFrom({"deleteButton": gdjs.LoginCode.GDdeleteButtonObjects2});
gdjs.LoginCode.eventsList76 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LoginCode.GDDeleteTextObjects2, gdjs.LoginCode.GDDeleteTextObjects3);

{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects3[i].returnVariable(gdjs.LoginCode.GDDeleteTextObjects3[i].getVariables().get("deletedTimestamp")).setNumber(gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp") + (10 * 1000));
}
}{gdjs.evtsExt__OnlineMultiplayerFirebase__DeleteUserCard.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)), gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("name")), (10 * 1000), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects2 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects2[i].returnVariable(gdjs.LoginCode.GDDeleteTextObjects2[i].getVariables().get("deletedTimestamp")).setNumber(gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp") + (24 * 60 * 60 * 1000));
}
}{gdjs.evtsExt__OnlineMultiplayerFirebase__DeleteUserCard.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)), gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("name")), (24 * 60 * 60 * 1000), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.eventsList77 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DeleteText"), gdjs.LoginCode.GDDeleteTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("DeleteTextBackground"), gdjs.LoginCode.GDDeleteTextBackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextBackgroundObjects3[k] = gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects3[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects3[k] = gdjs.LoginCode.GDDeleteTextObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects3.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects3[i].getVariableNumber(gdjs.LoginCode.GDRestoreButtonObjects3[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects3[k] = gdjs.LoginCode.GDRestoreButtonObjects3[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects3 */
/* Reuse gdjs.LoginCode.GDDeleteTextBackgroundObjects3 */
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects3 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextBackgroundObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DeleteText"), gdjs.LoginCode.GDDeleteTextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects2[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects2[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects2[k] = gdjs.LoginCode.GDDeleteTextObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList76(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList78 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects5);
gdjs.copyArray(gdjs.LoginCode.GDDeleteTextObjects4, gdjs.LoginCode.GDDeleteTextObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCardsBackgroundObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCardsBackgroundObjects5[i].getVariableNumber(gdjs.LoginCode.GDCardsBackgroundObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCardsBackgroundObjects5[k] = gdjs.LoginCode.GDCardsBackgroundObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDCardsBackgroundObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects5 */
{for(var i = 0, len = gdjs.LoginCode.GDCardsBackgroundObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDCardsBackgroundObjects5[i].getBehavior("Animation").setAnimationName("empty");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Avatars"), gdjs.LoginCode.GDAvatarsObjects5);
gdjs.copyArray(gdjs.LoginCode.GDDeleteTextObjects4, gdjs.LoginCode.GDDeleteTextObjects5);

gdjs.copyArray(runtimeScene.getObjects("PlayerGaldersText"), gdjs.LoginCode.GDPlayerGaldersTextObjects5);
gdjs.copyArray(runtimeScene.getObjects("PlayerJobText"), gdjs.LoginCode.GDPlayerJobTextObjects5);
gdjs.copyArray(runtimeScene.getObjects("PlayerLevelText"), gdjs.LoginCode.GDPlayerLevelTextObjects5);
gdjs.copyArray(runtimeScene.getObjects("PlayerNameText"), gdjs.LoginCode.GDPlayerNameTextObjects5);
gdjs.copyArray(runtimeScene.getObjects("PlayerTypeText"), gdjs.LoginCode.GDPlayerTypeTextObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerNameTextObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerNameTextObjects5[i].getVariableNumber(gdjs.LoginCode.GDPlayerNameTextObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerNameTextObjects5[k] = gdjs.LoginCode.GDPlayerNameTextObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerNameTextObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerJobTextObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerJobTextObjects5[i].getVariableNumber(gdjs.LoginCode.GDPlayerJobTextObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerJobTextObjects5[k] = gdjs.LoginCode.GDPlayerJobTextObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerJobTextObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerTypeTextObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerTypeTextObjects5[i].getVariableNumber(gdjs.LoginCode.GDPlayerTypeTextObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerTypeTextObjects5[k] = gdjs.LoginCode.GDPlayerTypeTextObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerTypeTextObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerLevelTextObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerLevelTextObjects5[i].getVariableNumber(gdjs.LoginCode.GDPlayerLevelTextObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerLevelTextObjects5[k] = gdjs.LoginCode.GDPlayerLevelTextObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerLevelTextObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDPlayerGaldersTextObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDPlayerGaldersTextObjects5[i].getVariableNumber(gdjs.LoginCode.GDPlayerGaldersTextObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDPlayerGaldersTextObjects5[k] = gdjs.LoginCode.GDPlayerGaldersTextObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDPlayerGaldersTextObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDAvatarsObjects5.length;i<l;++i) {
    if ( gdjs.LoginCode.GDAvatarsObjects5[i].getVariableNumber(gdjs.LoginCode.GDAvatarsObjects5[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects5[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDAvatarsObjects5[k] = gdjs.LoginCode.GDAvatarsObjects5[i];
        ++k;
    }
}
gdjs.LoginCode.GDAvatarsObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDAvatarsObjects5 */
/* Reuse gdjs.LoginCode.GDPlayerGaldersTextObjects5 */
/* Reuse gdjs.LoginCode.GDPlayerJobTextObjects5 */
/* Reuse gdjs.LoginCode.GDPlayerLevelTextObjects5 */
/* Reuse gdjs.LoginCode.GDPlayerNameTextObjects5 */
/* Reuse gdjs.LoginCode.GDPlayerTypeTextObjects5 */
{for(var i = 0, len = gdjs.LoginCode.GDPlayerNameTextObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerNameTextObjects5[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerJobTextObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerJobTextObjects5[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerTypeTextObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerTypeTextObjects5[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerLevelTextObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerLevelTextObjects5[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDPlayerGaldersTextObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDPlayerGaldersTextObjects5[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDAvatarsObjects5.length ;i < len;++i) {
    gdjs.LoginCode.GDAvatarsObjects5[i].hide();
}
}}

}


{

/* Reuse gdjs.LoginCode.GDDeleteTextObjects4 */
gdjs.copyArray(runtimeScene.getObjects("DeleteTextBackground"), gdjs.LoginCode.GDDeleteTextBackgroundObjects4);
gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextBackgroundObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextBackgroundObjects4[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextBackgroundObjects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects4[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextBackgroundObjects4[k] = gdjs.LoginCode.GDDeleteTextBackgroundObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextBackgroundObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects4[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects4[i].getVariables().get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects4[k] = gdjs.LoginCode.GDDeleteTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects4[i].getVariableNumber(gdjs.LoginCode.GDRestoreButtonObjects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects4[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects4[k] = gdjs.LoginCode.GDRestoreButtonObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects4 */
/* Reuse gdjs.LoginCode.GDDeleteTextBackgroundObjects4 */
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextBackgroundObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextBackgroundObjects4[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects4[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects4[i].hide();
}
}}

}


};gdjs.LoginCode.eventsList79 = function(runtimeScene) {

{

/* Reuse gdjs.LoginCode.GDDeleteTextObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDDeleteTextObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDDeleteTextObjects4[0].getVariables()).get("deletedTimestamp"))) - gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp") <= 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("UserRetrievedCount").sub(1);
}
{ //Subevents
gdjs.LoginCode.eventsList78(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList80 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LoginCode.GDDeleteTextObjects3, gdjs.LoginCode.GDDeleteTextObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects4.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects4[k] = gdjs.LoginCode.GDDeleteTextObjects4[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects4 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects4[i].setBBText("Delete in " + gdjs.evtsExt__InterfaceFunctions__MilisecondsToSentence.func(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects4[i].getVariables().get("deletedTimestamp"))) - gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}
{ //Subevents
gdjs.LoginCode.eventsList79(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDRestoreButtonObjects2Objects = Hashtable.newFrom({"RestoreButton": gdjs.LoginCode.GDRestoreButtonObjects2});
gdjs.LoginCode.eventsList81 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DeleteText"), gdjs.LoginCode.GDDeleteTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("DeleteTextBackground"), gdjs.LoginCode.GDDeleteTextBackgroundObjects2);
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextBackgroundObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextBackgroundObjects2[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextBackgroundObjects2[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDRestoreButtonObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDRestoreButtonObjects2[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextBackgroundObjects2[k] = gdjs.LoginCode.GDDeleteTextBackgroundObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextBackgroundObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDDeleteTextObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDDeleteTextObjects2[i].getVariableNumber(gdjs.LoginCode.GDDeleteTextObjects2[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDRestoreButtonObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDRestoreButtonObjects2[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDDeleteTextObjects2[k] = gdjs.LoginCode.GDDeleteTextObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDDeleteTextObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects2[i].getVariableNumber(gdjs.LoginCode.GDRestoreButtonObjects2[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(gdjs.LoginCode.GDRestoreButtonObjects2[i].getVariables().get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects2[k] = gdjs.LoginCode.GDRestoreButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDDeleteTextObjects2 */
/* Reuse gdjs.LoginCode.GDDeleteTextBackgroundObjects2 */
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects2 */
{for(var i = 0, len = gdjs.LoginCode.GDDeleteTextBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextBackgroundObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDDeleteTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDDeleteTextObjects2[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects2[i].hide();
}
}{gdjs.evtsExt__OnlineMultiplayerFirebase__RestoreUserCard.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)), gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild((gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDRestoreButtonObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDRestoreButtonObjects2[0].getVariables()).get("id"))) - 1).getChild("name")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCardsBackgroundObjects2Objects = Hashtable.newFrom({"CardsBackground": gdjs.LoginCode.GDCardsBackgroundObjects2});
gdjs.LoginCode.eventsList82 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDSelectedObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDSelectedObjects3[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{

/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].getVariableNumber(gdjs.LoginCode.GDSelectedObjects2[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDCardsBackgroundObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDCardsBackgroundObjects2[0].getVariables()).get("id"))) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCardsBackgroundObjects2 */
/* Reuse gdjs.LoginCode.GDSelectedObjects2 */
{for(var i = 0, len = gdjs.LoginCode.GDSelectedObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDSelectedObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}{runtimeScene.getScene().getVariables().get("SelectedCardIndex").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.LoginCode.GDCardsBackgroundObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LoginCode.GDCardsBackgroundObjects2[0].getVariables()).get("id"))));
}{runtimeScene.getScene().getVariables().get("SelectedPlayerName").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("name")));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setString(gdjs.evtsExt__InterfaceFunctions__ToTitleCase.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("UserCards").getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) - 1).getChild("job")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDOkayButtonObjects3Objects = Hashtable.newFrom({"OkayButton": gdjs.LoginCode.GDOkayButtonObjects3});
gdjs.LoginCode.asyncCallback62831396 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "CharacterCreation", false);
}}
gdjs.LoginCode.eventsList83 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.LoginCode.asyncCallback62831396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList84 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Character creation...", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "moving to character creation", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList83(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.asyncCallback62834108 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "CharacterCreation", false);
}}
gdjs.LoginCode.eventsList85 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.LoginCode.asyncCallback62834108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList86 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Character creation...", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "moving to character creation", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList85(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList87 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("UserCards")) <= 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList84(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")) == "0");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList86(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("UserCards")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")) != "0");
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrievePlayerStatsFromServer.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("SelectedPlayerName")));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Entering World", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "moving to game scene", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDBackButtonObjects2Objects = Hashtable.newFrom({"BackButton": gdjs.LoginCode.GDBackButtonObjects2});
gdjs.LoginCode.asyncCallback62839004 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.LoginCode.eventsList88 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.LoginCode.asyncCallback62839004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList89 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(20), false);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList88(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.eventsList90 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList75(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCardsBackgroundObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCardsBackgroundObjects2[i].getVariableNumber(gdjs.LoginCode.GDCardsBackgroundObjects2[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("SelectedCardIndex")) ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCardsBackgroundObjects2[k] = gdjs.LoginCode.GDCardsBackgroundObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDCardsBackgroundObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCardsBackgroundObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCardsBackgroundObjects2[i].getBehavior("Animation").getAnimationName() != "empty" ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCardsBackgroundObjects2[k] = gdjs.LoginCode.GDCardsBackgroundObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDCardsBackgroundObjects2.length = k;
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList77(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DeleteText"), gdjs.LoginCode.GDDeleteTextObjects2);

for (gdjs.LoginCode.forEachIndex3 = 0;gdjs.LoginCode.forEachIndex3 < gdjs.LoginCode.GDDeleteTextObjects2.length;++gdjs.LoginCode.forEachIndex3) {
gdjs.LoginCode.GDDeleteTextObjects3.length = 0;


gdjs.LoginCode.forEachTemporary3 = gdjs.LoginCode.GDDeleteTextObjects2[gdjs.LoginCode.forEachIndex3];
gdjs.LoginCode.GDDeleteTextObjects3.push(gdjs.LoginCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.LoginCode.eventsList80(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDRestoreButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects2[k] = gdjs.LoginCode.GDRestoreButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects2.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList81(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CardsBackground"), gdjs.LoginCode.GDCardsBackgroundObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCardsBackgroundObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList82(runtimeScene);} //End of subevents
}

}


{

gdjs.LoginCode.GDOkayButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LoginCode.GDOkayButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("OkayButton"), gdjs.LoginCode.GDOkayButtonObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDOkayButtonObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LoginCode.GDOkayButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LoginCode.GDOkayButtonObjects2_1final.indexOf(gdjs.LoginCode.GDOkayButtonObjects3[j]) === -1 )
            gdjs.LoginCode.GDOkayButtonObjects2_1final.push(gdjs.LoginCode.GDOkayButtonObjects3[j]);
    }
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(20), true);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getOnceTriggers().triggerOnce(62830724);
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.LoginCode.GDOkayButtonObjects2_1final, gdjs.LoginCode.GDOkayButtonObjects2);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList87(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackButton"), gdjs.LoginCode.GDBackButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDBackButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Login", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("PlayerRetrieved"), true);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("PlayerRetrieved"), false);
}
{ //Subevents
gdjs.LoginCode.eventsList89(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1ObjectsGDgdjs_9546LoginCode_9546GDRestoreButtonObjects1Objects = Hashtable.newFrom({"createCharacter": gdjs.LoginCode.GDcreateCharacterObjects1, "deleteButton": gdjs.LoginCode.GDdeleteButtonObjects1, "RestoreButton": gdjs.LoginCode.GDRestoreButtonObjects1});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1ObjectsGDgdjs_9546LoginCode_9546GDRestoreButtonObjects1Objects = Hashtable.newFrom({"createCharacter": gdjs.LoginCode.GDcreateCharacterObjects1, "deleteButton": gdjs.LoginCode.GDdeleteButtonObjects1, "RestoreButton": gdjs.LoginCode.GDRestoreButtonObjects1});
gdjs.LoginCode.mapOfEmptyGDCursorsObjects = Hashtable.newFrom({"Cursors": []});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCursorsObjects1Objects = Hashtable.newFrom({"Cursors": gdjs.LoginCode.GDCursorsObjects1});
gdjs.LoginCode.eventsList91 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LoginCode.mapOfEmptyGDCursorsObjects) == 0;
if (isConditionTrue_0) {
gdjs.LoginCode.GDCursorsObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDCursorsObjects1Objects, 0, 0, "Interface");
}}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoadingScreenObjects1ObjectsGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"LoadingScreen": gdjs.LoginCode.GDLoadingScreenObjects1, "StartButton": gdjs.LoginCode.GDStartButtonObjects1});
gdjs.LoginCode.eventsList92 = function(runtimeScene) {

{

/* Reuse gdjs.LoginCode.GDCursorsObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDCursorsObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDCursorsObjects1[i].isCurrentAnimationName("Hand") ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDCursorsObjects1[k] = gdjs.LoginCode.GDCursorsObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDCursorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDCursorsObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Click");
}
}}

}


};gdjs.LoginCode.eventsList93 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList92(runtimeScene);} //End of subevents
}

}


};gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDLoginButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2ObjectsGDgdjs_9546LoginCode_9546GDOkayButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDBackButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDSelectedObjects2ObjectsGDgdjs_9546LoginCode_9546GDRestoreButtonObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.LoginCode.GDStartButtonObjects2, "LoginButton": gdjs.LoginCode.GDLoginButtonObjects2, "deleteButton": gdjs.LoginCode.GDdeleteButtonObjects2, "createCharacter": gdjs.LoginCode.GDcreateCharacterObjects2, "OkayButton": gdjs.LoginCode.GDOkayButtonObjects2, "BackButton": gdjs.LoginCode.GDBackButtonObjects2, "Selected": gdjs.LoginCode.GDSelectedObjects2, "RestoreButton": gdjs.LoginCode.GDRestoreButtonObjects2});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects2Objects = Hashtable.newFrom({"ExitButton": gdjs.LoginCode.GDExitButtonObjects2});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.mapOf = Hashtable.newFrom({});
gdjs.LoginCode.eventsList94 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BackButton"), gdjs.LoginCode.GDBackButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("OkayButton"), gdjs.LoginCode.GDOkayButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.LoginCode.GDSelectedObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects2[k] = gdjs.LoginCode.GDStartButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects2[k] = gdjs.LoginCode.GDLoginButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects2[k] = gdjs.LoginCode.GDdeleteButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects2[k] = gdjs.LoginCode.GDcreateCharacterObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDOkayButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDOkayButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDOkayButtonObjects2[k] = gdjs.LoginCode.GDOkayButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDOkayButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDBackButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDBackButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDBackButtonObjects2[k] = gdjs.LoginCode.GDBackButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDBackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects2[k] = gdjs.LoginCode.GDRestoreButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDLoginButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDcreateCharacterObjects2ObjectsGDgdjs_9546LoginCode_9546GDOkayButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDBackButtonObjects2ObjectsGDgdjs_9546LoginCode_9546GDSelectedObjects2ObjectsGDgdjs_9546LoginCode_9546GDRestoreButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDRestoreButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDSelectedObjects2.length === 0 ) ? (( gdjs.LoginCode.GDBackButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDOkayButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDcreateCharacterObjects2.length === 0 ) ? (( gdjs.LoginCode.GDdeleteButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDLoginButtonObjects2.length === 0 ) ? (( gdjs.LoginCode.GDStartButtonObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDStartButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDLoginButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDdeleteButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDcreateCharacterObjects2[0].getLayer()) :gdjs.LoginCode.GDOkayButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDBackButtonObjects2[0].getLayer()) :gdjs.LoginCode.GDSelectedObjects2[0].getLayer()) :gdjs.LoginCode.GDRestoreButtonObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects2[k] = gdjs.LoginCode.GDStartButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects2[k] = gdjs.LoginCode.GDLoginButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects2[k] = gdjs.LoginCode.GDdeleteButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects2[k] = gdjs.LoginCode.GDcreateCharacterObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDOkayButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDOkayButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDOkayButtonObjects2[k] = gdjs.LoginCode.GDOkayButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDOkayButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDBackButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDBackButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDBackButtonObjects2[k] = gdjs.LoginCode.GDBackButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDBackButtonObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDSelectedObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDSelectedObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDSelectedObjects2[k] = gdjs.LoginCode.GDSelectedObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDSelectedObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects2[k] = gdjs.LoginCode.GDRestoreButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_click.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("SFXVolume")), 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_create_btnselect.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("SFXVolume")), 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects2[k] = gdjs.LoginCode.GDExitButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDExitButtonObjects2.length === 0 ) ? "" :gdjs.LoginCode.GDExitButtonObjects2[0].getLayer()));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects2.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects2[k] = gdjs.LoginCode.GDExitButtonObjects2[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_close.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("SFXVolume")), 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_open.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("SFXVolume")), 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOf, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ui_spinbtn.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("SFXVolume")), 1);
}}

}


};gdjs.LoginCode.eventsList95 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText"), gdjs.LoginCode.GDTransparentBackgroundTextObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setCenterPositionInScene((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getCenterXInScene()),(( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setWidth((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getWidth()) + 40);
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].setHeight((( gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length === 0 ) ? 0 :gdjs.LoginCode.GDTransparentBackgroundTextObjects3[0].getHeight()) + 40);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) != "    ");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects3[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TransparentBackgroundText"), gdjs.LoginCode.GDTransparentBackgroundTextObjects2);
{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundTextObjects2[i].setY(142);
}
}}

}


};gdjs.LoginCode.eventsList96 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TransparentBackground"), gdjs.LoginCode.GDTransparentBackgroundObjects2);
{/* Mismatched object type - skipped. */}{for(var i = 0, len = gdjs.LoginCode.GDTransparentBackgroundObjects2.length ;i < len;++i) {
    gdjs.LoginCode.GDTransparentBackgroundObjects2[i].setOpacity(62.5);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList95(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TransparentMessageTimer") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TransparentTextMessageSeconds"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(65620164);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.eventsList97 = function(runtimeScene, asyncObjectsList) {

{



}


};gdjs.LoginCode.asyncCallback68284412 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.LoginCode.eventsList97(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList98 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__LoadSDK.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68284412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList99 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__OnlineMultiplayerFirebase__RetrieveUserCards.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(19)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InterfaceFunctions__SetTransparentTextMessageWithTimeout.func(runtimeScene, "Logging in...", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "logging in", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


};gdjs.LoginCode.eventsList100 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("UserRetrieved"), false);
}{runtimeScene.getGame().getVariables().getFromIndex(19).setString(gdjs.evtsExt__CrazyGamesAdApi__GetUserId.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
{ //Subevents
gdjs.LoginCode.eventsList99(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.LoginCode.asyncCallback68286988 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects4);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects4.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects4[i].setString(gdjs.evtsExt__CrazyGamesAdApi__GetUserId.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}
{ //Subevents
gdjs.LoginCode.eventsList100(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoginCode.eventsList101 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__ShowAuthWindow.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.LoginCode.asyncCallback68286988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoginCode.eventsList102 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "login-input-displayed";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects3);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects3.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects3[i].setString(gdjs.evtsExt__CrazyGamesAdApi__GetUserId.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "landing-page";
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "crazygame-login-is-pressed";
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList101(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "qr-rewarded";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__DisplayHappyTime.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "loading-start";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetLoadingStarted.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "loading-end";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetLoadingStopped.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "game-start";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetGameplayStarted.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__NotifiedEvent.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "game-end";
if (isConditionTrue_0) {
{gdjs.evtsExt__CrazyGamesAdApi__SetGameplayStoped.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LoginCode.eventsList103 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__Observers__ObserveGameByGame.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "landing-page", "landing-page", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "spritesheet assets", "loading-start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.LoginCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("DynamicReady").getChild("Ready"), false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Mobs"), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Pets"), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Items"), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Characters"), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Npc"), false);
}{gdjs.evtTools.debuggerTools.log("doing process", "", "dynamic loading");
}
{ //Subevents
gdjs.LoginCode.eventsList58(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Mobs"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Items"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Characters"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Npc"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DynamicReady").getChild("Pets"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68281884);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("DynamicReady").getChild("Ready"), true);
}
{ //Subevents
gdjs.LoginCode.eventsList59(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("DynamicReady").getChild("Ready"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(62773828);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList60(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects1[k] = gdjs.LoginCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].setAnimation(1);
}
}
{ //Subevents
gdjs.LoginCode.eventsList64(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.LoginCode.GDExitButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDExitButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDExitButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDExitButtonObjects1[k] = gdjs.LoginCode.GDExitButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDExitButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDExitButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDExitButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ExitText"), gdjs.LoginCode.GDExitTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginButton2"), gdjs.LoginCode.GDLoginButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText"), gdjs.LoginCode.GDLoginTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoginText2"), gdjs.LoginCode.GDLoginText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Nickname"), gdjs.LoginCode.GDNicknameObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDNicknameObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDNicknameObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginTextObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDExitTextObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDExitTextObjects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginButton2Objects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginButton2Objects1[i].hide();
}
for(var i = 0, len = gdjs.LoginCode.GDLoginText2Objects1.length ;i < len;++i) {
    gdjs.LoginCode.GDLoginText2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.LoginCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDStartButtonObjects1[i].hide(false);
}
}{gdjs.evtsExt__InterfaceFunctions__ClearTransparentTextMessage.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoginButton2"), gdjs.LoginCode.GDLoginButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButton2Objects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButton2Objects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButton2Objects1[k] = gdjs.LoginCode.GDLoginButton2Objects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButton2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButton2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__Observers__NotifyString.func(runtimeScene, "show auth window", "crazygame-login-is-pressed", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoginButton"), gdjs.LoginCode.GDLoginButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoginButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoginButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoginButtonObjects1[k] = gdjs.LoginCode.GDLoginButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoginButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoginButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList66(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList73(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Character Selection");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList90(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1ObjectsGDgdjs_9546LoginCode_9546GDRestoreButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects1[k] = gdjs.LoginCode.GDcreateCharacterObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects1[k] = gdjs.LoginCode.GDdeleteButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects1[k] = gdjs.LoginCode.GDRestoreButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects1 */
/* Reuse gdjs.LoginCode.GDcreateCharacterObjects1 */
/* Reuse gdjs.LoginCode.GDdeleteButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDcreateCharacterObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDcreateCharacterObjects1[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.LoginCode.GDdeleteButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDdeleteButtonObjects1[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects1[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RestoreButton"), gdjs.LoginCode.GDRestoreButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("createCharacter"), gdjs.LoginCode.GDcreateCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("deleteButton"), gdjs.LoginCode.GDdeleteButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDcreateCharacterObjects1ObjectsGDgdjs_9546LoginCode_9546GDdeleteButtonObjects1ObjectsGDgdjs_9546LoginCode_9546GDRestoreButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDcreateCharacterObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDcreateCharacterObjects1[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDcreateCharacterObjects1[k] = gdjs.LoginCode.GDcreateCharacterObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDcreateCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDdeleteButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDdeleteButtonObjects1[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDdeleteButtonObjects1[k] = gdjs.LoginCode.GDdeleteButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDdeleteButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDRestoreButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDRestoreButtonObjects1[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDRestoreButtonObjects1[k] = gdjs.LoginCode.GDRestoreButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDRestoreButtonObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LoginCode.GDRestoreButtonObjects1 */
/* Reuse gdjs.LoginCode.GDcreateCharacterObjects1 */
/* Reuse gdjs.LoginCode.GDdeleteButtonObjects1 */
{for(var i = 0, len = gdjs.LoginCode.GDcreateCharacterObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDcreateCharacterObjects1[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.LoginCode.GDdeleteButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDdeleteButtonObjects1[i].setAnimationFrame(1);
}
for(var i = 0, len = gdjs.LoginCode.GDRestoreButtonObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDRestoreButtonObjects1[i].setAnimationFrame(1);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList91(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Attack");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("isOnNpcObject"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("chat");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Blocked");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Warp");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("pick");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoadingScreen"), gdjs.LoginCode.GDLoadingScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.LoginCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LoginCode.mapOfGDgdjs_9546LoginCode_9546GDLoadingScreenObjects1ObjectsGDgdjs_9546LoginCode_9546GDStartButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDLoadingScreenObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDLoadingScreenObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDLoadingScreenObjects1[k] = gdjs.LoginCode.GDLoadingScreenObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDLoadingScreenObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LoginCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.LoginCode.GDStartButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LoginCode.GDStartButtonObjects1[k] = gdjs.LoginCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.LoginCode.GDStartButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, (( gdjs.LoginCode.GDStartButtonObjects1.length === 0 ) ? (( gdjs.LoginCode.GDLoadingScreenObjects1.length === 0 ) ? "" :gdjs.LoginCode.GDLoadingScreenObjects1[0].getLayer()) :gdjs.LoginCode.GDStartButtonObjects1[0].getLayer()));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Arrow");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UsingSkill"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("skill");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("UsingDrill"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("dig");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("DefaultCursor"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cursors"), gdjs.LoginCode.GDCursorsObjects1);
{for(var i = 0, len = gdjs.LoginCode.GDCursorsObjects1.length ;i < len;++i) {
    gdjs.LoginCode.GDCursorsObjects1[i].setAnimationName("Hand");
}
}
{ //Subevents
gdjs.LoginCode.eventsList93(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(65196404);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList94(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LoginCode.eventsList96(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LoginCode.eventsList98(runtimeScene);} //End of subevents
}

}


{


let stopDoWhile_0 = false;
do {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Observers__Notified.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.LoginCode.eventsList102(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


};

gdjs.LoginCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoginCode.GDRestoreButtonObjects1.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects2.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects3.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects4.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects5.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects6.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects7.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects8.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects9.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects10.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects11.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects12.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects13.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects14.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects15.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects16.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects17.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects18.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects19.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects20.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects21.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects22.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects23.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects24.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects25.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects26.length = 0;
gdjs.LoginCode.GDRestoreButtonObjects27.length = 0;
gdjs.LoginCode.GDDeleteTextObjects1.length = 0;
gdjs.LoginCode.GDDeleteTextObjects2.length = 0;
gdjs.LoginCode.GDDeleteTextObjects3.length = 0;
gdjs.LoginCode.GDDeleteTextObjects4.length = 0;
gdjs.LoginCode.GDDeleteTextObjects5.length = 0;
gdjs.LoginCode.GDDeleteTextObjects6.length = 0;
gdjs.LoginCode.GDDeleteTextObjects7.length = 0;
gdjs.LoginCode.GDDeleteTextObjects8.length = 0;
gdjs.LoginCode.GDDeleteTextObjects9.length = 0;
gdjs.LoginCode.GDDeleteTextObjects10.length = 0;
gdjs.LoginCode.GDDeleteTextObjects11.length = 0;
gdjs.LoginCode.GDDeleteTextObjects12.length = 0;
gdjs.LoginCode.GDDeleteTextObjects13.length = 0;
gdjs.LoginCode.GDDeleteTextObjects14.length = 0;
gdjs.LoginCode.GDDeleteTextObjects15.length = 0;
gdjs.LoginCode.GDDeleteTextObjects16.length = 0;
gdjs.LoginCode.GDDeleteTextObjects17.length = 0;
gdjs.LoginCode.GDDeleteTextObjects18.length = 0;
gdjs.LoginCode.GDDeleteTextObjects19.length = 0;
gdjs.LoginCode.GDDeleteTextObjects20.length = 0;
gdjs.LoginCode.GDDeleteTextObjects21.length = 0;
gdjs.LoginCode.GDDeleteTextObjects22.length = 0;
gdjs.LoginCode.GDDeleteTextObjects23.length = 0;
gdjs.LoginCode.GDDeleteTextObjects24.length = 0;
gdjs.LoginCode.GDDeleteTextObjects25.length = 0;
gdjs.LoginCode.GDDeleteTextObjects26.length = 0;
gdjs.LoginCode.GDDeleteTextObjects27.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects1.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects2.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects3.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects4.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects5.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects6.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects7.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects8.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects9.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects10.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects11.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects12.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects13.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects14.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects15.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects16.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects17.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects18.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects19.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects20.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects21.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects22.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects23.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects24.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects25.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects26.length = 0;
gdjs.LoginCode.GDDeleteTextBackgroundObjects27.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects1.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects2.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects3.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects4.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects5.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects6.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects7.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects8.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects9.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects10.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects11.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects12.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects13.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects14.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects15.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects16.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects17.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects18.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects19.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects20.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects21.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects22.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects23.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects24.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects25.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects26.length = 0;
gdjs.LoginCode.GDLoadingScreenObjects27.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects6.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects7.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects8.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects9.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects10.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects11.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects12.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects13.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects14.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects15.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects16.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects17.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects18.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects19.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects20.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects21.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects22.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects23.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects24.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects25.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects26.length = 0;
gdjs.LoginCode.GDPlayerNameTextObjects27.length = 0;
gdjs.LoginCode.GDAvatarsObjects1.length = 0;
gdjs.LoginCode.GDAvatarsObjects2.length = 0;
gdjs.LoginCode.GDAvatarsObjects3.length = 0;
gdjs.LoginCode.GDAvatarsObjects4.length = 0;
gdjs.LoginCode.GDAvatarsObjects5.length = 0;
gdjs.LoginCode.GDAvatarsObjects6.length = 0;
gdjs.LoginCode.GDAvatarsObjects7.length = 0;
gdjs.LoginCode.GDAvatarsObjects8.length = 0;
gdjs.LoginCode.GDAvatarsObjects9.length = 0;
gdjs.LoginCode.GDAvatarsObjects10.length = 0;
gdjs.LoginCode.GDAvatarsObjects11.length = 0;
gdjs.LoginCode.GDAvatarsObjects12.length = 0;
gdjs.LoginCode.GDAvatarsObjects13.length = 0;
gdjs.LoginCode.GDAvatarsObjects14.length = 0;
gdjs.LoginCode.GDAvatarsObjects15.length = 0;
gdjs.LoginCode.GDAvatarsObjects16.length = 0;
gdjs.LoginCode.GDAvatarsObjects17.length = 0;
gdjs.LoginCode.GDAvatarsObjects18.length = 0;
gdjs.LoginCode.GDAvatarsObjects19.length = 0;
gdjs.LoginCode.GDAvatarsObjects20.length = 0;
gdjs.LoginCode.GDAvatarsObjects21.length = 0;
gdjs.LoginCode.GDAvatarsObjects22.length = 0;
gdjs.LoginCode.GDAvatarsObjects23.length = 0;
gdjs.LoginCode.GDAvatarsObjects24.length = 0;
gdjs.LoginCode.GDAvatarsObjects25.length = 0;
gdjs.LoginCode.GDAvatarsObjects26.length = 0;
gdjs.LoginCode.GDAvatarsObjects27.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects6.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects7.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects8.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects9.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects10.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects11.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects12.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects13.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects14.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects15.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects16.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects17.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects18.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects19.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects20.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects21.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects22.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects23.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects24.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects25.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects26.length = 0;
gdjs.LoginCode.GDPlayerJobTextObjects27.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects6.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects7.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects8.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects9.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects10.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects11.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects12.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects13.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects14.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects15.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects16.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects17.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects18.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects19.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects20.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects21.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects22.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects23.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects24.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects25.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects26.length = 0;
gdjs.LoginCode.GDPlayerTypeTextObjects27.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects6.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects7.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects8.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects9.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects10.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects11.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects12.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects13.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects14.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects15.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects16.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects17.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects18.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects19.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects20.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects21.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects22.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects23.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects24.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects25.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects26.length = 0;
gdjs.LoginCode.GDPlayerLevelTextObjects27.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects1.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects2.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects3.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects4.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects5.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects6.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects7.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects8.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects9.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects10.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects11.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects12.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects13.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects14.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects15.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects16.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects17.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects18.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects19.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects20.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects21.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects22.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects23.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects24.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects25.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects26.length = 0;
gdjs.LoginCode.GDPlayerGaldersTextObjects27.length = 0;
gdjs.LoginCode.GDStartButtonObjects1.length = 0;
gdjs.LoginCode.GDStartButtonObjects2.length = 0;
gdjs.LoginCode.GDStartButtonObjects3.length = 0;
gdjs.LoginCode.GDStartButtonObjects4.length = 0;
gdjs.LoginCode.GDStartButtonObjects5.length = 0;
gdjs.LoginCode.GDStartButtonObjects6.length = 0;
gdjs.LoginCode.GDStartButtonObjects7.length = 0;
gdjs.LoginCode.GDStartButtonObjects8.length = 0;
gdjs.LoginCode.GDStartButtonObjects9.length = 0;
gdjs.LoginCode.GDStartButtonObjects10.length = 0;
gdjs.LoginCode.GDStartButtonObjects11.length = 0;
gdjs.LoginCode.GDStartButtonObjects12.length = 0;
gdjs.LoginCode.GDStartButtonObjects13.length = 0;
gdjs.LoginCode.GDStartButtonObjects14.length = 0;
gdjs.LoginCode.GDStartButtonObjects15.length = 0;
gdjs.LoginCode.GDStartButtonObjects16.length = 0;
gdjs.LoginCode.GDStartButtonObjects17.length = 0;
gdjs.LoginCode.GDStartButtonObjects18.length = 0;
gdjs.LoginCode.GDStartButtonObjects19.length = 0;
gdjs.LoginCode.GDStartButtonObjects20.length = 0;
gdjs.LoginCode.GDStartButtonObjects21.length = 0;
gdjs.LoginCode.GDStartButtonObjects22.length = 0;
gdjs.LoginCode.GDStartButtonObjects23.length = 0;
gdjs.LoginCode.GDStartButtonObjects24.length = 0;
gdjs.LoginCode.GDStartButtonObjects25.length = 0;
gdjs.LoginCode.GDStartButtonObjects26.length = 0;
gdjs.LoginCode.GDStartButtonObjects27.length = 0;
gdjs.LoginCode.GDNicknameObjects1.length = 0;
gdjs.LoginCode.GDNicknameObjects2.length = 0;
gdjs.LoginCode.GDNicknameObjects3.length = 0;
gdjs.LoginCode.GDNicknameObjects4.length = 0;
gdjs.LoginCode.GDNicknameObjects5.length = 0;
gdjs.LoginCode.GDNicknameObjects6.length = 0;
gdjs.LoginCode.GDNicknameObjects7.length = 0;
gdjs.LoginCode.GDNicknameObjects8.length = 0;
gdjs.LoginCode.GDNicknameObjects9.length = 0;
gdjs.LoginCode.GDNicknameObjects10.length = 0;
gdjs.LoginCode.GDNicknameObjects11.length = 0;
gdjs.LoginCode.GDNicknameObjects12.length = 0;
gdjs.LoginCode.GDNicknameObjects13.length = 0;
gdjs.LoginCode.GDNicknameObjects14.length = 0;
gdjs.LoginCode.GDNicknameObjects15.length = 0;
gdjs.LoginCode.GDNicknameObjects16.length = 0;
gdjs.LoginCode.GDNicknameObjects17.length = 0;
gdjs.LoginCode.GDNicknameObjects18.length = 0;
gdjs.LoginCode.GDNicknameObjects19.length = 0;
gdjs.LoginCode.GDNicknameObjects20.length = 0;
gdjs.LoginCode.GDNicknameObjects21.length = 0;
gdjs.LoginCode.GDNicknameObjects22.length = 0;
gdjs.LoginCode.GDNicknameObjects23.length = 0;
gdjs.LoginCode.GDNicknameObjects24.length = 0;
gdjs.LoginCode.GDNicknameObjects25.length = 0;
gdjs.LoginCode.GDNicknameObjects26.length = 0;
gdjs.LoginCode.GDNicknameObjects27.length = 0;
gdjs.LoginCode.GDLoginButtonObjects1.length = 0;
gdjs.LoginCode.GDLoginButtonObjects2.length = 0;
gdjs.LoginCode.GDLoginButtonObjects3.length = 0;
gdjs.LoginCode.GDLoginButtonObjects4.length = 0;
gdjs.LoginCode.GDLoginButtonObjects5.length = 0;
gdjs.LoginCode.GDLoginButtonObjects6.length = 0;
gdjs.LoginCode.GDLoginButtonObjects7.length = 0;
gdjs.LoginCode.GDLoginButtonObjects8.length = 0;
gdjs.LoginCode.GDLoginButtonObjects9.length = 0;
gdjs.LoginCode.GDLoginButtonObjects10.length = 0;
gdjs.LoginCode.GDLoginButtonObjects11.length = 0;
gdjs.LoginCode.GDLoginButtonObjects12.length = 0;
gdjs.LoginCode.GDLoginButtonObjects13.length = 0;
gdjs.LoginCode.GDLoginButtonObjects14.length = 0;
gdjs.LoginCode.GDLoginButtonObjects15.length = 0;
gdjs.LoginCode.GDLoginButtonObjects16.length = 0;
gdjs.LoginCode.GDLoginButtonObjects17.length = 0;
gdjs.LoginCode.GDLoginButtonObjects18.length = 0;
gdjs.LoginCode.GDLoginButtonObjects19.length = 0;
gdjs.LoginCode.GDLoginButtonObjects20.length = 0;
gdjs.LoginCode.GDLoginButtonObjects21.length = 0;
gdjs.LoginCode.GDLoginButtonObjects22.length = 0;
gdjs.LoginCode.GDLoginButtonObjects23.length = 0;
gdjs.LoginCode.GDLoginButtonObjects24.length = 0;
gdjs.LoginCode.GDLoginButtonObjects25.length = 0;
gdjs.LoginCode.GDLoginButtonObjects26.length = 0;
gdjs.LoginCode.GDLoginButtonObjects27.length = 0;
gdjs.LoginCode.GDLoginButton2Objects1.length = 0;
gdjs.LoginCode.GDLoginButton2Objects2.length = 0;
gdjs.LoginCode.GDLoginButton2Objects3.length = 0;
gdjs.LoginCode.GDLoginButton2Objects4.length = 0;
gdjs.LoginCode.GDLoginButton2Objects5.length = 0;
gdjs.LoginCode.GDLoginButton2Objects6.length = 0;
gdjs.LoginCode.GDLoginButton2Objects7.length = 0;
gdjs.LoginCode.GDLoginButton2Objects8.length = 0;
gdjs.LoginCode.GDLoginButton2Objects9.length = 0;
gdjs.LoginCode.GDLoginButton2Objects10.length = 0;
gdjs.LoginCode.GDLoginButton2Objects11.length = 0;
gdjs.LoginCode.GDLoginButton2Objects12.length = 0;
gdjs.LoginCode.GDLoginButton2Objects13.length = 0;
gdjs.LoginCode.GDLoginButton2Objects14.length = 0;
gdjs.LoginCode.GDLoginButton2Objects15.length = 0;
gdjs.LoginCode.GDLoginButton2Objects16.length = 0;
gdjs.LoginCode.GDLoginButton2Objects17.length = 0;
gdjs.LoginCode.GDLoginButton2Objects18.length = 0;
gdjs.LoginCode.GDLoginButton2Objects19.length = 0;
gdjs.LoginCode.GDLoginButton2Objects20.length = 0;
gdjs.LoginCode.GDLoginButton2Objects21.length = 0;
gdjs.LoginCode.GDLoginButton2Objects22.length = 0;
gdjs.LoginCode.GDLoginButton2Objects23.length = 0;
gdjs.LoginCode.GDLoginButton2Objects24.length = 0;
gdjs.LoginCode.GDLoginButton2Objects25.length = 0;
gdjs.LoginCode.GDLoginButton2Objects26.length = 0;
gdjs.LoginCode.GDLoginButton2Objects27.length = 0;
gdjs.LoginCode.GDExitButtonObjects1.length = 0;
gdjs.LoginCode.GDExitButtonObjects2.length = 0;
gdjs.LoginCode.GDExitButtonObjects3.length = 0;
gdjs.LoginCode.GDExitButtonObjects4.length = 0;
gdjs.LoginCode.GDExitButtonObjects5.length = 0;
gdjs.LoginCode.GDExitButtonObjects6.length = 0;
gdjs.LoginCode.GDExitButtonObjects7.length = 0;
gdjs.LoginCode.GDExitButtonObjects8.length = 0;
gdjs.LoginCode.GDExitButtonObjects9.length = 0;
gdjs.LoginCode.GDExitButtonObjects10.length = 0;
gdjs.LoginCode.GDExitButtonObjects11.length = 0;
gdjs.LoginCode.GDExitButtonObjects12.length = 0;
gdjs.LoginCode.GDExitButtonObjects13.length = 0;
gdjs.LoginCode.GDExitButtonObjects14.length = 0;
gdjs.LoginCode.GDExitButtonObjects15.length = 0;
gdjs.LoginCode.GDExitButtonObjects16.length = 0;
gdjs.LoginCode.GDExitButtonObjects17.length = 0;
gdjs.LoginCode.GDExitButtonObjects18.length = 0;
gdjs.LoginCode.GDExitButtonObjects19.length = 0;
gdjs.LoginCode.GDExitButtonObjects20.length = 0;
gdjs.LoginCode.GDExitButtonObjects21.length = 0;
gdjs.LoginCode.GDExitButtonObjects22.length = 0;
gdjs.LoginCode.GDExitButtonObjects23.length = 0;
gdjs.LoginCode.GDExitButtonObjects24.length = 0;
gdjs.LoginCode.GDExitButtonObjects25.length = 0;
gdjs.LoginCode.GDExitButtonObjects26.length = 0;
gdjs.LoginCode.GDExitButtonObjects27.length = 0;
gdjs.LoginCode.GDLoginTextObjects1.length = 0;
gdjs.LoginCode.GDLoginTextObjects2.length = 0;
gdjs.LoginCode.GDLoginTextObjects3.length = 0;
gdjs.LoginCode.GDLoginTextObjects4.length = 0;
gdjs.LoginCode.GDLoginTextObjects5.length = 0;
gdjs.LoginCode.GDLoginTextObjects6.length = 0;
gdjs.LoginCode.GDLoginTextObjects7.length = 0;
gdjs.LoginCode.GDLoginTextObjects8.length = 0;
gdjs.LoginCode.GDLoginTextObjects9.length = 0;
gdjs.LoginCode.GDLoginTextObjects10.length = 0;
gdjs.LoginCode.GDLoginTextObjects11.length = 0;
gdjs.LoginCode.GDLoginTextObjects12.length = 0;
gdjs.LoginCode.GDLoginTextObjects13.length = 0;
gdjs.LoginCode.GDLoginTextObjects14.length = 0;
gdjs.LoginCode.GDLoginTextObjects15.length = 0;
gdjs.LoginCode.GDLoginTextObjects16.length = 0;
gdjs.LoginCode.GDLoginTextObjects17.length = 0;
gdjs.LoginCode.GDLoginTextObjects18.length = 0;
gdjs.LoginCode.GDLoginTextObjects19.length = 0;
gdjs.LoginCode.GDLoginTextObjects20.length = 0;
gdjs.LoginCode.GDLoginTextObjects21.length = 0;
gdjs.LoginCode.GDLoginTextObjects22.length = 0;
gdjs.LoginCode.GDLoginTextObjects23.length = 0;
gdjs.LoginCode.GDLoginTextObjects24.length = 0;
gdjs.LoginCode.GDLoginTextObjects25.length = 0;
gdjs.LoginCode.GDLoginTextObjects26.length = 0;
gdjs.LoginCode.GDLoginTextObjects27.length = 0;
gdjs.LoginCode.GDLoginText2Objects1.length = 0;
gdjs.LoginCode.GDLoginText2Objects2.length = 0;
gdjs.LoginCode.GDLoginText2Objects3.length = 0;
gdjs.LoginCode.GDLoginText2Objects4.length = 0;
gdjs.LoginCode.GDLoginText2Objects5.length = 0;
gdjs.LoginCode.GDLoginText2Objects6.length = 0;
gdjs.LoginCode.GDLoginText2Objects7.length = 0;
gdjs.LoginCode.GDLoginText2Objects8.length = 0;
gdjs.LoginCode.GDLoginText2Objects9.length = 0;
gdjs.LoginCode.GDLoginText2Objects10.length = 0;
gdjs.LoginCode.GDLoginText2Objects11.length = 0;
gdjs.LoginCode.GDLoginText2Objects12.length = 0;
gdjs.LoginCode.GDLoginText2Objects13.length = 0;
gdjs.LoginCode.GDLoginText2Objects14.length = 0;
gdjs.LoginCode.GDLoginText2Objects15.length = 0;
gdjs.LoginCode.GDLoginText2Objects16.length = 0;
gdjs.LoginCode.GDLoginText2Objects17.length = 0;
gdjs.LoginCode.GDLoginText2Objects18.length = 0;
gdjs.LoginCode.GDLoginText2Objects19.length = 0;
gdjs.LoginCode.GDLoginText2Objects20.length = 0;
gdjs.LoginCode.GDLoginText2Objects21.length = 0;
gdjs.LoginCode.GDLoginText2Objects22.length = 0;
gdjs.LoginCode.GDLoginText2Objects23.length = 0;
gdjs.LoginCode.GDLoginText2Objects24.length = 0;
gdjs.LoginCode.GDLoginText2Objects25.length = 0;
gdjs.LoginCode.GDLoginText2Objects26.length = 0;
gdjs.LoginCode.GDLoginText2Objects27.length = 0;
gdjs.LoginCode.GDExitTextObjects1.length = 0;
gdjs.LoginCode.GDExitTextObjects2.length = 0;
gdjs.LoginCode.GDExitTextObjects3.length = 0;
gdjs.LoginCode.GDExitTextObjects4.length = 0;
gdjs.LoginCode.GDExitTextObjects5.length = 0;
gdjs.LoginCode.GDExitTextObjects6.length = 0;
gdjs.LoginCode.GDExitTextObjects7.length = 0;
gdjs.LoginCode.GDExitTextObjects8.length = 0;
gdjs.LoginCode.GDExitTextObjects9.length = 0;
gdjs.LoginCode.GDExitTextObjects10.length = 0;
gdjs.LoginCode.GDExitTextObjects11.length = 0;
gdjs.LoginCode.GDExitTextObjects12.length = 0;
gdjs.LoginCode.GDExitTextObjects13.length = 0;
gdjs.LoginCode.GDExitTextObjects14.length = 0;
gdjs.LoginCode.GDExitTextObjects15.length = 0;
gdjs.LoginCode.GDExitTextObjects16.length = 0;
gdjs.LoginCode.GDExitTextObjects17.length = 0;
gdjs.LoginCode.GDExitTextObjects18.length = 0;
gdjs.LoginCode.GDExitTextObjects19.length = 0;
gdjs.LoginCode.GDExitTextObjects20.length = 0;
gdjs.LoginCode.GDExitTextObjects21.length = 0;
gdjs.LoginCode.GDExitTextObjects22.length = 0;
gdjs.LoginCode.GDExitTextObjects23.length = 0;
gdjs.LoginCode.GDExitTextObjects24.length = 0;
gdjs.LoginCode.GDExitTextObjects25.length = 0;
gdjs.LoginCode.GDExitTextObjects26.length = 0;
gdjs.LoginCode.GDExitTextObjects27.length = 0;
gdjs.LoginCode.GDloadingImgObjects1.length = 0;
gdjs.LoginCode.GDloadingImgObjects2.length = 0;
gdjs.LoginCode.GDloadingImgObjects3.length = 0;
gdjs.LoginCode.GDloadingImgObjects4.length = 0;
gdjs.LoginCode.GDloadingImgObjects5.length = 0;
gdjs.LoginCode.GDloadingImgObjects6.length = 0;
gdjs.LoginCode.GDloadingImgObjects7.length = 0;
gdjs.LoginCode.GDloadingImgObjects8.length = 0;
gdjs.LoginCode.GDloadingImgObjects9.length = 0;
gdjs.LoginCode.GDloadingImgObjects10.length = 0;
gdjs.LoginCode.GDloadingImgObjects11.length = 0;
gdjs.LoginCode.GDloadingImgObjects12.length = 0;
gdjs.LoginCode.GDloadingImgObjects13.length = 0;
gdjs.LoginCode.GDloadingImgObjects14.length = 0;
gdjs.LoginCode.GDloadingImgObjects15.length = 0;
gdjs.LoginCode.GDloadingImgObjects16.length = 0;
gdjs.LoginCode.GDloadingImgObjects17.length = 0;
gdjs.LoginCode.GDloadingImgObjects18.length = 0;
gdjs.LoginCode.GDloadingImgObjects19.length = 0;
gdjs.LoginCode.GDloadingImgObjects20.length = 0;
gdjs.LoginCode.GDloadingImgObjects21.length = 0;
gdjs.LoginCode.GDloadingImgObjects22.length = 0;
gdjs.LoginCode.GDloadingImgObjects23.length = 0;
gdjs.LoginCode.GDloadingImgObjects24.length = 0;
gdjs.LoginCode.GDloadingImgObjects25.length = 0;
gdjs.LoginCode.GDloadingImgObjects26.length = 0;
gdjs.LoginCode.GDloadingImgObjects27.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects5.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects6.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects7.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects8.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects9.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects10.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects11.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects12.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects13.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects14.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects15.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects16.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects17.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects18.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects19.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects20.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects21.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects22.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects23.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects24.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects25.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects26.length = 0;
gdjs.LoginCode.GDNewTiledSpriteObjects27.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects1.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects2.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects3.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects4.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects5.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects6.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects7.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects8.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects9.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects10.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects11.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects12.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects13.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects14.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects15.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects16.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects17.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects18.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects19.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects20.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects21.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects22.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects23.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects24.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects25.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects26.length = 0;
gdjs.LoginCode.GDCharacterSelectBackgroundObjects27.length = 0;
gdjs.LoginCode.GDSelectedObjects1.length = 0;
gdjs.LoginCode.GDSelectedObjects2.length = 0;
gdjs.LoginCode.GDSelectedObjects3.length = 0;
gdjs.LoginCode.GDSelectedObjects4.length = 0;
gdjs.LoginCode.GDSelectedObjects5.length = 0;
gdjs.LoginCode.GDSelectedObjects6.length = 0;
gdjs.LoginCode.GDSelectedObjects7.length = 0;
gdjs.LoginCode.GDSelectedObjects8.length = 0;
gdjs.LoginCode.GDSelectedObjects9.length = 0;
gdjs.LoginCode.GDSelectedObjects10.length = 0;
gdjs.LoginCode.GDSelectedObjects11.length = 0;
gdjs.LoginCode.GDSelectedObjects12.length = 0;
gdjs.LoginCode.GDSelectedObjects13.length = 0;
gdjs.LoginCode.GDSelectedObjects14.length = 0;
gdjs.LoginCode.GDSelectedObjects15.length = 0;
gdjs.LoginCode.GDSelectedObjects16.length = 0;
gdjs.LoginCode.GDSelectedObjects17.length = 0;
gdjs.LoginCode.GDSelectedObjects18.length = 0;
gdjs.LoginCode.GDSelectedObjects19.length = 0;
gdjs.LoginCode.GDSelectedObjects20.length = 0;
gdjs.LoginCode.GDSelectedObjects21.length = 0;
gdjs.LoginCode.GDSelectedObjects22.length = 0;
gdjs.LoginCode.GDSelectedObjects23.length = 0;
gdjs.LoginCode.GDSelectedObjects24.length = 0;
gdjs.LoginCode.GDSelectedObjects25.length = 0;
gdjs.LoginCode.GDSelectedObjects26.length = 0;
gdjs.LoginCode.GDSelectedObjects27.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects1.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects2.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects3.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects4.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects5.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects6.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects7.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects8.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects9.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects10.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects11.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects12.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects13.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects14.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects15.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects16.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects17.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects18.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects19.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects20.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects21.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects22.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects23.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects24.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects25.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects26.length = 0;
gdjs.LoginCode.GDCardsBackgroundObjects27.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects1.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects2.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects3.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects4.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects5.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects6.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects7.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects8.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects9.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects10.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects11.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects12.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects13.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects14.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects15.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects16.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects17.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects18.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects19.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects20.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects21.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects22.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects23.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects24.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects25.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects26.length = 0;
gdjs.LoginCode.GDcreateCharacterObjects27.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects1.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects2.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects3.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects4.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects5.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects6.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects7.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects8.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects9.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects10.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects11.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects12.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects13.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects14.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects15.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects16.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects17.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects18.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects19.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects20.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects21.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects22.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects23.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects24.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects25.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects26.length = 0;
gdjs.LoginCode.GDdeleteButtonObjects27.length = 0;
gdjs.LoginCode.GDOkayButtonObjects1.length = 0;
gdjs.LoginCode.GDOkayButtonObjects2.length = 0;
gdjs.LoginCode.GDOkayButtonObjects3.length = 0;
gdjs.LoginCode.GDOkayButtonObjects4.length = 0;
gdjs.LoginCode.GDOkayButtonObjects5.length = 0;
gdjs.LoginCode.GDOkayButtonObjects6.length = 0;
gdjs.LoginCode.GDOkayButtonObjects7.length = 0;
gdjs.LoginCode.GDOkayButtonObjects8.length = 0;
gdjs.LoginCode.GDOkayButtonObjects9.length = 0;
gdjs.LoginCode.GDOkayButtonObjects10.length = 0;
gdjs.LoginCode.GDOkayButtonObjects11.length = 0;
gdjs.LoginCode.GDOkayButtonObjects12.length = 0;
gdjs.LoginCode.GDOkayButtonObjects13.length = 0;
gdjs.LoginCode.GDOkayButtonObjects14.length = 0;
gdjs.LoginCode.GDOkayButtonObjects15.length = 0;
gdjs.LoginCode.GDOkayButtonObjects16.length = 0;
gdjs.LoginCode.GDOkayButtonObjects17.length = 0;
gdjs.LoginCode.GDOkayButtonObjects18.length = 0;
gdjs.LoginCode.GDOkayButtonObjects19.length = 0;
gdjs.LoginCode.GDOkayButtonObjects20.length = 0;
gdjs.LoginCode.GDOkayButtonObjects21.length = 0;
gdjs.LoginCode.GDOkayButtonObjects22.length = 0;
gdjs.LoginCode.GDOkayButtonObjects23.length = 0;
gdjs.LoginCode.GDOkayButtonObjects24.length = 0;
gdjs.LoginCode.GDOkayButtonObjects25.length = 0;
gdjs.LoginCode.GDOkayButtonObjects26.length = 0;
gdjs.LoginCode.GDOkayButtonObjects27.length = 0;
gdjs.LoginCode.GDBackButtonObjects1.length = 0;
gdjs.LoginCode.GDBackButtonObjects2.length = 0;
gdjs.LoginCode.GDBackButtonObjects3.length = 0;
gdjs.LoginCode.GDBackButtonObjects4.length = 0;
gdjs.LoginCode.GDBackButtonObjects5.length = 0;
gdjs.LoginCode.GDBackButtonObjects6.length = 0;
gdjs.LoginCode.GDBackButtonObjects7.length = 0;
gdjs.LoginCode.GDBackButtonObjects8.length = 0;
gdjs.LoginCode.GDBackButtonObjects9.length = 0;
gdjs.LoginCode.GDBackButtonObjects10.length = 0;
gdjs.LoginCode.GDBackButtonObjects11.length = 0;
gdjs.LoginCode.GDBackButtonObjects12.length = 0;
gdjs.LoginCode.GDBackButtonObjects13.length = 0;
gdjs.LoginCode.GDBackButtonObjects14.length = 0;
gdjs.LoginCode.GDBackButtonObjects15.length = 0;
gdjs.LoginCode.GDBackButtonObjects16.length = 0;
gdjs.LoginCode.GDBackButtonObjects17.length = 0;
gdjs.LoginCode.GDBackButtonObjects18.length = 0;
gdjs.LoginCode.GDBackButtonObjects19.length = 0;
gdjs.LoginCode.GDBackButtonObjects20.length = 0;
gdjs.LoginCode.GDBackButtonObjects21.length = 0;
gdjs.LoginCode.GDBackButtonObjects22.length = 0;
gdjs.LoginCode.GDBackButtonObjects23.length = 0;
gdjs.LoginCode.GDBackButtonObjects24.length = 0;
gdjs.LoginCode.GDBackButtonObjects25.length = 0;
gdjs.LoginCode.GDBackButtonObjects26.length = 0;
gdjs.LoginCode.GDBackButtonObjects27.length = 0;
gdjs.LoginCode.GDCursorsObjects1.length = 0;
gdjs.LoginCode.GDCursorsObjects2.length = 0;
gdjs.LoginCode.GDCursorsObjects3.length = 0;
gdjs.LoginCode.GDCursorsObjects4.length = 0;
gdjs.LoginCode.GDCursorsObjects5.length = 0;
gdjs.LoginCode.GDCursorsObjects6.length = 0;
gdjs.LoginCode.GDCursorsObjects7.length = 0;
gdjs.LoginCode.GDCursorsObjects8.length = 0;
gdjs.LoginCode.GDCursorsObjects9.length = 0;
gdjs.LoginCode.GDCursorsObjects10.length = 0;
gdjs.LoginCode.GDCursorsObjects11.length = 0;
gdjs.LoginCode.GDCursorsObjects12.length = 0;
gdjs.LoginCode.GDCursorsObjects13.length = 0;
gdjs.LoginCode.GDCursorsObjects14.length = 0;
gdjs.LoginCode.GDCursorsObjects15.length = 0;
gdjs.LoginCode.GDCursorsObjects16.length = 0;
gdjs.LoginCode.GDCursorsObjects17.length = 0;
gdjs.LoginCode.GDCursorsObjects18.length = 0;
gdjs.LoginCode.GDCursorsObjects19.length = 0;
gdjs.LoginCode.GDCursorsObjects20.length = 0;
gdjs.LoginCode.GDCursorsObjects21.length = 0;
gdjs.LoginCode.GDCursorsObjects22.length = 0;
gdjs.LoginCode.GDCursorsObjects23.length = 0;
gdjs.LoginCode.GDCursorsObjects24.length = 0;
gdjs.LoginCode.GDCursorsObjects25.length = 0;
gdjs.LoginCode.GDCursorsObjects26.length = 0;
gdjs.LoginCode.GDCursorsObjects27.length = 0;
gdjs.LoginCode.GDWarpzoneObjects1.length = 0;
gdjs.LoginCode.GDWarpzoneObjects2.length = 0;
gdjs.LoginCode.GDWarpzoneObjects3.length = 0;
gdjs.LoginCode.GDWarpzoneObjects4.length = 0;
gdjs.LoginCode.GDWarpzoneObjects5.length = 0;
gdjs.LoginCode.GDWarpzoneObjects6.length = 0;
gdjs.LoginCode.GDWarpzoneObjects7.length = 0;
gdjs.LoginCode.GDWarpzoneObjects8.length = 0;
gdjs.LoginCode.GDWarpzoneObjects9.length = 0;
gdjs.LoginCode.GDWarpzoneObjects10.length = 0;
gdjs.LoginCode.GDWarpzoneObjects11.length = 0;
gdjs.LoginCode.GDWarpzoneObjects12.length = 0;
gdjs.LoginCode.GDWarpzoneObjects13.length = 0;
gdjs.LoginCode.GDWarpzoneObjects14.length = 0;
gdjs.LoginCode.GDWarpzoneObjects15.length = 0;
gdjs.LoginCode.GDWarpzoneObjects16.length = 0;
gdjs.LoginCode.GDWarpzoneObjects17.length = 0;
gdjs.LoginCode.GDWarpzoneObjects18.length = 0;
gdjs.LoginCode.GDWarpzoneObjects19.length = 0;
gdjs.LoginCode.GDWarpzoneObjects20.length = 0;
gdjs.LoginCode.GDWarpzoneObjects21.length = 0;
gdjs.LoginCode.GDWarpzoneObjects22.length = 0;
gdjs.LoginCode.GDWarpzoneObjects23.length = 0;
gdjs.LoginCode.GDWarpzoneObjects24.length = 0;
gdjs.LoginCode.GDWarpzoneObjects25.length = 0;
gdjs.LoginCode.GDWarpzoneObjects26.length = 0;
gdjs.LoginCode.GDWarpzoneObjects27.length = 0;
gdjs.LoginCode.GDSpawningPointObjects1.length = 0;
gdjs.LoginCode.GDSpawningPointObjects2.length = 0;
gdjs.LoginCode.GDSpawningPointObjects3.length = 0;
gdjs.LoginCode.GDSpawningPointObjects4.length = 0;
gdjs.LoginCode.GDSpawningPointObjects5.length = 0;
gdjs.LoginCode.GDSpawningPointObjects6.length = 0;
gdjs.LoginCode.GDSpawningPointObjects7.length = 0;
gdjs.LoginCode.GDSpawningPointObjects8.length = 0;
gdjs.LoginCode.GDSpawningPointObjects9.length = 0;
gdjs.LoginCode.GDSpawningPointObjects10.length = 0;
gdjs.LoginCode.GDSpawningPointObjects11.length = 0;
gdjs.LoginCode.GDSpawningPointObjects12.length = 0;
gdjs.LoginCode.GDSpawningPointObjects13.length = 0;
gdjs.LoginCode.GDSpawningPointObjects14.length = 0;
gdjs.LoginCode.GDSpawningPointObjects15.length = 0;
gdjs.LoginCode.GDSpawningPointObjects16.length = 0;
gdjs.LoginCode.GDSpawningPointObjects17.length = 0;
gdjs.LoginCode.GDSpawningPointObjects18.length = 0;
gdjs.LoginCode.GDSpawningPointObjects19.length = 0;
gdjs.LoginCode.GDSpawningPointObjects20.length = 0;
gdjs.LoginCode.GDSpawningPointObjects21.length = 0;
gdjs.LoginCode.GDSpawningPointObjects22.length = 0;
gdjs.LoginCode.GDSpawningPointObjects23.length = 0;
gdjs.LoginCode.GDSpawningPointObjects24.length = 0;
gdjs.LoginCode.GDSpawningPointObjects25.length = 0;
gdjs.LoginCode.GDSpawningPointObjects26.length = 0;
gdjs.LoginCode.GDSpawningPointObjects27.length = 0;
gdjs.LoginCode.GDTransitionObjects1.length = 0;
gdjs.LoginCode.GDTransitionObjects2.length = 0;
gdjs.LoginCode.GDTransitionObjects3.length = 0;
gdjs.LoginCode.GDTransitionObjects4.length = 0;
gdjs.LoginCode.GDTransitionObjects5.length = 0;
gdjs.LoginCode.GDTransitionObjects6.length = 0;
gdjs.LoginCode.GDTransitionObjects7.length = 0;
gdjs.LoginCode.GDTransitionObjects8.length = 0;
gdjs.LoginCode.GDTransitionObjects9.length = 0;
gdjs.LoginCode.GDTransitionObjects10.length = 0;
gdjs.LoginCode.GDTransitionObjects11.length = 0;
gdjs.LoginCode.GDTransitionObjects12.length = 0;
gdjs.LoginCode.GDTransitionObjects13.length = 0;
gdjs.LoginCode.GDTransitionObjects14.length = 0;
gdjs.LoginCode.GDTransitionObjects15.length = 0;
gdjs.LoginCode.GDTransitionObjects16.length = 0;
gdjs.LoginCode.GDTransitionObjects17.length = 0;
gdjs.LoginCode.GDTransitionObjects18.length = 0;
gdjs.LoginCode.GDTransitionObjects19.length = 0;
gdjs.LoginCode.GDTransitionObjects20.length = 0;
gdjs.LoginCode.GDTransitionObjects21.length = 0;
gdjs.LoginCode.GDTransitionObjects22.length = 0;
gdjs.LoginCode.GDTransitionObjects23.length = 0;
gdjs.LoginCode.GDTransitionObjects24.length = 0;
gdjs.LoginCode.GDTransitionObjects25.length = 0;
gdjs.LoginCode.GDTransitionObjects26.length = 0;
gdjs.LoginCode.GDTransitionObjects27.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects1.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects2.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects3.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects4.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects5.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects6.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects7.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects8.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects9.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects10.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects11.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects12.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects13.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects14.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects15.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects16.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects17.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects18.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects19.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects20.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects21.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects22.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects23.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects24.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects25.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects26.length = 0;
gdjs.LoginCode.GDTransparentBackgroundObjects27.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects1.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects2.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects3.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects4.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects5.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects6.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects7.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects8.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects9.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects10.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects11.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects12.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects13.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects14.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects15.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects16.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects17.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects18.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects19.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects20.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects21.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects22.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects23.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects24.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects25.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects26.length = 0;
gdjs.LoginCode.GDTransparentBackgroundTextObjects27.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects6.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects7.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects8.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects9.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects10.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects11.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects12.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects13.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects14.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects15.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects16.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects17.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects18.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects19.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects20.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects21.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects22.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects23.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects24.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects25.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects26.length = 0;
gdjs.LoginCode.GDAnnouncementBackgroundObjects27.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects6.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects7.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects8.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects9.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects10.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects11.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects12.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects13.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects14.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects15.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects16.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects17.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects18.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects19.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects20.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects21.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects22.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects23.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects24.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects25.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects26.length = 0;
gdjs.LoginCode.GDAnnouncementMaskObjects27.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects6.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects7.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects8.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects9.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects10.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects11.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects12.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects13.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects14.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects15.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects16.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects17.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects18.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects19.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects20.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects21.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects22.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects23.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects24.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects25.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects26.length = 0;
gdjs.LoginCode.GDAnnouncementBitmapTextObjects27.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects1.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects2.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects3.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects4.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects5.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects6.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects7.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects8.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects9.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects10.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects11.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects12.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects13.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects14.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects15.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects16.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects17.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects18.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects19.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects20.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects21.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects22.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects23.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects24.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects25.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects26.length = 0;
gdjs.LoginCode.GDAnnouncementIconObjects27.length = 0;

gdjs.LoginCode.eventsList103(runtimeScene);

return;

}

gdjs['LoginCode'] = gdjs.LoginCode;
